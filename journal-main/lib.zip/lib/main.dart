import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';
import 'package:journal_macos/src/core/app_core.dart';
import 'package:journal_macos/src/features/journals/infrastructure/datasources/remote/journal_api.dart';
import 'package:journal_macos/src/features/journals/infrastructure/datasources/remote/journal_repository_impl.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_bloc.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_events.dart';
import 'package:journal_macos/src/features/projects/domain/entities/project_entity.dart';
import 'package:journal_macos/src/features/projects/domain/repositories/project_repository.dart';
import 'package:journal_macos/src/features/projects/infrastructure/datasources/project_http_api.dart';
import 'package:journal_macos/src/features/projects/infrastructure/datasources/testdata_projects_http_crud_api.dart';
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_bloc.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_event.dart';
import 'package:journal_macos/src/features/snippets/domain/entities/snippet_entity.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/datasources/mappers/json_snippetvo_mappers.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/datasources/remote/snippet_api.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/models/snippet_vo.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_bloc.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_events.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/api/task_api.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/repo/task_repository_impl.dart';
import 'package:journal_macos/src/features/tasks/presentation/bloc/task_bloc.dart';
import 'package:journal_macos/src/features/tasks/presentation/bloc/task_events.dart';

import 'src/core/routes/routes.dart';
import 'src/features/home/presentation/screens/screens.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
     final ICrudHttpApi snippetApi = SnippetApi(
         baseUrl: AppSettings.serverUrl);
    final SnippetBloc snippetBloc = SnippetBloc(repository: CrudRepositoryImpl<SnippetEntity, SnippetVo>(
      api: snippetApi,
      voFromJsonFn: (Map<String, dynamic> json) => SnippetVo.fromJson(json),
      entityFromVoFn: (SnippetVo e) => SnippetEntity.fromVo(e),

    ));
    return MultiBlocProvider(
        providers: [
          BlocProvider<ProjectBloc>(create:(context)=> ProjectBloc(repository: ProjectRepositoryImpl(
            api: ProjectHttpApi(AppSettings.serverUrl),
            voFromJsonFn: (Map<String, dynamic> json) => ProjectVo.fromJson(json),
            entityFromVoFn: (ProjectVo e) => ProjectEntity.fromVo(e),
          ))..add(LoadProjects())),
          BlocProvider<JournalBloc>(
              create: (context) =>
              JournalBloc(repository: JournalRepositoryImpl(JournalApi(baseUrl:  AppSettings.serverUrl)
              ))
                ..add(LoadJournals())),
          BlocProvider<TaskBloc>(
              create: (context) =>
              TaskBloc(repository: TaskRepositoryImpl(TaskApi(baseUrl:  AppSettings.serverUrl)
              ))
                ..add(LoadTasks())),
          BlocProvider<SnippetBloc>(
          create: (context) => snippetBloc..add( LoadSnippets())),


          // BlocProvider<DevJournalBloc>(
          //   create: (context) => DevJournalBloc(
          //       repository: DevJournalRepository(
          //           baseUrl: 'http://localhost:3001/dev-journals'))
          //     ..add(DbLoadDevJournal(criteria: null)),
          //   // create: (context) => Bloc(promptRepository: PromptRepositoryMock())..add(DbSearchPrompts(criteria: null)),
          // ),
        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          initialRoute: HomeScreen.routeName,
          onGenerateRoute: AppRouter.onGenerateRoute,
          title: 'Flutter Demo',
          // theme: ThemeData(
          //   primarySwatch: Colors.blue,
          //   primaryColorDark: Colors.blue.shade900,
          //   primaryColorLight: Colors.blue.shade50,
          // ),
          home: const HomeScreen(),
        ));

    // );
  }
}
