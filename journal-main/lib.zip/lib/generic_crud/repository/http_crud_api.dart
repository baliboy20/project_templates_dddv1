import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';

import '../../src/core/app_core.dart';
import 'crud_repository.dart';

abstract class ICrudHttpApi<T extends ValueObjectMappable> {
  final String baseUrl;

  ICrudHttpApi({required this.baseUrl});

  /// Say hello to test the API.
  Future<bool> sayHello();

  /// Fetch all items from the API.
  Future<List<T>> getAllItems();

  /// Find items by title.
  Future<List<T>> findItemsByTitle(String title);

  Future<T> findItemById(String id);

  /// Create a new item in the API.
  Future<T> createItem(T item);

  /// Update an existing item in the API.
  Future<T> updateItem(T item);

  /// Delete an item by its ID.
  Future<bool> deleteItemById(String id);

  /// Filter items based on criteria.
  Future<List<T>> filterItems(Map<String, dynamic> criteria);
}

class CrudHttpApiImpl<T extends ValueObjectMappable>
    implements ICrudHttpApi<T> {
  final String baseUrl;
  final dynamic Function(String) fromJsonFactory;
  final String Function(dynamic) toJsonFactory;

  CrudHttpApiImpl(
      {
        required this.fromJsonFactory,
      required this.toJsonFactory,
      this.baseUrl = AppSettings.serverUrl});

  Future<bool> sayHello() async {
    final url = ('$baseUrl/projects/sayhello');
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to say hello');
    }
  }

  // Fetch all journals
  Future<List<T>> getAllItems() async {
    final response = await http.get(Uri.parse('$baseUrl/projects/findAll'));
    if (response.statusCode == 200) {
      return this.fromJsonFactory(response.body);
    } else {
      throw Exception('Failed to load journals');
    }
  }

  // Find journals by title
  Future<List<T>> findItemsByTitle(String title) async {
    final response = await http.get(Uri.parse('$baseUrl/projects/projects/findBy?title=$title'));
    if (response.statusCode == 200) {
      return this.fromJsonFactory(response.body);
    } else {
      throw Exception('Failed to find journals by title');
    }
  }

  Future<T> findItemById(String id) async {
    final response = await http.get(Uri.parse('$baseUrl/projects/findById/$id'));
    if (response.statusCode == 200) {
      return this.fromJsonFactory(response.body);
    } else {
      throw Exception('Failed to find journals by title');
    }
  }

  // Create a new journal
  Future<T> createItem(T item) async {
    final str = this.toJsonFactory(item);
    final endpoint = ('$baseUrl/projects/addOne');
    final response = await http.post(
      Uri.parse(endpoint),
      headers: {'Content-Type': 'application/json'},
      body:this.toJsonFactory(item),
    );
    if (response.statusCode == 200) {
      return this.fromJsonFactory(response.body);
    } else {
      throw Exception('Failed to create journal ${response.statusCode}.');
    }
  }

  // Update an existing journal
  Future<T> updateItem(T journal) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/projects/update'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(journal.toJson()),
      );
      if (response.statusCode == 200) {
        final vo =  this.fromJsonFactory(response.body);
        return vo;
      } else {
        throw Exception(
            'Failed to update journal : ${response.statusCode}, ${response.body}');
      }
    } catch (e) {
      throw Exception('Failed to update journal: $e');
    }
  }

  // Delete a journal by ID
  Future<bool> deleteItemById(String id) async {
    print('deleteing');
    final response = await http.delete(Uri.parse('$baseUrl/projects/deleteById/$id'));
    if (response.statusCode == 200) {
      return Future.value(true);
    } else {
      throw Exception('Failed to delete journal ${response.body}.');
    }
  }

  // Filter journals based on criteria
  Future<List<T>> filterItems(Map<String, dynamic> criteria) async {
    throw UnimplementedError('Filtering not implemented or tested');
    final response = await http.post(
      Uri.parse('$baseUrl/projectsfilterItems'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(criteria),
    );
    if (response.statusCode == 200) {
      return this.fromJsonFactory(response.body);
    } else {
      throw Exception('Failed to filter journals');
    }
  }
}
