


import 'http_crud_api.dart';

/// T is the entity type
/// U is the value object type
abstract class CrudRepository<T extends EntityMappable,V extends ValueObjectMappable> {
  Future<List<T>> getAllItems();
  Future<List<T>> findItemsByTitle(String title);
  Future<List<T>>  createItem(T entity);
  Future<List<T>> updateItem(T entity);
  Future<List<T>>  deleteItemById(String id);
  Future<List<T>> filterItems(Map<String, dynamic> criteria);
}


abstract interface class ValueObjectMappable {
  Map<String, dynamic> toJson();
 ValueObjectMappable fromJson(Map<String, dynamic> item );
  String? get id;
}

abstract interface class EntityMappable {
  ValueObjectMappable toVo();
  dynamic copyWith(args);
}



// entity_repository_impl.dart


class CrudRepositoryImpl<T extends EntityMappable, U extends ValueObjectMappable> implements CrudRepository {
  final ICrudHttpApi api;
  final U Function(Map<String,dynamic>) voFromJsonFn ;
  final T Function(U) entityFromVoFn ;

  CrudRepositoryImpl(
      {required this.api,
      required this.voFromJsonFn,
      required this.entityFromVoFn});
 

  @override
  Future<List<T>> getAllItems() async {
    final entities = await api.getAllItems() as List<U>;
    return entities.map((item) => entityFromVoFn( item)).toList();
  }

  @override
  Future<List<T>> findItemsByTitle(String title) async {
    final  entities = await api.findItemsByTitle(title) as List<U>;
     return entities.map((item) => entityFromVoFn(item)).toList();
  }

  @override
  Future<List<T>> createItem(EntityMappable entity)async {
    final  ent =  await api.createItem(entity.toVo()) as List<U>;
    return ent.map((json) => entityFromVoFn( json)).toList();
  }

  @override

  Future<List<T>> updateItem(EntityMappable entity) async {
    final ValueObjectMappable vos = await api.updateItem(entity.toVo());
    final entities =  entityFromVoFn(vos as U);
    return [entities];
  }


  @override
  Future<List<T>>  deleteItemById(String id) async {
    return await api.deleteItemById(id as String) as List<T>;
  }

  @override
  Future<List<T>> filterItems(Map<String, dynamic> criteria) async {
    final List entities = await api.filterItems(criteria);
    return entities.map((vo) => entityFromVoFn(vo)).toList();
  }


}
