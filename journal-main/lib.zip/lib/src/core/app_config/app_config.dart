class ValidateJson {
  dynamic _altValue;
  final Map<String, dynamic> _fragment;
  final String _key;
  dynamic _value;

  /// Factory constructor to create an instance of `ValidateJson`.
  ///
  /// Example:
  /// ```dart
  /// Map<String, dynamic> json = {"isCorrect": true};
  /// ValidateJson validator = ValidateJson.inst(fragment: json, key: "isCorrect");
  /// ```
  factory ValidateJson.inst({
    dynamic altValue,
    required Map<String, dynamic> fragment,
    required String key,
  }) {
    return ValidateJson._(
      altValue: altValue,
      fragment: fragment,
      key: key,
    );
  }

  ValidateJson._({
    dynamic altValue,
    required Map<String, dynamic> fragment,
    required String key,
  })  : _altValue = altValue,
        _fragment = fragment,
        _key = key {
    _value = fragment.containsKey(key) ? fragment[key] : altValue;
    if (_value == null) {
      throw ValidationException("Key not found and no alternative value provided: '$key'");
    }
  }

  dynamic get value => _value;

  /// Validates if the value is a number.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "percentage").isNumber().value;
  /// ```
  ValidateJson isNumber() {
    if (_value is! num) throw ValidationException("Expected number, got: $_value");
    return this;
  }

  /// Validates if the value is an integer.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "count").isInt().value;
  /// ```
  ValidateJson isInt() {
    if (_value is! int) throw ValidationException("Expected int, got: $_value");
    return this;
  }

  /// Validates if the value is a double.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "percentage").isDouble().value;
  /// ```
  ValidateJson isDouble() {
    if (_value is! double) throw ValidationException("Expected double, got: $_value");
    return this;
  }

  /// Validates if the value is a string.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "answer").isString().value;
  /// ```
  ValidateJson isString() {
    if (_value is! String) throw ValidationException("Expected string, got: $_value");
    return this;
  }

  /// Validates if the value is a boolean.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "isCorrect").isBool().value;
  /// ```
  ValidateJson isBool() {
    if (_value is! bool) throw ValidationException("Expected bool, got: $_value");
    return this;
  }

  /// Validates if the value is a list.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "items").isList().value;
  /// ```
  ValidateJson isList() {
    if (_value is! List) throw ValidationException("Expected list, got: $_value");
    return this;
  }

  /// Validates if the value is a map.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "data").isMap().value;
  /// ```
  ValidateJson isMap() {
    if (_value is! Map) throw ValidationException("Expected map, got: $_value");
    return this;
  }

  /// Validates if the value is not null.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "answer").isNotNull().value;
  /// ```
  ValidateJson isNotNull() {
    if (_value == null) throw ValidationException("Value is null");
    return this;
  }

  /// Validates if the value is a DateTime object.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "createdOn").isDateTime().value;
  /// ```
  ValidateJson isDateTime() {
    if (_value is! DateTime) throw ValidationException("Expected DateTime, got: $_value");
    return this;
  }

  /// Validates if the value is a valid DateTime string.
  ///
  /// Example:
  /// ```dart
  /// ValidateJson.inst(fragment: json, key: "createdOn").isDateTimeString().asDateTime();
  /// ```
  ValidateJson isDateTimeString() {
    try {
      DateTime.parse(_value);
    } on FormatException {
      if (_altValue != null) {
        try {
          DateTime.parse(_altValue);
          _value = _altValue;
        } on FormatException {
          throw ValidationException("Invalid DateTime string for both value and altValue");
        }
      } else {
        throw ValidationException("Invalid DateTime string and no alternative provided");
      }
    }
    return this;
  }

  DateTime get asDateTime => DateTime.parse(_value);
}
class ValidationException implements Exception {
  final String message;

  ValidationException(this.message);

  @override
  String toString() {
    return "ValidationException: $message";
  }
}


typedef JSON = Map<String, dynamic>;
typedef JSONList = List<JSON>;