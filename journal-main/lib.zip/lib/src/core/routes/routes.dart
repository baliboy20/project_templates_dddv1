import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:journal_macos/src/features/dev_journal/data/models/dev_journal.model.dart';
import 'package:journal_macos/src/features/projects/presentation/screens/projects_screen.dart';
import 'package:journal_macos/src/features/snippets/presentation/screens/SnippetScreen.dart'
    as snip;

import '../../features/home/presentation/screens/screens.dart' as home;
import '../../features/dev_journal/presentation/screens/screens.dart' as dev;
import '../../features/journals/presentation/screens/journalscreen.dart';
import '../../features/tasks/presentation/screens/task_screeen.dart';

class AppRouter {
  static Route onGenerateRoute(RouteSettings settings) {
    print('Route: ${settings.name}');
    switch (settings.name) {
      case '/':
        return home.HomeScreen.genRoute();
      case JournalScreen.routeName:
        return JournalScreen.genRoute();
      case '/home':
        return home.HomeScreen.genRoute();
      case dev.DevJournalBlogScreen.routeName:
        return dev.DevJournalBlogScreen.genRoute();
      case snip.SnippetsScreen.routeName:
        return snip.SnippetsScreen.genRoute();
      case TaskScreen.routeName:
        return TaskScreen.genRoute();
      case ProjectsScreen.routeName:
        return ProjectsScreen.genRoute();
      default:
        {
          log('error route from default fired ${settings.name}');
          return _errorRoute();
        }
    }
  }

  static Route _errorRoute() {
    return MaterialPageRoute(
      settings: const RouteSettings(name: '/error'),
      builder: (_) => Scaffold(
        appBar: AppBar(
          title: const Text('Error'),
        ),
        body: const Center(
          child: Text(
              'Something went wrong! (has the route been added to AppRouter?)'),
        ),
      ),
    );
  }
}
