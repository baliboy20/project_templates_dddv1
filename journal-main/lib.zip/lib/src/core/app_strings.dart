class AppSettings {
  AppSettings._();

  static const String title = "ddd_app_outline";
  static const serverUrl = 'http://localhost:3010';
}