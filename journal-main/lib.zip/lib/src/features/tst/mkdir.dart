import 'dart:io';

void main() async {
  final rootDir = Directory('./projects_feature');
  if (!await rootDir.exists()) {
    await rootDir.create();
  }

  final folders = [
    'bloc',
    'models',
    'repository',
    'screens',
    'widgets',
  ];

  final files = {
    'bloc/project_bloc.dart': 'class ProjectBloc {}',
    'bloc/project_event.dart': 'abstract class ProjectEvent {}',
    'bloc/project_state.dart': 'abstract class ProjectState {}',
    'models/project_entity.dart': '''
class ProjectEntity {
  final String id;
  final String projectName;
  final String description;
  final List<String> snippetsId;
  final List<String> taskId;
  final List<String> journalId;
  final String projectStatus;
  final String projectPath;

  ProjectEntity({
    required this.id,
    required this.projectName,
    required this.description,
    required this.snippetsId,
    required this.taskId,
    required this.journalId,
    required this.projectStatus,
    required this.projectPath,
  });
}''',
    'repository/project_repository.dart': '''
class ProjectRepository {
  // Repository logic for projects
}''',
    'screens/projects_screen.dart': '''
import 'package:flutter/material.dart';

class ProjectsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Projects'),
      ),
      body: Center(child: Text('Projects List')),
    );
  }
}''',
    'widgets/project_item.dart': '''
import 'package:flutter/material.dart';

class ProjectItem extends StatelessWidget {
  final String projectName;
  ProjectItem({required this.projectName});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(projectName),
    );
  }
}''',
  };

  for (final folder in folders) {
    final dir = Directory('${rootDir.path}/$folder');
    if (!await dir.exists()) {
      await dir.create();
    }
  }

  for (final filePath in files.keys) {
    final file = File('${rootDir.path}/$filePath');
    if (!await file.exists()) {
      await file.create(recursive: true);
      await file.writeAsString(files[filePath]!);
    }
  }

  print('Projects feature folder structure has been created at ${rootDir.path}');
}
