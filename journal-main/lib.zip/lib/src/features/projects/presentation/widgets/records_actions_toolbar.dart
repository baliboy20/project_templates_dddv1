import 'package:flutter/material.dart';

/**
 * ###Animated toolbar:###
 * #### Display record edit action buttons.####
 */
class DeleteToolbar extends StatefulWidget {

  final Function removeItem;

  DeleteToolbar(
      {super.key,

      required this.removeItem});

  @override
  State<DeleteToolbar> createState() => _DeleteToolbarState();
}

class _DeleteToolbarState extends State<DeleteToolbar> {
  bool isMinnimal = true;
  double iconSize = 13;
  Color iconColor = Colors.black38;
  double splasRadius = 12;

  @override
  Widget build(BuildContext context) {
    return Material(
      child: ColoredBox(
        color: Colors.blueGrey.shade50,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[

            AnimatedCrossFade(
              excludeBottomFocus: true,
              alignment: Alignment.center,
              firstCurve: Curves.easeIn,
              secondCurve: Curves.easeIn,
              reverseDuration: Duration(milliseconds: 100),
              duration: const Duration(milliseconds: 350),
              firstChild: MouseRegion(
                onEnter: (i) => setState(() => isMinnimal = !isMinnimal),
                child: IconButton(
                    icon: Icon(
                      Icons.more_vert,
                      size: iconSize,
                      color: iconColor,
                    ),
                    onPressed: () => setState(
                          () => isMinnimal = !isMinnimal,
                        )),
              ),
              secondChild: Container(
                width: 90,
                child: MouseRegion(
                  // onExit: (i) => print('hello'),
                  onExit: (i) => setState(() => isMinnimal = !isMinnimal),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                          child: IconButton(
                              splashRadius: splasRadius,
                             // tooltip: "Remove",
                              icon: Icon(Icons.delete,
                                  size: iconSize + 3, color: iconColor),
                              onPressed: () => widget.removeItem())),
                    ],
                  ),
                ),
              ),
              crossFadeState: isMinnimal
                  ? CrossFadeState.showFirst
                  : CrossFadeState.showSecond,
            ),
          ],
        ),
      ),
    );
  }
}



class RecordsActionsToolbar extends StatefulWidget {
  final Function additem;
  final Function amendItem;
  final Function removeItem;

  RecordsActionsToolbar(
      {super.key,
        required this.additem,
        required this.amendItem,
        required this.removeItem});

  @override
  State<RecordsActionsToolbar> createState() => _RecordsActionsToolbarState();
}

class _RecordsActionsToolbarState extends State<RecordsActionsToolbar> {
  bool isMinnimal = true;
  double iconSize = 13;
  Color iconColor = Colors.black38;
  double splasRadius = 12;

  @override
  Widget build(BuildContext context) {
    return Material(
      child: ColoredBox(
        color: Colors.blueGrey.shade50,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[
            IconButton(icon: Icon(Icons.line_style), onPressed: ()=> null,),
            AnimatedCrossFade(
              excludeBottomFocus: true,
              alignment: Alignment.center,
              firstCurve: Curves.easeIn,
              secondCurve: Curves.easeIn,
              reverseDuration: Duration(milliseconds: 100),
              duration: const Duration(milliseconds: 350),
              firstChild: MouseRegion(
                onEnter: (i) => setState(() => isMinnimal = !isMinnimal),
                child: IconButton(
                    icon: Icon(
                      Icons.edit,
                      size: iconSize,
                      color: iconColor,
                    ),
                    onPressed: () => setState(
                          () => isMinnimal = !isMinnimal,
                    )),
              ),
              secondChild: Container(
                width: 90,
                child: MouseRegion(
                  // onExit: (i) => print('hello'),
                  onExit: (i) => setState(() => isMinnimal = !isMinnimal),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Expanded(
                          child: IconButton(
                              splashRadius: splasRadius,
                              tooltip: "Add",

                              icon: Icon(Icons.add,
                                  size: iconSize + 3, color: iconColor),
                              onPressed: () => widget.additem())),
                      Expanded(
                          child: IconButton(
                              splashRadius: splasRadius,
                              tooltip: "Amend",
                              icon: Icon(Icons.edit_note,
                                  size: iconSize + 3, color: iconColor),
                              onPressed: () => widget.amendItem())),
                      Expanded(
                          child: IconButton(
                              splashRadius: splasRadius,
                              tooltip: "Remove",
                              icon: Icon(Icons.delete,
                                  size: iconSize + 3, color: iconColor),
                              onPressed: () => widget.removeItem())),
                    ],
                  ),
                ),
              ),
              crossFadeState: isMinnimal
                  ? CrossFadeState.showFirst
                  : CrossFadeState.showSecond,
            ),
          ],
        ),
      ),
    );
  }
}



