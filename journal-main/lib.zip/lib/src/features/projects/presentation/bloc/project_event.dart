import 'package:equatable/equatable.dart';

import '../../domain/entities/project_entity.dart';




abstract class ProjectEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadProjects extends ProjectEvent {}

class DeleteProject extends ProjectEvent {
  final String id;
  DeleteProject(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectProject extends ProjectEvent {
  final String id;
  SelectProject(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends ProjectEvent {
  final ProjectEntity project;
  final bool isNew;
  SaveChanges(this.project, this.isNew);

  @override
  List<Object?> get props => [project];
}
