import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/features/projects/domain/repositories/project_repository.dart';
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_event.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_state.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';
import '../../domain/entities/project_entity.dart';

class ProjectBloc extends Bloc<ProjectEvent, ProjectState> {
  final List<ProjectEntity> items = [];
  final ProjectRepositoryImpl repository;

  ProjectBloc({required this.repository}) : super(Loading()) {
    on<LoadProjects>(_onLoadProjects);
    on<DeleteProject>(_onDeleteProject);
    on<SelectProject>(_onSelectProject);
    on<SaveChanges>(_onSaveChanges);
  }

  void _onLoadProjects(LoadProjects event, Emitter<ProjectState> emit) async {
    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    final List<ProjectEntity> items = await repository.getAllItems();
    emit(ProjectsLoaded(items..sort((a, b) => b.id.compareTo(a.id))));
  }

  void _onDeleteProject(DeleteProject event, Emitter<ProjectState> emit) async {
    try {
      print('Deleting project with id: ${event.id}');
      await repository.deleteItemById(event.id);
      final List<ProjectEntity> items = await repository.getAllItems();
      emit(ProjectsLoaded(items));
    } catch (e) {
      emit(ProjectError('Failed: $e'));
    }
  }

  void _onSelectProject(SelectProject event, Emitter<ProjectState> emit) {
    final selectedProject = items.firstWhere(
          (project) => project.id == event.id,
      orElse: () => ProjectEntity(
        id: '',
        projectName: '',
        description: '',
        snippetsId: [],
        taskId: [],
        journalId: [],
        projectStatus: '',
        projectPath: '',
      ),
    );
    emit(ProjectSelectedForChanging(selectedProject));
  }

  void _onSaveChanges(SaveChanges event, Emitter<ProjectState> emit) async {
    emit(ProjectSaving());
    try {
      if(event.isNew){
        await repository.createItem(event.project);
        emit(ProjectNotification('New project created'));
      } else {
        final reply = await repository.updateItem(event.project);
        emit(ProjectNotification('Changes saved'));
        final List<ProjectEntity> items = await repository.getAllItems();
        emit(ProjectsLoaded(items));
      }
    } catch (e) {
      emit(ProjectError('Failed: $e'));
      await Future.delayed(Duration(milliseconds: 500));
      final List<ProjectEntity> items = await repository.getAllItems();
      emit(ProjectsLoaded(items));
    }
  }
}
