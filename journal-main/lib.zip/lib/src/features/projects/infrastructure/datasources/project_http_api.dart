
import 'dart:convert';

import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';

import '../mappers/json_projectvo_mappers.dart';

class ProjectHttpApi extends CrudHttpApiImpl<ProjectVo> {

  // static   dynamic _decodeJsonList( String jsonStr) {
  //   final json = JsonVoMapper.jsonDecode(jsonStr);
  //   if (json is Map<String,dynamic>) {
  //     return ProjectVo.fromJson(json);
  //   } else if(json is List) {
  //     return json.map((e)=> ProjectVo.fromJson(e)).toList();
  //   } else
  //   throw Exception('Failed to decode json from string $json');
  // }
  //
  // static String _encodeValueObjectMappable(dynamic vos) {
  //   if(vos is List<ProjectVo>) {
  //     return jsonEncode(vos.map((e) => e.toJson()).toList());
  //   } else if(vos is ProjectVo){
  //     return jsonEncode(vos.toJson());
  //   } else
  //   throw Exception('Failed to encode ValueObjectMappable $vos');
  // }

  ProjectHttpApi(baseUrl) : super(
      fromJsonFactory: JsonProjectVoMapper.decodeJsonList,
      toJsonFactory: JsonProjectVoMapper.encodeProjectVo,
      baseUrl: baseUrl);

  @override
  Future<List<ProjectVo>> filterItems(Map<String, dynamic> criteria) {
    return super.filterItems(criteria);
  }

  @override
  Future<bool> deleteItemById(String id) {
   return super.deleteItemById(id);
  }

  @override
  Future<ProjectVo> findItemById(String id) async {
    return super.findItemById(id);
  }

  @override
  Future<ProjectVo> updateItem(ProjectVo vo) {
    return super.updateItem(vo);
  }

  @override
  Future<ProjectVo> createItem(ProjectVo vo) {
    return super.createItem(vo);
  }

  @override
  Future<List<ProjectVo>> findItemsByTitle(String title) {
    return super.findItemsByTitle(title);
  }

  @override
  Future<List<ProjectVo>> getAllItems() {
   return super.getAllItems();
  }

  @override
  Future<bool> sayHello() {
    return super.sayHello();
  }
}