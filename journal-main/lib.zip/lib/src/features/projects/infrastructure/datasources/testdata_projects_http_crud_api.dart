//
// import '../../../../../generic_crud/repository/http_crud_api.dart';
// import '../../domain/entities/project_entity.dart';
// import '../models/project_vo.dart';
// import '../../../../../generic_crud/repository/crud_repository.dart';
//
// class DummyProjectCrudHttpApi<T extends ValueObjectMappable> implements ICrudHttpApi {
//   final String baseUrl;
//   List<ProjectVo> _items = [];
//
//   DummyProjectCrudHttpApi({this.baseUrl = 'http://localhost:3001/projects'}) {
//     // Load initial test data
//     print('initializing DummyCrudHttpApi');
//     _items = testProjectsVo.sublist(0);
//   }
//
//   Future<bool> sayHello() async {
//     print('Hello from Dummy API');
//     return Future.value(true);
//   }
//
//   Future<List<T>> getAllItems() async {
//     print('Fetching all items...');
//     return Future.value(_items as List<T>);
//   }
//
//   Future<List<T>> findItemsByTitle(String title) async {
//     print('Finding items by title: $title');
//     final filteredItems = _items
//         .where((item) => item.projectName.toLowerCase().contains(title.toLowerCase()))
//         .toList() as List<T>;
//     return Future.value(filteredItems);
//   }
//
//
//
//   Future<List<T>> createItem( ValueObjectMappable item) async {
//     print('Creating new item: ${item.toJson()}');
//     final newItem = ProjectVo.fromJson(item.toJson());
//     _items.add(newItem);
//     return Future.value(_items as List<T>);
//   }
//
//   Future<List<T>> updateItem(ValueObjectMappable item) async {
//     print('Updating item: ${item.toJson()}');
//     //final updatedItem = ProjectVo.fromJson(item.toJson());
//     final index = _items.indexWhere((existing) => existing.id == item!.id);
//     if (index != -1) {
//       _items[index] = item as ProjectVo;
//       return Future.value(_items as List<T>);
//     } else {
//       _items.add(item as ProjectVo);
//       return Future.value(_items as List<T>);
//     }
//   }
//
//   Future<bool> deleteItemById(String id) async {
//     print('Deleting item with ID: $id');
//     final index = _items.indexWhere((item) => item.id == id);
//     if (index != -1) {
//       final retval = _items.removeAt(index);
//       return retval != null;
//     } else {
//       throw Exception('Item with ID $id not found.');
//     }
//   }
//
//   Future<List<T>> filterItems(Map<String, dynamic> criteria) async {
//     print('Filtering items with criteria: $criteria');
//     List<ProjectVo> filteredItems = _items;
//
//     if (criteria.containsKey('status')) {
//       filteredItems = filteredItems
//           .where((item) => item.projectStatus == criteria['status'])
//           .toList();
//     }
//     if (criteria.containsKey('path')) {
//       filteredItems = filteredItems
//           .where((item) => item.projectPath.contains(criteria['path']))
//           .toList();
//     }
//
//     return Future.value(filteredItems.map((item) => item.toJson()).toList() as List<T>);
//   }
//
//   @override
//   Future<ValueObjectMappable> findItemById(String id) {
//     // TODO: implement findItemById
//     throw UnimplementedError();
//   }
// }
//
//
//
//
// const List<ProjectVo> testProjectsVo = [
//   ProjectVo(
//     projectName: 'Project Alpha',
//     description: 'Description for Project Alpha',
//     snippetsId: ['snippet1', 'snippet2'],
//     taskId: ['task1', 'task2'],
//     journalId: ['journal1'],
//     projectStatus: 'Active',
//     projectPath: '/projects/alpha',
//     id: '1',
//   ),
//   ProjectVo(
//     projectName: 'Project Beta',
//     description: 'Description for Project Beta',
//     snippetsId: ['snippet3'],
//     taskId: ['task3', 'task4'],
//     journalId: ['journal2'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/beta',
//     id: '2',
//   ),
//   ProjectVo(
//     projectName: 'Project Gamma',
//     description: 'Description for Project Gamma',
//     snippetsId: ['snippet5'],
//     taskId: ['task6'],
//     journalId: ['journal3', 'journal4'],
//     projectStatus: 'On Hold',
//     projectPath: '/projects/gamma',
//     id: '3',
//   ),
//   ProjectVo(
//     projectName: 'Project Delta',
//     description: 'Description for Project Delta',
//     snippetsId: ['snippet7', 'snippet8', 'snippet9'],
//     taskId: ['task8'],
//     journalId: [],
//     projectStatus: 'Active',
//     projectPath: '/projects/delta',
//     id: '4',
//   ),
//   ProjectVo(
//     projectName: 'Project Epsilon',
//     description: 'Description for Project Epsilon',
//     snippetsId: ['snippet10'],
//     taskId: [],
//     journalId: ['journal5'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/epsilon',
//     id: '5',
//   ),
//   ProjectVo(
//     projectName: 'Project Zeta',
//     description: 'Description for Project Zeta',
//     snippetsId: [],
//     taskId: ['task11', 'task12'],
//     journalId: [],
//     projectStatus: 'On Hold',
//     projectPath: '/projects/zeta',
//     id: '6',
//   ),
//   ProjectVo(
//     projectName: 'Project Eta',
//     description: 'Description for Project Eta',
//     snippetsId: ['snippet12', 'snippet13'],
//     taskId: [],
//     journalId: ['journal6', 'journal7'],
//     projectStatus: 'Active',
//     projectPath: '/projects/eta',
//     id: '7',
//   ),
//   ProjectVo(
//     projectName: 'Project Theta',
//     description: 'Description for Project Theta',
//     snippetsId: [],
//     taskId: ['task13'],
//     journalId: ['journal8'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/theta',
//     id: '8',
//   ),
//   ProjectVo(
//     projectName: 'Project Iota',
//     description: 'Description for Project Iota',
//     snippetsId: ['snippet15'],
//     taskId: [],
//     journalId: [],
//     projectStatus: 'Active',
//     projectPath: '/projects/iota',
//     id: '9',
//   ),
//   ProjectVo(
//     projectName: 'Project Kappa',
//     description: 'Description for Project Kappa',
//     snippetsId: ['snippet16', 'snippet17'],
//     taskId: ['task15'],
//     journalId: ['journal9', 'journal10'],
//     projectStatus: 'On Hold',
//     projectPath: '/projects/kappa',
//     id: '10',
//   ),
//   ProjectVo(
//     projectName: 'Project Lambda',
//     description: 'Description for Project Lambda',
//     snippetsId: ['snippet18'],
//     taskId: [],
//     journalId: [],
//     projectStatus: 'Active',
//     projectPath: '/projects/lambda',
//     id: '11',
//   ),
//   ProjectVo(
//     projectName: 'Project Mu',
//     description: 'Description for Project Mu',
//     snippetsId: ['snippet19'],
//     taskId: ['task16', 'task17'],
//     journalId: [],
//     projectStatus: 'Completed',
//     projectPath: '/projects/mu',
//     id: '12',
//   ),
//   ProjectVo(
//     projectName: 'Project Nu',
//     description: 'Description for Project Nu',
//     snippetsId: [],
//     taskId: ['task18'],
//     journalId: ['journal11'],
//     projectStatus: 'Active',
//     projectPath: '/projects/nu',
//     id: '13',
//   ),
//   ProjectVo(
//     projectName: 'Project Xi',
//     description: 'Description for Project Xi',
//     snippetsId: ['snippet20', 'snippet21'],
//     taskId: [],
//     journalId: [],
//     projectStatus: 'On Hold',
//     projectPath: '/projects/xi',
//     id: '14',
//   ),
//   ProjectVo(
//     projectName: 'Project Omicron',
//     description: 'Description for Project Omicron',
//     snippetsId: [],
//     taskId: ['task20'],
//     journalId: ['journal12'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/omicron',
//     id: '15',
//   ),
//   ProjectVo(
//     projectName: 'Project Pi',
//     description: 'Description for Project Pi',
//     snippetsId: [],
//     taskId: [],
//     journalId: ['journal13', 'journal14'],
//     projectStatus: 'Active',
//     projectPath: '/projects/pi',
//     id: '16',
//   ),
//   ProjectVo(
//     projectName: 'Project Rho',
//     description: 'Description for Project Rho',
//     snippetsId: ['snippet22'],
//     taskId: ['task21', 'task22'],
//     journalId: [],
//     projectStatus: 'On Hold',
//     projectPath: '/projects/rho',
//     id: '17',
//   ),
//   ProjectVo(
//     projectName: 'Project Sigma',
//     description: 'Description for Project Sigma',
//     snippetsId: [],
//     taskId: [],
//     journalId: ['journal15'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/sigma',
//     id: '18',
//   ),
//   ProjectVo(
//     projectName: 'Project Tau',
//     description: 'Description for Project Tau',
//     snippetsId: ['snippet23'],
//     taskId: ['task23'],
//     journalId: [],
//     projectStatus: 'Active',
//     projectPath: '/projects/tau',
//     id: '19',
//   ),
//   ProjectVo(
//     projectName: 'Project Upsilon',
//     description: 'Description for Project Upsilon',
//     snippetsId: ['snippet24', 'snippet25'],
//     taskId: [],
//     journalId: ['journal16'],
//     projectStatus: 'Completed',
//     projectPath: '/projects/upsilon',
//     id: '20',
//   ),
// ];
//
//
// List<ProjectEntity> testProjectsEntity = testProjectsVo
//     .map((projectVo) => ProjectEntity.fromVo(projectVo))
//     .toList();
//
