import 'package:bson/bson.dart';
import 'package:equatable/equatable.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';


class ProjectVo extends Equatable implements ValueObjectMappable {
  final String projectName;
  final String description;
  final List<String> snippetsId;
  final List<String> taskId;
  final List<String> journalId;
  final String projectStatus;
  final String projectPath;
  final String? id;

  const ProjectVo({
    required this.projectName,
    required this.description,
    required this.snippetsId,
    required this.taskId,
    required this.journalId,
    required this.projectStatus,
    required this.projectPath,
    this.id,
  });

  /// Factory constructor to create an instance from JSON.
  factory ProjectVo.fromJson(Map<String, dynamic> json) {
    String idstr;
    if(json['_id'] is ObjectId) {
      idstr = (json['_id'] as ObjectId).toHexString();
    } else if(json['_id'] is String) {
      idstr = json['_id'];
    } else {
      idstr = '';
    }
    return ProjectVo(
      projectName: json['projectName'] ?? '',
      description: json['description'] ?? '',
      snippetsId: List<String>.from(json['snippetsId'] ?? []),
      taskId: List<String>.from(json['taskId'] ?? []),
      journalId: List<String>.from(json['journalId'] ?? []),
      projectStatus: json['projectStatus'] ?? '',
      projectPath: json['projectPath'] ?? '',
      id: idstr,
    );
  }

  /// Converts the object to JSON.
  Map<String, dynamic> toJson() {
    return {
      'projectName': projectName,
      'description': description,
      'snippetsId': snippetsId,
      'taskId': taskId,
      'journalId': journalId,
      'projectStatus': projectStatus,
      'projectPath': projectPath,
      'id': id ?? '',
    };
  }

  /// Static method to create a new instance with default values.
  static ProjectVo newInstance() {
    return ProjectVo(
      projectName: '',
      description: '',
      snippetsId: [],
      taskId: [],
      journalId: [],
      projectStatus: '',
      projectPath: '',
      id: null,
    );
  }

  /// Concatenates fields into a single string.
  String concatenateFields() {
    return '$projectName$description${snippetsId.join()}${taskId.join()}${journalId.join()}$projectStatus$projectPath';
  }

  /// Override the `props` for Equatable comparison.
  @override
  List<Object?> get props => [
    projectName,
    description,
    snippetsId,
    taskId,
    journalId,
    projectStatus,
    projectPath,
    id,
  ];

  /// Implements the `fromJson` method required by `ValueObjectMappable`.
  @override
  ProjectVo fromJson(Map<String, dynamic> json) {
    return ProjectVo.fromJson(json);
  }
}
