import '../../../../../generic_crud/repository/crud_repository.dart';
import '../../infrastructure/models/project_vo.dart';
import '../entities/project_entity.dart';

class ProjectRepositoryImpl extends CrudRepositoryImpl<ProjectEntity, ProjectVo> {

  ProjectRepositoryImpl( {required super.api,
      required super.voFromJsonFn,
      required super.entityFromVoFn});

  @override
  Future<List<ProjectEntity>> getAllItems() async {
    return super.getAllItems();
  }

  @override
  Future<List<ProjectEntity>> findItemsByTitle(String title) async {
    return super.findItemsByTitle(title);
  }

  @override
  Future<List<ProjectEntity>> createItem(EntityMappable entity) async {
    return super.createItem(entity);
  }

  @override
  Future<List<ProjectEntity>> updateItem(EntityMappable entity) async {
     return super.updateItem(entity);
  }

  @override
  Future<List<ProjectEntity>> deleteItemById(String id) async {
    final resp = await api.deleteItemById(id);
    return await getAllItems();
  }

  @override
  Future<List<ProjectEntity>> filterItems(Map<String, dynamic> criteria) async {
    return super.filterItems(criteria);
  }
}