import '../../../../../generic_crud/repository/crud_repository.dart';
import '../../infrastructure/models/project_vo.dart';

class ProjectEntity implements EntityMappable {
  final String id;
  final String projectName;
  final String description;
  final List<String> snippetsId;
  final List<String> taskId;
  final List<String> journalId;
  final String projectStatus;
  final String projectPath;

  ProjectEntity({
    required this.id,
    required this.projectName,
    required this.description,
    required this.snippetsId,
    required this.taskId,
    required this.journalId,
    required this.projectStatus,
    required this.projectPath,
  });

  @override
  copyWith(args) {
    return ProjectEntity(
      id: args['id'] ?? id,
      projectName: args['projectName'] ?? projectName,
      description: args['description'] ?? description,
      snippetsId: args['snippetsId'] ?? snippetsId,
      taskId: args['taskId'] ?? taskId,
      journalId: args['journalId'] ?? journalId,
      projectStatus: args['projectStatus'] ?? projectStatus,
      projectPath: args['projectPath'] ?? projectPath,
    );
  }

  @override
  ValueObjectMappable toVo() {
    return ProjectVo(
      id: id,
      projectName: projectName,
      description: description,
      snippetsId: snippetsId,
      taskId: taskId,
      journalId: journalId,
      projectStatus: projectStatus,
      projectPath: projectPath,
    );
  }

  factory ProjectEntity.empty() {
    return ProjectEntity(
      id: '',
      projectName: '',
      description: '',
      snippetsId: [],
      taskId: [],
      journalId: [],
      projectStatus: '',
      projectPath: '',
    );
  }
  factory ProjectEntity.fromVo(ProjectVo vo) {
    return ProjectEntity(
      id: vo.id ?? '',
      projectName: vo.projectName,
      description: vo.description,
      snippetsId: vo.snippetsId,
      taskId: vo.taskId,
      journalId: vo.journalId,
      projectStatus: vo.projectStatus,
      projectPath: vo.projectPath,
    );
  }
}