// task_events.dart
import '../../domain/entities/task_entity.dart';

abstract class TaskEvent {}

class LoadTasks extends TaskEvent {}

class DeleteTask extends TaskEvent {
  final String id;
  DeleteTask(this.id);
}

class SelectTask extends TaskEvent {
  final String id;
  SelectTask(this.id);
}

class SaveChanges extends TaskEvent {
  final TaskEntity task;
  SaveChanges(this.task);
}
