import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/features/tasks/domain/entities/task_entity.dart';

import '../../infrastructure/api/task_api.dart';
import '../../infrastructure/repo/task_repository_impl.dart';
import '../bloc/task_bloc.dart';
import '../bloc/task_events.dart';
import '../bloc/task_states.dart';


void main() {
  final LoadTasks loadTasks = LoadTasks();

  runApp(BlocProvider<TaskBloc>(
      create: (context) =>
      TaskBloc(repository: TaskRepositoryImpl(TaskApi(
        baseUrl: 'localhost:3010/tasks'
      )))
        ..add(loadTasks),
      child: TaskHome()));
}

class TaskHome extends StatelessWidget {
  const TaskHome({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: TaskScreen(),
    );
  }
}

class TaskScreen extends StatefulWidget {
  static const routeName = '/tasks';

  static const String routeLabel = 'Tasks';
  static MaterialPageRoute genRoute () {
    return MaterialPageRoute(
        settings: RouteSettings(name: routeName),
        builder: (_) => TaskScreen());
  }
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_rounded),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
      ),
      body: BlocBuilder<TaskBloc, TaskState>(builder: (context, state) {
        if (state is Loading) {
          return Text('loading');
        } else if (state is TasksLoaded) {
          return TasksLoadedView(tasks: state.tasks);
        } else if (state is TaskSaving) {
          return Text('saving');
        } else if (state is TaskSelectedForChanging) {
          return TaskEditForm(task: state.task);
        } else if (state is TaskError) {
          return Text('Error: ${state.message}');
        } else {
          return Text('super hi');
        }
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showBottomSheetNew(context, TaskEntity.empty());
        },
        child: Icon(Icons.add),
      ),
    );
  }

  _showBottomSheetNew(BuildContext context, TaskEntity task) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: TaskEditForm(task: TaskEntity.empty()),
        );
      },
    );
  }
}

class TasksLoadedView extends StatefulWidget {
  final List<TaskEntity> tasks;

  const TasksLoadedView({super.key, required this.tasks});

  @override
  State<TasksLoadedView> createState() => _TasksLoadedViewState();
}

class _TasksLoadedViewState extends State<TasksLoadedView> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: widget.tasks.length,
      itemBuilder: (context, index) {
        return ListTile(
          onLongPress: () {
            _showBottomSheet(context, widget.tasks[index]);
          },
          title: Text(widget.tasks[index].title),
          subtitle: SelectableText(widget.tasks[index].description),
        );
      },
    );
  }

  _showBottomSheet(BuildContext context, TaskEntity task) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
          child: TaskEditForm(task: task),
        );
      },
    );
  }
}

/// =====
/// TaskEditForm
///

class TaskEditForm extends StatefulWidget {
  final TaskEntity task;

  const TaskEditForm({super.key, required this.task});

  @override
  State<TaskEditForm> createState() => _TaskEditFormState();
}

class _TaskEditFormState extends State<TaskEditForm> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.task.title);
    _descriptionController = TextEditingController(text: widget.task.description);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(height: 20),
          TextField(
            controller: _titleController,
            decoration: InputDecoration(labelText: 'Task Title'),
          ),
          SizedBox(height: 20),
          TextField(
            controller: _descriptionController,
            decoration: InputDecoration(labelText: 'Task Description'),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  BlocProvider.of<TaskBloc>(context).add(SaveChanges(
                    TaskEntity(
                      id: widget.task.id,
                      title: _titleController.text,
                      description: _descriptionController.text,
                      userId: widget.task.userId,
                      category: widget.task.category,
                      projectId: '',

                    ),
                  ));
                  Navigator.pop(context); // Close the bottom sheet after saving
                },
                icon: Icon(Icons.save),
                label: Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: () async {
                  final confirmed = await _showDeleteConfirmationDialog(context);
                  if (confirmed) {
                    BlocProvider.of<TaskBloc>(context)
                        .add(DeleteTask(widget.task.id!));
                  }
                  Navigator.pop(context); // Close the bottom sheet after saving
                },
                icon: Icon(Icons.delete),
                label: Text('Delete'),
              ),
              SizedBox(height: 220),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context); // Close the bottom sheet without saving
                },
                icon: Icon(Icons.cancel),
                label: Text('Cancel'),
              ),
            ],
          )
        ],
      ),
    );
  }

  Future<bool> _showDeleteConfirmationDialog(BuildContext context) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text(
              'Are you sure you wish to delete this task? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false); // Dismisses the dialog without deleting
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(true); // Confirms the deletion
              },
              child: Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    ) ??
        false; // Return false if the dialog is dismissed without a selection
  }
}
