

import 'package:journal_macos/src/features/tasks/domain/entities/task_entity.dart';

typedef GroupedTasks = Map<DateTime, List<TaskEntity>>;
class groupTasksByDate {
  groupTasksByDate({
    required this.tasks,
  });

  final List<TaskEntity> tasks;

  GroupedTasks call() {
    final GroupedTasks grouped = {};

    for (final task in tasks) {
      final date = DateTime(task.createdOn!.year, task.createdOn!.month, task.createdOn!.day);
      if (grouped.containsKey(date)) {
        grouped[date]!.add(task);
      } else {
        grouped[date] = [task];
      }
    }
 final List<MapEntry<DateTime, List<TaskEntity>>> entries = grouped.entries.toList()..sort((a, b) => b.key.compareTo(a.key));
    return Map.fromEntries(entries);
  }
}