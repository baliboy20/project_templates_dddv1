// task_interface.dart

import '../entities/task_entity.dart';


abstract class TaskRepository {
  Future<List<TaskEntity>> getAllTasks();
  Future<TaskEntity> findTaskById(String id);
  Future<TaskEntity> createTask(TaskEntity task);
  Future<bool> updateTask(TaskEntity task);
  Future<bool> deleteTaskById(String id);
  Future<List<TaskEntity>> filterTasks(Map<String, dynamic> criteria);
}
