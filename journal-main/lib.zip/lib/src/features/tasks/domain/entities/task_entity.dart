// task_entity.dart
import 'package:bson/bson.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';

import '../../infrastructure/models/task_vo.dart';

enum ActionStatus { pending, completed, inProgress }
enum TaskPriority { high, normal, low }

/// ActionModification enum to indicate the type of modification to be made to an
/// action item.
enum ActionModification { add, remove, update }

/// ActionModifiers is a list of tuples containing the modification to be made.
typedef ActionModifiers = List<(ActionModification, ActionItem)>;


/// ActionItem is an interface class that defines the properties of an action item.
/// and is implemented by ActionItemModel and ActionDTO.
abstract interface class ActionItem {
  /// id, action, from, to, status
  String get id;
  String get action;
  DateTime get from;
  DateTime? get completeBy;
  ActionStatus get status;
  DateTime? get completedOn;

}

abstract interface class Task {
  /// id, description, from,to,status, actionItems,
  String get id;
  String get description;
  DateTime get from;
  DateTime get to;
  ActionStatus get status;
  List<ActionItem> get actionItems;
  TaskPriority get priority;

}


class ActionItemModel implements ActionItem {
  final String id;
  final String action;
  final DateTime from;
  final DateTime? completeBy;
  late  ActionStatus status;
  final DateTime? completedOn;

  ActionItemModel({
    required this.id,
    required this.action,
    required this.from,
    required this.completeBy,
    required this.status,
    required this.completedOn,
  });

  String completedByFormatted() {
    return completeBy != null ? '${completeBy!.day}-${completeBy!.month}-${completeBy!.year}' : '';
  }

  ActionItem copyWith(args) {
    throw UnimplementedError();
  }


}

extension TaskModelExtension on TaskEntity {
  TaskModel toModel() {
    return TaskModel(
      id: id ?? '',
      description: title,
      from: createdOn ?? DateTime.now(),
      to: createdOn ?? DateTime.now(),
      status: ActionStatus.pending,
      actionItems: [],
      priority: TaskPriority.normal,
    );
  }

}

/// replacement for TaskEntity
class TaskModel implements Task {
  final String id;
  final String description;
  final DateTime from;
  final DateTime to;
  final ActionStatus status;
  final List<ActionItemModel> actionItems;
  final TaskPriority priority;

  TaskModel({
    required this.id,
    required this.description,
    required this.from,
    required this.to,
    required this.status,
    required this.actionItems,
    required this.priority,
  });

  @override
  copyWith(args) {
    // TODO: implement copyWith
    throw UnimplementedError();
  }

  String fromFormatted() =>
  '${from.day}-${from.month}-${from.year}';
  String toFormatted() => '${to.day}-${to.month}-${to.year}';


  @override
  ValueObjectMappable toVo() {
    // TODO: implement toVo
    throw UnimplementedError();
  }
  void add(ActionItemModel item) {
    actionItems.add(item);
  }
  void remove(ActionItemModel item) {
    actionItems.remove(item);
  }

  void update(ActionItemModel item) {
    final index = actionItems.indexWhere((element) => element.id == item.id);
    if (index != -1) {
      actionItems[index] = item;
    }
  }

  ActionItemModel? findAction(String id) {
    return actionItems.firstWhere((element) => element.id == id);
  }
  List<ActionItemModel> outstandingActions( ) {
    return actionItems.where((element) => element.status != ActionStatus.completed).toList();
  }
  List<ActionItemModel> completedActions( ) {
    return actionItems.where((element) => element.status == ActionStatus.completed).toList();
  }
  List<ActionItemModel> lateActions( DateTime date) {
    return actionItems.where((element) => element.completeBy != null && element.completeBy!.isBefore(date)).toList();
  }


}





class TaskEntity {
  final String? id;
  final String title;
  final String description;
  final String userId;
  final String projectId;
  final String category;

  TaskEntity({
    required this.id,
    required this.title,
    required this.description,
    required this.userId,
    required this.projectId,
    required this.category,

  });

  DateTime? get createdOn => id != null ? ObjectId.fromHexString(id!).dateTime : null;

  /// Converts the TaskEntity instance to a TaskVo instance.
  TaskVo toVo() {
    return TaskVo(
      id: id ??  ObjectId(clientMode: true).toHexString(),
      title: title,
      description: description,
      userId: userId,
      projectId: projectId,
      category: category,
     // Assuming TaskVo has a string representation for createdOn
    );
  }

  factory TaskEntity.fromVo(TaskVo vo) {
    return TaskEntity(
      id: vo.id,
      title: vo.title,
      description: vo.description ?? '',
      userId: vo.userId,
      projectId: vo.projectId ?? '',
      category: vo.category,
    );
  }

  factory TaskEntity.empty() {
    return TaskEntity(
      id: null,
      title: '',
      description: '',
      userId: '',
      projectId: '',
      category: '',
    );
  }
}
