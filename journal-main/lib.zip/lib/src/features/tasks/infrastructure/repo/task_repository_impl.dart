// task_repository_impl.dar
import '../../domain/repositories/task_repository.dart';
import '../api/task_api.dart';
import '../models/task_vo.dart';
import '../../domain/entities/task_entity.dart' as ent;

class TaskRepositoryImpl implements TaskRepository {
  final TaskApi api;

  TaskRepositoryImpl(this.api);

  @override
  Future<List<ent.TaskEntity>> getAllTasks() async {
    final List<TaskVo> taskVos = await api.getAllItems(); // This still returns a List of TaskVo
    // Convert TaskVo to TaskEntity if necessary
    return taskVos.map((taskVo) => ent.TaskEntity.fromVo(taskVo)).toList();
  }

  @override
  Future<ent.TaskEntity> findTaskById(String id) async {
    final taskVo = await api.findItemById(id);
    return ent.TaskEntity.fromVo(taskVo);
  }

  @override
  Future<ent.TaskEntity> createTask(ent.TaskEntity task) async {
    final taskVo = task.toVo(); // Assuming a toVo method to convert TaskEntity to TaskVo
    final createdTaskVo = await api.createItem(taskVo); // This still returns a TaskVo
    return ent.TaskEntity.fromVo(createdTaskVo); // Convert to TaskEntity
  }

  @override
  Future<bool> updateTask(ent.TaskEntity task) async {
    final taskVo = task.toVo(); // Convert to TaskVo
    final result = await api.updateItem(taskVo); // This returns a boolean
    return result != null;
  }

  @override
  Future<bool> deleteTaskById(String id) async {
    final result = await api.deleteItemById(id); // This returns a boolean
    return result;
  }

  @override
  Future<List<ent.TaskEntity>> filterTasks(Map<String, dynamic> criteria) async {
    final taskVos = await api.filterItems(criteria); // This returns a List of TaskVo
    // Convert TaskVo to TaskEntity
    return taskVos.map((taskVo) => ent.TaskEntity.fromVo(taskVo)).toList();
  }
}
