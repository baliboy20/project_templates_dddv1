

import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/datasources/mappers/json_snippetvo_mappers.dart';


import '../models/task_vo.dart';



class TaskApi extends CrudHttpApiImpl<TaskVo> {


  TaskApi(
      {required String baseUrl}
      ):super(
    fromJsonFactory: JsonSnippetVoMapper.decodeJsonList,
    toJsonFactory: JsonSnippetVoMapper.encodeSnippetVo,
    baseUrl: baseUrl,
  );

  @override
  Future<TaskVo> createItem(TaskVo item) async{
    return super.createItem(item);
  }

  @override
  Future<bool> deleteItemById(String id) async{
    return super.deleteItemById(id);
  }

  @override
  Future<List<TaskVo>> filterItems(Map<String, dynamic> criteria) {
    return super.filterItems(criteria);
  }

  @override
  Future<TaskVo> findItemById(String id) {
    return super.findItemById(id);
  }

  @override
  Future<List<TaskVo>> findItemsByTitle(String title) {
    return super.findItemsByTitle(title);
  }

  @override
  Future<List<TaskVo>> getAllItems() {
    return super.getAllItems();
  }

  @override
  Future<bool> sayHello() {
    return super.sayHello();
  }

  @override
  Future<TaskVo> updateItem(TaskVo item) {
    return super.updateItem(item);
  }


}
