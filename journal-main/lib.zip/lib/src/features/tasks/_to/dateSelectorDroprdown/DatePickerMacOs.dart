import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

void main() {
  runApp(HomeScreen());
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Home Screen',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // late TextEditingController _descriptionController;

  @override
  initState() {
    super.initState();
    // _descriptionController = TextEditingController();
  }

  dispose() {
    // _descriptionController.dispose();
    super.dispose();
  }

  _onDateSelected(DateTime date) {
    print('outer callback the date selected is $date');
    setState(() {
      _selecteddate = date.formatted ?? '';
    });
  }

  late String _selecteddate = '';

  TextStyle _labelStyle(BuildContext context) {
    return Theme.of(context).textTheme.bodyMedium!.copyWith(
          color: Colors.black,
          fontWeight: FontWeight.bold,
        );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom Dropdown'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          height: MediaQuery.sizeOf(context).height - 50,
          color: Colors.yellow.shade100,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            spacing: 20,
            children: [
              Container(
                color: Colors.orange.shade100,
                height: 50,
                child: Transform.translate(
                  offset: Offset(0, 0),
                  child: DatePickerMacOs2(
                      alignment: Alignment.center,
                      onDateSelected: _onDateSelected),
                ),
              ),
              Flexible(
                child: Text('Another Dropdown $_selecteddate',
                    style: _labelStyle(context).copyWith(color: Colors.orange)),
              ),
              Flexible(child: Text('Another Dropdown2')),
              Flexible(
                fit: FlexFit.loose,
                child: Container(
                  color: Colors.purpleAccent.shade100,
                  width: 150,
                  height: 20,
                  child: Text(' wide : ${size.width}'),
                ),
              ),
              Flexible(
                fit: FlexFit.tight,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.purpleAccent.shade100,
                    border: Border.all(color: Colors.blue.shade800),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.grey.shade300,
                          blurRadius: 5,
                          spreadRadius: 5)
                    ],
                    shape: BoxShape.circle,
                  ),
                  width: 150,
                  height: 20,
                  child: Transform.translate(
                      offset: Offset(20, 50),
                      child: Text('date : ${_selecteddate}')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


/**
## DatePickerMacOs2

### Purpose

The `DatePickerMacOs2` widget is a custom date picker implementation designed to resemble the date picker UI found in macOS. It provides a text field for date input, a calendar icon button to open a date selection popup, and a cancel button to clear the field. It also supports swiping to increment or decrement the selected date. The widget manages its state internally and uses a custom `MultiChildLayoutDelegate` to position its child widgets. It allows users to input a date via text or selection from the calendar popup, notifying a parent widget via a callback function when a date is selected.

### Main Methods

*   **`DatePickerMacOs2({Key? key, Alignment alignment = Alignment.topRight, required void Function(DateTime date) onDateSelected, DateTime? initialDate})`**

*   **Constructor:** Creates an instance of the `DatePickerMacOs2` widget.
*   **Parameters:**
*   `key`: Optional widget key.
*   `alignment`:  The alignment of the date picker UI within the available space, defaults to `Alignment.topRight`.
*   `onDateSelected`: A callback function that takes a `DateTime` object as a parameter and is called whenever the date is updated.
*   `initialDate`: An optional `DateTime` representing the initial selected date.
*   **`createState()`**
*   **Purpose:** Creates the mutable state for this widget.
*   **Return Value:** Returns an instance of `_DatePickerMacOs2State`.

## _DatePickerMacOs2State

### Purpose

The `_DatePickerMacOs2State` manages the state for `DatePickerMacOs2`. This includes a `TextEditingController` to control the text field, handling date input and updates, and interaction with a custom date-picker dialog. It also manages the `Timer` used to provide the auto increment and decrement functionality

### Main Methods

*   **`initState()`**
*   **Purpose:** Initializes the state, sets up the `TextEditingController` with the initial date if given, and adds a listener to call `_textInputAction()` when text changes.
*   **Logic:**
1. Initializes the `_textdateController`
2. Sets the initial value of the controller, based on `initialDate`, or `DateTime.now()`.
3. Adds a listener to `_textdateController` to call the `_textInputAction` method, when the text is updated.
*   **`dispose()`**
*   **Purpose:** Disposes of the `TextEditingController` when the state is released to prevent memory leaks.
*   **Logic:** disposes of the `_textdateController` and calls the superclass `dispose()` method.
*   **`didUpdateWidget(DatePickerMacOs2 oldWidget)`**
*   **Purpose:** Updates the text controller when the widget's `initialDate` property changes
*   **Parameter:** `oldWidget` a reference to the old widget.
*  **Logic:** If the old widget and the new widgets `initialDate` are different, update the text in the text controller.
*   **`_textInputAction()`**
*   **Purpose:**  Validates and process date input from the text field.
*   **Logic:**
1. Gets the text from the controller and uses the `isValidDate()` extention method to check the text represents a valid date.
2. If the text represents a valid date, calls the `widget.onDateSelected()` with a converted `DateTime` object using the `toDateTime()` extention method.
*  **`_onPopupMenuSelection(DateTime date) async`**
*   **Purpose:** Called when a date is selected from the popup menu.
*   **Parameters:** `date` A `DateTime` object representing the date selected.
*   **Logic:**
1. If the year of the date is 0 (i.e. it was a custom select option), it will call the `_showCustomDatePicker` method and use this to set the text in the text controller, and call `widget.onDateSelected()`.
2. If not, it will set the text in the text controller, and call `widget.onDateSelected()`.
*   **`_showCustomDatePicker(BuildContext context, date) async`**
*   **Purpose:** Displays a custom `CalendarDatePicker` dialog to allow the user to pick a date.
*   **Parameters:** `context` the flutter widget context, and `date` a `DateTime` object representing the current date selected.
*  **Logic:**
1. Shows a custom dialog box using `showDialog()`.
2. Shows a `CalendarDatePicker` widget in the dialog box.
3. When a date is selected, sets `pickedDate` to the selected date, and closes the dialog using `Navigator.of(context).pop()`.
4. Returns `pickedDate` to the caller.
*   **`_incrementDate(PointerMoveEvent details)`**
*   **Purpose:** Handles date incrementing or decrementing based on the horizontal swipe in the text field.
*   **Parameters:** `PointerMoveEvent` that encapsulates the details of the swipe action.
*  **Logic:**
1. If the magnitude of the swipe is not significant, it will return early.
2. Calculates the direction of the change using the `details.delta.dx` property
3. Creates a Timer, and if the timer is still active, it returns early.
4. After the timer expires, update the text field with a date that is incremented by a day.
*   **`build(BuildContext context)`**
*   **Purpose:** Builds the widget tree for the date picker.
*   **Parameters:** `context` the flutter widget context.
*   **Return value:** Returns a `CustomMultiChildLayout` widget.
*   **Logic:** Constructs the layout of the date picker using a `CustomMultiChildLayout`, including the background, popup, text field, and cancel button.

## _DatePickerDelegate

### Purpose

The `_DatePickerDelegate` is a custom `MultiChildLayoutDelegate` responsible for the layout of the `DatePickerMacOs2`'s child widgets. It positions the various components based on the alignment, padding, and gap specified in the `DatePickerMacOs2` widget, ensuring the correct visual arrangement of the date picker's elements.

### Main Methods

*   **`_DatePickerDelegate({Alignment alignment = Alignment.topCenter, double padding = 0, double gap = 5})`**
*   **Constructor:** Creates an instance of the `_DatePickerDelegate`.
*   **Parameters:**
*   `alignment`:  The alignment of the date picker UI within the available space, defaults to `Alignment.topCenter`.
*   `padding`: The padding to apply around the layout, defaults to 0.
*    `gap`: The gap between elements. defaults to 5.
*   **`getSize(BoxConstraints constraints)`**
*   **Purpose:** returns the required size of the layout.
*   **Parameters:** `BoxConstraints` that are passed in from the parent widget.
*   **Return value:** returns a size object, the same as the available contraints from the parent widget.
*   **`_computeCompontentSize(List<Size> args)`**
*   **Purpose:** Computes the overall size of all the elements in the layout, used to perform the positioning of the items.
*   **Parameters:** `List<Size>` A list of sizes that represent each of the items that will be displayed in the layout.
*   **Return Value:** Returns a size object representing the required size of the widget.
*    **Logic:** currently this returns the `background` widgets size.
*   **`_computeStartPoint(Size constraint)`**
*  **Purpose:** computes the start position based on the current `alignment`.
*   **Parameters:** `Size` the size of the current widget available to layout.
*  **Return Value:** returns a `Point` object that represents the start position.
*  **Logic:** Checks the provided `alignment` property of the widget, to compute the start point of the layout, defaulting to the top left of the available space.
*   **`performLayout(Size size)`**
*   **Purpose:** Executes the layout algorithm, positioning each child widget within the available size.
*   **Parameters:** The available size for the layout.
*   **Logic:**
1. Computes the `startAt` point using `_computeStartPoint()`.
2. Lays out each of the child widgets using the `layoutChild()` method and positions them using the `positionChild()` method.
*   **`shouldRelayout(MultiChildLayoutDelegate oldDelegate)`**
*   **Purpose:** Determines if the layout needs to be recalculated when the widget changes.
*  **Parameters:** A reference to the previous instance of the layout delegate.
*   **Return Value:** Returns `true` so that the layout is always recalculated.

## _PopupMenuForCalendarButton

### Purpose
The `_PopupMenuForCalendarButton` widget is a stateless widget that displays a popup menu button for selecting dates. It provides options for selecting today, tomorrow, the weekend, or a custom date via a calendar. It uses a popup menu to present these options and invokes a callback when an option is selected.

### Main Methods

*   **`_PopupMenuForCalendarButton({Key? key, required Function(DateTime arg) onMenuItemSelected})`**
*   **Constructor:** Creates an instance of the `_PopupMenuForCalendarButton` widget.
*   **Parameters:**
*   `key`: Optional widget key.
*   `onMenuItemSelected`: A callback function that accepts a `DateTime` object when an item is selected from the menu.
*   **`build(BuildContext context)`**
*   **Purpose:** Builds the widget tree for the popup menu button.
*   **Parameters:** `context` the flutter widget context.
*   **Return value:** Returns a `SizedBox` containing a `PopupMenuButton`.
*   **Logic:** Constructs the popup menu button with calendar icon and creates popup menu items for Today, Tomorrow, Weekend, and Custom date selection.

## _LabelOfCalendarDropDown

### Purpose

The `_LabelOfCalendarDropDown` widget is a stateless widget responsible for displaying the individual label entries within the date picker's popup menu. It displays an icon, label, and date string with optional separators.

### Main Methods

*   **`_LabelOfCalendarDropDown({Key? key, required IconData icon, required String label, required String date, Widget? topSeparator})`**
*   **Constructor:** Creates an instance of the `_LabelOfCalendarDropDown` widget.
*   **Parameters:**
*  `key`: Optional widget key.
*   `icon`: The icon to be displayed next to the label.
*   `label`: The text label to be displayed.
*   `date`: The date to be displayed.
*  `topSeparator`: An optional widget to be displayed above the label.
*   **`build(BuildContext context)`**
*   **Purpose:** Builds the widget tree for the calendar dropdown label.
*    **Parameters:** `context` the flutter widget context.
*   **Return value:** Returns a `RichText` widget.
*   **Logic:** Constructs the widget with a RichText containing the optional separator, the icon, the label, and the date text.

## _CancelButton

### Purpose

The `_CancelButton` widget is a stateless widget that displays a button with a close icon, which is used to clear the date field.

### Main Methods

*   **`_CancelButton({Key? key, VoidCallback? onPressed})`**
*   **Constructor:** Creates an instance of the `_CancelButton` widget.
*   **Parameters:**
*  `key`: Optional widget key.
*   `onPressed`: An optional callback function that is called when the button is pressed.
*   **`build(BuildContext context)`**
*   **Purpose:** Builds the widget tree for the cancel button.
*   **Parameters:** `context` the flutter widget context.
*   **Return value:** Returns a `TextButton` widget.
*  **Logic:** Constructs the button with a close icon and the provided `onPressed` callback.

## `DateTextInputFormatter`

### Purpose

The `DateTextInputFormatter` is a custom `TextInputFormatter` designed for Flutter text fields. Its primary purpose is to enforce a specific date format (dd/MM/yyyy) as the user inputs text. It ensures that only valid date values are entered in the correct format, improving the user experience and data integrity.

This formatter attempts to:
* Ensure that only digits and the `/` character can be entered.
* Automatically add the `/` character at the correct positions as the user types.
* Restrict the input such that it follows the dd/mm/yyyy format
* Validate individual elements of the date as they are entered.

### Main Methods

*   **`DateTextInputFormatter()`**

*   **Constructor:** The default constructor for the class. It does not take any arguments.
*   **Side Effect:**  Prints `"DateTextInputFormatter created"` to the console when a new instance is created.

*   **`formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue)`**

*   **Purpose:** This is the core method of any `TextInputFormatter`. It's called by Flutter whenever the text field's content changes.
*   **Parameters:**
*   `oldValue`: The `TextEditingValue` representing the state of the text field before the edit.
*   `newValue`: The `TextEditingValue` representing the new state of the text field after the edit.
*   **Return Value:** Returns a new `TextEditingValue` which reflects any formatting applied.
*   **Logic:**
1.  **Handles Backspace:** If the length of `newValue` is less than `oldValue`, this is assumed to be a deletion and return the new `TextEditingValue`.
2.  **Initial Character:** Ensures that the first character is a value between 0 and 3.
3.  **Day Formatting** When the length of the string is 2. Ensure valid day format, and adds in the '/' separator.
4.  **Month Formatting** When the length of the string is 5. Ensure valid day and month formats, and adds in the '/' separator.
5.  **Returns:** The formatted text, or original text if the formatting conditions have not been met

*   **`_removeInvalidChars(String newText)`**

*   **Purpose:**  Removes all characters except digits (`0-9`) and the forward slash (`/`) from the input string.
*   **Parameter:**
*   `newText`: The string to process.
*   **Return Value:** A string with only digit and `/` characters.
*   **Logic:** Uses a Regular Expression to remove invalid characters

*   **`isValidDayInt(int day, int? month, int? year)`**

*   **Purpose:**  Validates the day, accounting for variations in month length and leap years when a full date is available.
*   **Parameters:**
* `day`: the day to validate as an integer
* `month`: the month to use for validation, or `null` if unavailable.
* `year`: the year to use for validation, or `null` if unavailable.
*   **Return Value:** A `bool` value indicating whether or not the input day is valid.
*   **Logic:**
1. If `month` is null, ensure the day is in range.
2. If the `month` is not null, but the year is, get the number of days in a month for the entered month. Ensure the day is less than this number.
3. If both `month` and `year` are not null, then if the month is 2, then check for leap year and ensure that the day is valid based on the number of days in February. Otherwise, ensure day is within the 31 days of other months.

### Dependencies

*   **Flutter Framework:** This class relies on the `flutter/services.dart` library for `TextInputFormatter`, `TextEditingValue`, and `TextSelection`.
*   **`getDaysInMonth` Extension:** This relies on an extension on the int class, which is not provided, but is available in packages like `intl`. The extension should calculate the number of days in a month.
*   **`isLeapYear` Extension:**  This relies on an extension on the int class, which is not provided. The extension should calculate whether or not a year is a leap year.

### Usage Notes

*   Attach the `DateTextInputFormatter` to a Flutter `TextField` using its `inputFormatters` property.
*   This formatter is designed for basic date formatting and relies on extension functions which are not supplied in this class.
*   Additional validation and error handling might be required for real-world applications (e.g., validating against a specific date range).
*   Ensure `getDaysInMonth` and `isLeapYear` extensions are defined and implemented.

## Extension methods
### Purpose
These extension methods provide enhanced functionality for core Dart types

### formattedDate
*   `String get formatted`: extension on `DateTime` to convert to a dd/MM/yyyy string

### DateAsString
*   `DateTime toDateTime()`: extension on `String` to convert to a `DateTime` object
*   `bool isValidDate()`: extension on `String` to validate if a string is a valid date
## int extension
### Purpose
These extension methods provide enhanced functionality for the int type
*    `bool validMonthNo()`: Validates if the input is a valid month number (1-12)
*  `int getDaysInMonth(int month)`: gets the number of days in a given month
*    `bool isLeapYear()`: validates if an int is a leap year
*/
class DatePickerMacOs2 extends StatefulWidget {
  final DateTime? initialDate;
  final Alignment alignment;
  final void Function(DateTime date) onDateSelected;

  const DatePickerMacOs2(
      {super.key,
      this.alignment = Alignment.topRight,
      required this.onDateSelected,
      this.initialDate});

  @override
  State<DatePickerMacOs2> createState() => _DatePickerMacOs2State();
}

class _DatePickerMacOs2State extends State<DatePickerMacOs2> {
  late TextEditingController _textdateController;

  @override
  dispose() {
    _textdateController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant DatePickerMacOs2 oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.initialDate != widget.initialDate) {
      _textdateController.text =
          widget.initialDate?.formatted ?? DateTime.now().formatted;
    }
  }

  @override
  void initState() {
    super.initState();
    _textdateController = TextEditingController();
    _textdateController.text =
        widget.initialDate?.formatted ?? DateTime.now().formatted;

    _textdateController.addListener(() {
      //assert(_textdateController.text is String);
      print('text ${_textdateController.text}');
      _textInputAction();
    });
  }

  _textInputAction() {
    final text = _textdateController.text;
    print('_textInputAction $text, ${text.isValidDate()}');
    if (text.isValidDate()) {
      print('are we here');
      widget.onDateSelected(text.toDateTime());
    }

    print('text $text');
  }

  void _onPopupMenuSelection(DateTime date) async {
    DateTime? selectedDate;
    // print('hello smely ${date.formatted}');

    if (date.year == 0) {
      selectedDate = await _showCustomDatePicker(context, date);
      assert(selectedDate is DateTime); // Make sure the date is a DateTime
      _textdateController.value =
          TextEditingValue(text: selectedDate!.formatted);
    } else {
      _textdateController.value = TextEditingValue(text: date.formatted);
      selectedDate = date;
    }
    widget.onDateSelected(selectedDate);
  }

  Future<DateTime> _showCustomDatePicker(BuildContext context, date) async {
    DateTime pickedDate = date;
    await showDialog(
      context: context,
      builder: (context) {
        return Localizations(
          locale: const Locale('en', 'US'),
          delegates: [
            DefaultMaterialLocalizations.delegate,
            DefaultWidgetsLocalizations.delegate,
          ],
          child: Dialog(
            child: Container(
              width: 360, // Custom width
              height: 300, // Custom height
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Text(
                    "Select Date",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  Expanded(
                    child: CalendarDatePicker(
                      initialDate:
                          pickedDate.year == 0 ? DateTime.now() : pickedDate,
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2100),
                      onDateChanged: (arg) {
                        pickedDate = arg;
                        Navigator.of(context).pop(); // Close dialog
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );

    return pickedDate;
  }

  late Timer _timer = Timer(Duration.zero, () => null);

  _incrementDate(PointerMoveEvent details) {
    print('details delta ${details.delta.dx}'); // 10');
    if (details.delta.dx.abs() * 100 < 50) return;

    final direction = details.delta.dx > 0 ? 1 : -1;

    if (_timer != null && _timer.isActive) return;

    _timer = Timer(Duration(milliseconds: 150), () {
      print('timer tick');
      final value = _textdateController.text;

      final nwdate = value.isValidDate()
          ? value.toDateTime().add(Duration(days: direction))
          : DateTime.now().add(Duration(days: direction));
      _textdateController.text = nwdate.formatted;
      _timer.cancel();
    });
  }

  @override
  Widget build(BuildContext context) {
    return CustomMultiChildLayout(
      delegate:
          _DatePickerDelegate(alignment: widget.alignment, padding: 0, gap: 5),
      children: [
        LayoutId(
          id: 'background',
          child: Container(
            padding: const EdgeInsets.all(0),
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              border: Border.all(color: Colors.blue.shade300),
              borderRadius: BorderRadius.circular(5),
            ),
          ),
        ),
        LayoutId(
          id: 'popup',
          child: _PopupMenuForCalendarButton(
            onMenuItemSelected: _onPopupMenuSelection,
          ),
        ),
        LayoutId(
          id: 'textfield',
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: Colors.white,
            ),
            child: Listener(
              onPointerMove: (details) {
                _incrementDate(details);
              },
              child: EditableText(
                controller: _textdateController,
                inputFormatters: [DateTextInputFormatter()],
                focusNode: FocusNode()
                  ..onKeyEvent = (node, event) {
                    if (event.logicalKey == LogicalKeyboardKey.enter) {
                      _textInputAction();
                      return KeyEventResult.handled;
                    }
                    return KeyEventResult.ignored;
                  },
                style: const TextStyle(color: Colors.black, fontSize: 12),
                cursorColor: Colors.black,
                backgroundCursorColor: Colors.black,
                keyboardType: TextInputType.text,
                readOnly: false,
                showCursor: true,
                maxLines: 1,
                selectionControls: MaterialTextSelectionControls(),
              ),
            ),
          ),
        ),
        LayoutId(
          id: 'cancelbutton',
          child: _CancelButton(
            onPressed: _textdateController.clear,
          ),
        ),
      ],
    );
  }
}

class _DatePickerDelegate extends MultiChildLayoutDelegate {
  final Alignment alignment;
  final double padding;
  final double gap;

  _DatePickerDelegate(
      {this.alignment = Alignment.topCenter, this.padding = 0, this.gap = 5});

  final Map<String, Size> sizes = {
    'background': const Size(125, 28),
    'popup': const Size(150, 24),
    'textfield': const Size(75, 30),
    'cancelbutton': const Size(20, 20),
  };

  @override
  getSize(BoxConstraints constraints) {
    // print('\n\nQQQQ constraints $constraints');
    return Size(constraints.maxWidth, constraints.maxHeight);
  }

//todo: implement the layout of the children
  Size _computeCompontentSize(List<Size> args) {
    // final sz =  sizes.fold(Size.zero, (prev, element) {
    //     print("prev sz:${element}");
    //   return Size(
    //       prev.width + element.width , prev.height > element.height ? prev.height : element.height);
    // });
    // print('sz $sz');
    return sizes['background']!;
  }

  Point _computeStartPoint(Size constraint) {
    // print('alignment $alignment');
    late Point startPoint = Point(0, 0);
    // Size container = getSize(constraints)
    Size components = _computeCompontentSize(sizes.values.toList());

    if (alignment == Alignment.center) {
      final x = (constraint.width - components.width) / 2;
      final y = (constraint.height - components.height) / 2;
      startPoint = Point(x, y);
    } else if (alignment == Alignment.topLeft) {
      startPoint = Point(padding, padding);
    } else if (alignment == Alignment.topRight) {
      final x = constraint.width - components.width - padding;
      final y = padding;
      startPoint = Point(x, y);
    } else if (alignment == Alignment.bottomLeft) {
      final x = padding;
      final y = constraint.height - components.height - padding;
      startPoint = Point(x, y);
    } else if (alignment == Alignment.bottomRight) {
      final x = constraint.width - components.width - padding;
      final y = constraint.height - components.height - padding;
      startPoint = Point(x, y);
    }
    return startPoint;
  }

  @override
  void performLayout(Size size) {
    Point startAt = _computeStartPoint(size);
    // print('performLayout size $size, startat $startAt');

    if (hasChild('textfield')) {
      layoutChild('textfield', BoxConstraints.loose(sizes['textfield']!));
      positionChild('textfield', Offset(startAt.x + 25, startAt.y + 6));
    }
    if (hasChild('background')) {
      layoutChild('background', BoxConstraints.loose(sizes['background']!));
      positionChild('background', Offset(startAt.x + 0, startAt.y + 0));
    }
    if (hasChild('popup')) {
      layoutChild('popup', BoxConstraints.loose(sizes['popup']!));
      positionChild('popup', Offset(startAt.x + 0, startAt.y + 0));
    }
    if (hasChild('cancelbutton')) {
      layoutChild('cancelbutton', BoxConstraints.loose(sizes['cancelbutton']!));
      positionChild('cancelbutton', Offset(startAt.x + 90, startAt.y + 5));
    }
  }

  @override
  bool shouldRelayout(covariant MultiChildLayoutDelegate oldDelegate) {
    // TODO: implement shouldRelayout
    return true;
  }
}

/// Extension methods.
extension formattedDate on DateTime {
  String get formatted => DateFormat('dd/MM/yyyy').format(this);
}

extension DateAsString on String {
  /// ___Extension method___ to convert a `String` to a `DateTime` object.
  DateTime toDateTime() {
    return DateFormat('dd/MM/yyyy').parse(this as String);
  }

  /// ___Extension method___ to validate if a `String` is a valid date.
  bool isValidDate() {
    try {
      final res = DateFormat("dd/MM/yyyy").parse(this.trim()) != null;
      return res;
    } catch (e) {
      print('isValidDate failed $e');
      return false;
    }
  }
}

/// A dropdown that shows a calendar and allows the user to select a date.
///
class _PopupMenuForCalendarButton extends StatelessWidget {
  DateTime get today => DateTime.now();
  final Function(DateTime arg) onMenuItemSelected;

  DateTime get tomorrow => DateTime.now().add(const Duration(days: 1));

  DateTime get weekend =>
      DateTime.now().add(Duration(days: (7 - DateTime.now().weekday) % 7 + 1));

  _PopupMenuForCalendarButton({super.key, required this.onMenuItemSelected});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 25,
      child: PopupMenuButton<DateTime>(
        initialValue: today,
        splashRadius: 10,
        position: PopupMenuPosition.over,
        onSelected: onMenuItemSelected,
        icon: Icon(
          Icons.calendar_month_outlined,
          size: 11,
          color: Colors.blue.shade400,
        ),
        itemBuilder: (BuildContext context) {
          return <PopupMenuEntry<DateTime>>[
            PopupMenuItem<DateTime>(
              value: today,
              child: _LabelOfCalendarDropDown(
                  icon: Icons.calendar_month,
                  topSeparator: Text('Suggestions',
                      style:
                          TextStyle(color: Colors.grey.shade500, fontSize: 13)),
                  label: "Today",
                  date: "${today.formatted}"),
            ),
            PopupMenuItem<DateTime>(
              value: tomorrow,
              child: _LabelOfCalendarDropDown(
                  topSeparator: null,
                  icon: Icons.add_business,
                  label: "Tomorrow",
                  date: "${tomorrow.formatted}"),
            ),
            PopupMenuItem<DateTime>(
              value: weekend,
              child: _LabelOfCalendarDropDown(
                  topSeparator: Divider(
                    color: Colors.grey.shade500,
                  ),
                  icon: Icons.add_business,
                  label: "Weekend",
                  date: "${weekend.formatted}"),
            ),
            PopupMenuItem<DateTime>(
              value: DateTime(0),
              child: _LabelOfCalendarDropDown(
                  topSeparator: Divider(
                    color: Colors.grey.shade500,
                  ),
                  icon: Icons.dashboard_customize,
                  label: "Custom...",
                  date: "Use the calendar to pick a date"),
            ),
          ];
        },
      ),
    );
  }
}

/// A stateless widget that represents a label for a calendar dropdown menu.
///
/// This widget is used to display a label with an icon, a date, and an optional top separator.
/// It is typically used within a `PopupMenuItem` to provide a consistent look and feel for
/// date selection options in a dropdown menu.
///
/// ### Properties:
/// - `topSeparator`: An optional widget to be displayed above the label.
/// - `icon`: The icon to be displayed next to the label.
/// - `label`: The text label to be displayed.
/// - `date`: The date to be displayed.
///
/// ### Methods:
/// - `build`: Builds the widget tree for the label, including the icon, label, date, and optional top separator.

class _LabelOfCalendarDropDown extends StatelessWidget {
  final Widget? topSeparator;
  final IconData icon;
  final String label;
  final String date;

  const _LabelOfCalendarDropDown({
    Key? key,
    required this.icon,
    required this.label,
    required this.date,
    required this.topSeparator,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        text: '',
        style: const TextStyle(color: Colors.black, fontSize: 13),
        children: [
          if (topSeparator != null) ...[
            WidgetSpan(child: topSeparator!),
            const TextSpan(text: '\n')
          ],
          WidgetSpan(
            child: SizedBox.square(
              dimension: 20,
              child: Transform.translate(
                offset: const Offset(0, 14),
                child: Icon(
                  icon,
                  color: Colors.grey,
                  size: 15,
                ),
              ),
            ),
          ),
          TextSpan(
            text: '$label\n',
          ),
          const WidgetSpan(
            child: SizedBox.square(dimension: 20),
          ),
          TextSpan(
            text: '$date',
          ),
        ],
      ),
    );
  }
}

class _CancelButton extends StatelessWidget {
  final VoidCallback? onPressed;

  const _CancelButton({Key? key, this.onPressed}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: onPressed,
      style: ButtonStyle(
        // Remove mouseover and click effects
        overlayColor: WidgetStateProperty.all(Colors.transparent),
        shadowColor: WidgetStateProperty.all(Colors.transparent),
        // No background or elevation
        backgroundColor: WidgetStateProperty.all(Colors.transparent),
        elevation: WidgetStateProperty.all(0),
      ),
      child: const Icon(
        Icons.close,
        size: 13,
        color: Color(0x37000000),
        // Set your desired color for the icon
      ),
    );
  }
}

/// # DateTextInputFormatter
///
/// ## Purpose
///
/// The `DateTextInputFormatter` is a custom `TextInputFormatter` designed for Flutter text fields. Its primary purpose is to enforce a specific date format (dd/MM/yyyy) as the user inputs text. It ensures that only valid date values are entered in the correct format, improving the user experience and data integrity.
///
/// This formatter attempts to:
/// * Ensure that only digits and the `/` character can be entered.
/// * Automatically add the `/` character at the correct positions as the user types.
/// * Restrict the input such that it follows the dd/mm/yyyy format
/// * Validate individual elements of the date as they are entered.
///
/// ## Main Methods
///
/// ### `DateTextInputFormatter()`
///
/// *   **Constructor:** The default constructor for the class. It does not take any arguments.
/// *   **Side Effect:**  Prints `"DateTextInputFormatter created"` to the console when a new instance is created.
///
/// ### `formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue)`
///
/// *   **Purpose:** This is the core method of any `TextInputFormatter`. It's called by Flutter whenever the text field's content changes.
/// *   **Parameters:**
/// *   `oldValue`: The `TextEditingValue` representing the state of the text field before the edit.
/// *   `newValue`: The `TextEditingValue` representing the new state of the text field after the edit.
/// *   **Return Value:** Returns a new `TextEditingValue` which reflects any formatting applied.
/// *   **Logic:**
/// 1.  **Handles Backspace:** If the length of `newValue` is less than `oldValue`, this is assumed to be a deletion and return the new `TextEditingValue`.
/// 2.  **Initial Character:** Ensures that the first character is a value between 0 and 3.
/// 3.  **Day Formatting** When the length of the string is 2. Ensure valid day format, and adds in the '/' separator.
/// 4.  **Month Formatting** When the length of the string is 5. Ensure valid day and month formats, and adds in the '/' separator.
/// 5.  **Returns:** The formatted text, or original text if the formatting conditions have not been met
///
/// ### `_removeInvalidChars(String newText)`
///
/// *   **Purpose:**  Removes all characters except digits (`0-9`) and the forward slash (`/`) from the input string.
/// *   **Parameter:**
/// *   `newText`: The string to process.
/// *   **Return Value:** A string with only digit and `/` characters.
/// *   **Logic:** Uses a Regular Expression to remove invalid characters
///
/// ### `isValidDayInt(int day, int? month, int? year)`
///
/// *   **Purpose:**  Validates the day, accounting for variations in month length and leap years when a full date is available.
/// *  **Parameters:**
/// * `day`: the day to validate as an integer
/// * `month`: the month to use for validation, or `null` if unavailable.
/// * `year`: the year to use for validation, or `null` if unavailable.
/// *  **Return Value:** A `bool` value indicating whether or not the input day is valid.
/// *   **Logic:**
/// 1. If `month` is null, ensure the day is in range.
/// 2. If the `month` is not null, but the year is, get the number of days in a month for the entered month. Ensure the day is less than this number.
/// 3. If both `month` and `year` are not null, then if the month is 2, then check for leap year and ensure that the day is valid based on the number of days in February. Otherwise, ensure day is within the 31 days of other months.
///
/// ## Dependencies
///
/// *   **Flutter Framework:** This class relies on the `flutter/services.dart` library for `TextInputFormatter`, `TextEditingValue`, and `TextSelection`.
/// *   **`getDaysInMonth` Extension:** This relies on an extension on the int class, which is not provided, but is available in packages like `intl`. The extension should calculate the number of days in a month.
/// *   **`isLeapYear` Extension:**  This relies on an extension on the int class, which is not provided. The extension should calculate whether or not a year is a leap year.
///
/// ## Usage Notes
///
/// *   Attach the `DateTextInputFormatter` to a Flutter `TextField` using its `inputFormatters` property.
/// *   This formatter is designed for basic date formatting and relies on extension functions which are not supplied in this class.
/// *   Additional validation and error handling might be required for real-world applications (e.g., validating against a specific date range).
/// *   Ensure `getDaysInMonth` and `isLeapYear` extensions are defined and implemented.

class DateTextInputFormatter extends TextInputFormatter {
  DateTextInputFormatter() : super() {
    print("DateTextInputFormatter created");
  }

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    bool isvalid = true;
    String newText = newValue.text;
    String formattedText = newText.trim();
    int caretPosition = newValue.selection.end;

    // Remove non-digit characters except '/'
    //newText = _removeInvalidChars(newText);

    if (newValue.text.length < oldValue.text.length) {
      return TextEditingValue(
        text: newText,
        selection: TextSelection.collapsed(offset: newText.length),
      );
    }

    // Insert '/' at the correct positions (after 2nd and 5th character)

    if (newText.length == 1) if (RegExp(r'^[0123]$').hasMatch(newText)) {
      isvalid = true;
    } else
      isvalid = false;

    if (newText.length == 2) if (RegExp(r'^(3[10]|[12][0-9]|0[1-9])$')
        .hasMatch(newText)) {
      isvalid = isValidDayInt(int.parse(newText), null, null);
      formattedText = newText.substring(0, 2) + '/';
    } else
      isvalid = false;

    if (newText.length == 5) if (RegExp(
            r'^(0[1-9]|[12]\d|3[01])\/(0[1-9]|1[0-2])$')
        .hasMatch(newText)) {
      final vals = newText.split("/").map((e) => int.parse(e)).toList();
      isvalid = isValidDayInt(vals[0], vals[1], null);
      formattedText = newText.substring(0, 5) + '/';
    } else
      isvalid = false;

    final retStr = isvalid ? formattedText : oldValue.text;
    return TextEditingValue(
      text: retStr,
      selection: TextSelection.collapsed(offset: retStr.length),
    );
  }

  bool isValidDayInt(int day, int? month, int? year) {
    if (month == null) {
      return day > 0 && day < 32;
    }

    if (month != null && year == null) {
      final dim = month.getDaysInMonth(month);

      if (day != null) {
        return day > 0 && day <= dim;
      }
      return false;
    }
    if (month != null && year != null) {
      if (month == 2) {
        if (year.isLeapYear()) {
          return day != null && day < 30;
        }
        return day != null && day < 29;
      }
      return day != null && day < 31;
    }
    throw UnimplementedError('isValidDayInt() "unexpected condition"');
  }
}

extension on int {


  int getDaysInMonth(int month) {
    const List<int> daysInMonth = [
      31,
      28,
      31,
      30,
      31,
      30,
      31,
      31,
      30,
      31,
      30,
      31
    ];
    return daysInMonth[month - 1];
  }

  bool isLeapYear() {
    if (this % 4 != 0) return false; // Not divisible by 4

    if (this % 100 == 0)
      return this % 400 ==
          0; // Divisible by 100, check if also divisible by 400
    else
      return true; // Divisible by 4, and not a century year that's not divisible by 400
  }
}

