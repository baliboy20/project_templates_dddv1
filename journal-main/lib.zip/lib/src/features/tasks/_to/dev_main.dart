import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/features/tasks/_to/_test_data.dart';
import 'package:journal_macos/src/features/tasks/_to/to_task_bloc.dart';

import '../../journals/infrastructure/datasources/remote/journals.testdata.dart';
import '../domain/entities/task_entity.dart';
import '../presentation/bloc/task_states.dart';

part 'dev_form_editors.dart';

Widget _buildBloc(Function(BuildContext, ToTaskState) builder) {
  return BlocProvider(
    create: (context) => ToTaskBloc(data: testTaskData),
    child: BlocConsumer<ToTaskBloc, ToTaskState>(
      listener: (context, state) {
        // if (state is TasksLoaded) {
        //   print('Tasks loaded');
        // }
      },
      builder: builder as BlocWidgetBuilder<ToTaskState>,
    ),
  );
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: _buildBloc(
          (context, state) => HomeScreen(),
        ));
  }
}

// Ω
// Home Screen.
class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: ListOfTasksEditable(),
    );
  }
}

class ListOfTasksEditable extends StatefulWidget {
  const ListOfTasksEditable({super.key});

  @override
  State<ListOfTasksEditable> createState() => _ListOfTasksEditableState();
}

// Ω
// List of Tasks Editable State.
class _ListOfTasksEditableState extends State<ListOfTasksEditable> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Tasks'),
      ),
      backgroundColor: Colors.white70,
      body: ListView.builder(
        itemCount: testTaskData.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.all(18.0),
            child: TaskCard(task: testTaskData[index]),
          );
        },
      ),
    );
  }
}

class TaskCard extends StatefulWidget {
  final TaskModel task;

  const TaskCard({super.key, required this.task});

  @override
  State<TaskCard> createState() => _TaskCardState();
}

// Ω
// Task Card State.
class _TaskCardState extends State<TaskCard> {
  bool _isDirty = false;
  bool _editMode = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      //
      decoration: BoxDecoration(
        color: Colors.blueGrey.shade50,
        border: Border.all(color: Colors.blueGrey.shade100),
        borderRadius: BorderRadius.circular(10),
      ),
      width: MediaQuery.sizeOf(context).width,
      height: 300,
      child: Stack(
        children: [
          Positioned(
              top: 15,
              right: 10,
              child: IconButton(
                  onPressed: () {
                    setState(() {
                      _editMode = !_editMode;
                      print("settin editmode: $_editMode");
                    });
                  },
                  icon: Icon(Icons.edit_note_outlined,
                      size: 18,
                      color: _editMode ? Colors.redAccent : Colors.grey))),
          Positioned(
            top: 45,
            left: 25,
            bottom: 45,
            child: _editMode
                ? TaskEditor(task: widget.task)
                : TaskView(task: widget.task),
          )
        ],
      ),
    );
  }
}

// Ω
/// Task View.
class TaskView extends StatelessWidget {
  final TaskModel task;

  const TaskView({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: 400,
        maxWidth: MediaQuery.sizeOf(context).width - 100,
      ),
      alignment: Alignment.topLeft,
      color: Colors.white,
      child: CustomScrollView(slivers: [
        SliverAppBar(
          pinned: false,
          floating: true,
             flexibleSpace: FlexibleSpaceBar(
               collapseMode: CollapseMode.pin,
               title:  Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                'Task: ${task.description}',
                style: Theme.of(context).textTheme.labelLarge,
              ),
            ),
          ),
        ),
        SliverList.list(children: [
          Text('Descriptionz: ${task.description}'),
          RichText(
              text: TextSpan(
                  text: 'On: ',
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(color: Colors.grey),
                  children: [
                TextSpan(
                  text: task.fromFormatted(),
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(color: Colors.black),
                ),
                TextSpan(
                  text: ' to ',
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(color: Colors.grey),
                ),
                TextSpan(
                  text: task.toFormatted(),
                  style: Theme.of(context)
                      .textTheme
                      .labelSmall
                      ?.copyWith(color: Colors.black),
                ),
              ])),
          TaskPriorityFlag(priority: task.priority),

        ]),
        SliverList.list(
            children: _buildActionsView(task.actionItems)
        ),
      ]),
    );
  }
  
  List<Widget> _buildActionsView(List<ActionItemModel> items)
  => items.map<Widget>((e)=> ActionView(actionItem: e)).toList();
}

///   📗
/// Task Priority Flag.
class TaskPriorityFlag extends StatelessWidget {
  final TaskPriority priority;

  const TaskPriorityFlag({super.key, required this.priority});

  @override
  Widget build(BuildContext context) {
    final color = priority == TaskPriority.high
        ? Colors.red
        : priority == TaskPriority.normal
            ? Colors.amber
            : Colors.green;
    return Icon(Icons.flag, color: color);
  }
}

/// 📗
///  Actions View.
class ActionView extends StatelessWidget {
  final ActionItemModel actionItem;

   

  const ActionView({super.key, required this.actionItem});

  @override
  Widget build(BuildContext context) {
    return  Row(




        children: [

          // Checkbox.adaptive(
          //   shape: RoundedRectangleBorder(
          //     borderRadius: BorderRadius.circular(10),
          //   ),
          //   value: actionItem.status == ActionStatus.completed,
          //   onChanged: (value) {
          //
          //   },
          // ),
          Container(
            color: Colors.blueGrey.shade100,
            height: 10,
            width: 50,
            child: RichText(
              text: TextSpan(
                  text: actionItem.action,
                  style: Theme.of(context)
                      .textTheme
                      .labelMedium
                      ?.copyWith(color: Colors.black),
                  children: [

                    TextSpan(
                      text: '\n Due: ',
                      style: Theme.of(context)
                          .textTheme
                          .labelSmall
                          ?.copyWith(color: Colors.grey),
                    ),
                    TextSpan(
                      text: actionItem.completedByFormatted(),
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(color: Colors.black),
                    ),
                  ]),
            ),
          ),

          Text('Due: ${actionItem.completedByFormatted()}'),
          // Text('Status: ${actionItem.status.name}'),

        ],
      ) ;
  }

 
}

