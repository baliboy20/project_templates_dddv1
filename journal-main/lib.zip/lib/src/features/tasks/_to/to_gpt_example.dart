import 'package:flutter/material.dart';

import '../domain/entities/task_entity.dart';

class TaskFormScreen extends StatefulWidget {
  final TaskModel? task; // Pass null for creating a new task
  const TaskFormScreen({Key? key, this.task}) : super(key: key);

  @override
  State<TaskFormScreen> createState() => _TaskFormScreenState();
}

class _TaskFormScreenState extends State<TaskFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _descriptionController = TextEditingController();
  final List<ActionItemModel> _actionItems = [];

  DateTime? _fromDate;
  DateTime? _toDate;
  TaskPriority _priority = TaskPriority.normal;

  @override
  void initState() {
    super.initState();
    if (widget.task != null) {
      _descriptionController.text = widget.task!.description;
      _fromDate = widget.task!.from;
      _toDate = widget.task!.to;
      _priority = widget.task!.priority;
      _actionItems.addAll(widget.task!.actionItems);
    }
  }

  void _addActionItem() {
    setState(() {
      _actionItems.add(ActionItemModel(
        completedOn:DateTime.now(),
        id: UniqueKey().toString(),
        action: '',
        from: DateTime.now(),
        completeBy: DateTime.now().add(const Duration(days: 1)),
        status: ActionStatus.pending,
      ));
    });
  }

  void _removeActionItem(int index) {
    setState(() {
      _actionItems.removeAt(index);
    });
  }

  void _saveTask() {
    if (_formKey.currentState!.validate()) {
      final newTask = TaskModel(
        id: widget.task?.id ?? UniqueKey().toString(),
        description: _descriptionController.text,
        from: _fromDate!,
        to: _toDate!,
        priority: _priority,
        status: ActionStatus.pending,
        actionItems: _actionItems,
      );
      // Save the task (pass it to a callback or a state management solution)
      Navigator.pop(context, newTask);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.task == null ? 'Add Task' : 'Edit Task'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveTask,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                TextFormField(
                  controller: _descriptionController,
                  decoration: const InputDecoration(labelText: 'Description'),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: TextButton.icon(
                        icon: const Icon(Icons.date_range),
                        label: Text(_fromDate == null
                            ? 'Start Date'
                            : _fromDate!.toLocal().toString().split(' ')[0]),
                        onPressed: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (date != null) {
                            setState(() => _fromDate = date);
                          }
                        },
                      ),
                    ),
                    Expanded(
                      child: TextButton.icon(
                        icon: const Icon(Icons.date_range),
                        label: Text(_toDate == null
                            ? 'End Date'
                            : _toDate!.toLocal().toString().split(' ')[0]),
                        onPressed: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (date != null) {
                            setState(() => _toDate = date);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<TaskPriority>(
                  value: _priority,
                  items: TaskPriority.values.map((priority) {
                    return DropdownMenuItem(
                      value: priority,
                      child: Text(priority.name),
                    );
                  }).toList(),
                  onChanged: (value) => setState(() => _priority = value!),
                  decoration: const InputDecoration(labelText: 'Priority'),
                ),
                const SizedBox(height: 16),
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: _actionItems.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: TextFormField(
                        initialValue: _actionItems[index].action,
                        decoration: const InputDecoration(labelText: 'Action'),
                        onChanged: (value) {
                          // _actionItems[index] =
                          //     _actionItems[index].copyWith(action: value);
                        },
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete),
                        onPressed: () => _removeActionItem(index),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _addActionItem,
                  icon: const Icon(Icons.add),
                  label: const Text('Add Action Item'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
