import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:tuple/tuple.dart';
import 'dart:math' as math;

class DynamicSizedCard extends MultiChildRenderObjectWidget {
  final EdgeInsets padding;
  final Color? backgroundColor;
  DynamicSizedCard({Key? key, required List<Widget> children, this.padding = EdgeInsets.zero, this.backgroundColor})
      : super(key: key, children: children);

  @override
  RenderDynamicSizedCard createRenderObject(BuildContext context) {
    return RenderDynamicSizedCard(backgroundColor: backgroundColor);
  }
}

class RenderDynamicSizedCard extends RenderBox
    with
        ContainerRenderObjectMixin<RenderBox, DynamicSizedCardData>,
        RenderBoxContainerDefaultsMixin<RenderBox, DynamicSizedCardData> {
  Color? backgroundColor;
  RenderDynamicSizedCard({this.backgroundColor});

  @override
  void setupParentData(RenderBox child) {
    if (child.parentData is! DynamicSizedCardData) {
      child.parentData = DynamicSizedCardData();
    }
  }

  @override
  void performLayout() {
    double maxWidth = 0;
    double totalHeight = 0;
    double currentY = 0;
    RenderBox? child = firstChild;

    childrenWithOffsets.clear(); // Clear previous data

    while (child != null) {
      final DynamicSizedCardData childData = child.parentData! as DynamicSizedCardData;
      child.layout(constraints.loosen(), parentUsesSize: true);
      final Size childSize = child.size;

      maxWidth = math.max(maxWidth, childSize.width);
      totalHeight += childSize.height;
      childData.offset = Offset(0, currentY);
      childrenWithOffsets.add(Tuple2(child, childData.offset));
      currentY += childSize.height;
      child = childData.nextSibling;
    }

    size = constraints.constrain(Size(maxWidth, totalHeight));
  }

  @override
  void paint(PaintingContext context, Offset offset) {
    final canvas = context.canvas;
    if (backgroundColor != null) {
      canvas.drawRect(offset & size, Paint()..color = backgroundColor!);
    }
    canvas.saveLayer(offset & size, Paint()..blendMode = BlendMode.dstIn); //added clipping
    for (final childAndOffset in childrenWithOffsets) {
      context.paintChild(childAndOffset.item1, offset + childAndOffset.item2);
    }
    canvas.restore();
  }

  @override
  bool hitTestChildren(BoxHitTestResult result, {required Offset position}) {
    for (final childAndOffset in childrenWithOffsets.reversed) {
      if (childAndOffset.item1.hitTest(result, position: position - childAndOffset.item2)) {
        return true;
      }
    }
    return false;
  }

  List<Tuple2<RenderBox, Offset>> childrenWithOffsets = [];
}

class DynamicSizedCardData extends ContainerBoxParentData<RenderBox> {
  Offset offset = Offset.zero;
}