
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:journal_macos/src/features/tasks/_to/_test_data.dart';

import '../domain/entities/task_entity.dart';

class ToTaskBloc extends Bloc<ToTaskEvent, ToTaskState> {
  // final TaskRepository taskRepository;
  final List<TaskModel> data;

  ToTaskBloc({required this.data}) : super(LoadingTasks()) {
    on<ToTaskEvent>(_onEvent);
  }

  void _onEvent(ToTaskEvent event, Emitter<ToTaskState> emit) {
    if (event is  LoadTasks) {
      _loadTasks(emit);
    } else if (event is  AddTask) {
      _addTask(event, emit);
    } else if (event is  UpdateTask) {
      _updateTask(event, emit);
    } else if (event is  DeleteTask) {
      _deleteTask(event, emit);
    }
  }

  void _loadTasks(Emitter<ToTaskState> emit) async {
    emit(LoadingTasks(loading: true));
    await Future.delayed(Duration(seconds: 1));
    emit(TasksLoaded(tasks: data));

  }

  void _addTask( AddTask event, Emitter<ToTaskState> emit) async {


  }

  void _updateTask(UpdateTask event, Emitter<ToTaskState> emit) async {

  }

  void _deleteTask( DeleteTask event, Emitter<ToTaskState> emit) async {

  }
}

///== Events
abstract class ToTaskEvent extends Equatable {
  const ToTaskEvent();

  @override
  List<Object?> get props => [];
}

class LoadTasks extends ToTaskEvent {}
class AddTask extends ToTaskEvent {
  final Task task;
  AddTask({required this.task});

  @override
  List<Object?> get props => [task];
}

class UpdateTask extends AddTask{
  UpdateTask({required super.task});
}

class DeleteTask extends AddTask{
  DeleteTask({required super.task});
}




///== States
///== States
/// States for the bloc
base class ToTaskState extends Equatable {
  @override List<Object?> get props => throw UnimplementedError();
}

final class LoadingTasks extends ToTaskState {
  final bool loading;
  LoadingTasks({this.loading = false});

  @override
  List<Object?> get props => [loading];
}

final class TasksLoaded extends ToTaskState {
  final List<Task> tasks;
  TasksLoaded({required this.tasks});

  @override
  List<Object?> get props => [tasks];
}
