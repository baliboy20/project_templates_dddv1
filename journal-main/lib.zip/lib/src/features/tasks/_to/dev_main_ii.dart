import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/features/tasks/_to/_test_data.dart';
import 'package:journal_macos/src/features/tasks/_to/dateSelectorDroprdown/DatePickerMacOs.dart';
import 'package:journal_macos/src/features/tasks/_to/to_task_bloc.dart';

import '../domain/entities/task_entity.dart';

Widget _buildBloc(Function(BuildContext, ToTaskState) builder) {
  return BlocProvider(
    create: (context) => ToTaskBloc(data: testTaskData),
    child: BlocConsumer<ToTaskBloc, ToTaskState>(
      listener: (context, state) {
        // if (state is TasksLoaded) {
        //   print('Tasks loaded');
        // }
      },
      builder: builder as BlocWidgetBuilder<ToTaskState>,
    ),
  );
}

// After
CupertinoTextThemeData _appTextTheme(BuildContext context) =>
    const CupertinoTextThemeData(
      textStyle: TextStyle(
          fontFamily: "SF Pro Text",
          fontSize: 16,
          fontWeight: FontWeight.normal),
    );

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return (CupertinoApp(
        theme: CupertinoThemeData(
          textTheme: _appTextTheme(context),
        ),
        debugShowCheckedModeBanner: false,
        title: 'Flutter Demo',
        home: _buildBloc(
          (context, state) => const HomeScreen(),
        )));
  }
}

// Ω
// Home Screen.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Localizations(
      delegates: const [
        DefaultCupertinoLocalizations.delegate,
        DefaultMaterialLocalizations.delegate,
        DefaultWidgetsLocalizations.delegate,
      ],
      locale: const Locale('en', 'UK'),
      child: Theme(
        data: ThemeData(
          textTheme: const TextTheme(
            titleMedium: TextStyle(
                fontFamily: "SF Pro Text",
                fontSize: 24,
                color: Colors.blue,
                fontWeight: FontWeight.w800),
            labelLarge: TextStyle(
              color: Colors.black87,
              fontSize: 13,
              letterSpacing: 0,
              fontFamily: "SF Pro Text",
              fontWeight: FontWeight.w400,
            ),
            labelMedium: TextStyle(
              fontFamily: 'SF Pro Text',
              fontSize: 11,
              fontWeight: FontWeight.w400,
              color: Colors.black87,
            ),
            labelSmall: TextStyle(
              fontFamily: 'SF Pro Text',
              fontSize: 10,
              fontWeight: FontWeight.w300,
              height: 2.3,
              color: Colors.grey,
            ),
          ),
        ),
        child: const Scaffold(
          // appBar: AppBar(
          //   title: Text('Dev Main II'),
          // ),
          body: ListOfTasksEditable(),
        ),
      ),
    );
  }
}

class ListOfTasksEditable extends StatefulWidget {
  const ListOfTasksEditable({super.key});

  @override
  State<ListOfTasksEditable> createState() => _ListOfTasksEditableState();
}

// Ω
// List of Tasks Editable State.
class _ListOfTasksEditableState extends State<ListOfTasksEditable> {
  late final ScrollController _scrollController;

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController();
  }
  // _buildAppBar() {
  //   return AppBar(
  //     toolbarHeight: 25,
  //     actions: [
  //       IconButton(
  //         onPressed: () {
  //           setState(() {
  //             showDialog<void>(
  //               context: context,
  //               barrierDismissible: false, // user must tap button!
  //               builder: (BuildContext context) {
  //                 return CupertinoAlertDialog(
  //                   title: const Text('Dev Main II'),
  //                   content: const Text('File: dev_main_ii.dart'),
  //                   actions: <Widget>[
  //                     CupertinoDialogAction(
  //                       child: const Text('OK'),
  //                       onPressed: () {
  //                         Navigator.of(context).pop();
  //                       },
  //                     ),
  //                   ],
  //                 );
  //               },
  //             );
  //           });
  //         },
  //         icon: const Icon(
  //           Icons.edit_note_outlined,
  //           color: Colors.black26,
  //           size: 18,
  //         ),
  //       ),
  //     ],
  //     backgroundColor: CupertinoColors.white,
  //     // title: Text('Tasks'),
  //   );
  // }

  _onPressed(){
      setState(() {
        showDialog<void>(
          context: context,
          barrierDismissible: false, // user must tap button!
          builder: (BuildContext context) {
            return CupertinoAlertDialog(
              title: const Text('Dev Main II'),
              content: const Text('File: dev_main_ii.dart'),
              actions: <Widget>[
                CupertinoDialogAction(
                  child: const Text('OK'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
      });
    }


  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: PreferredSize(
        preferredSize: const Size.fromHeight(25),
        child: _ScaffoldBar(
          handleOnPressed: _onPressed )
    ),
      backgroundColor: Colors.white,
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: CupertinoScrollbar(
          controller: _scrollController,
          thumbVisibility: true,
          child: ListView.builder(
            controller: _scrollController,
            itemCount: testTaskData.length,
            itemBuilder: (context, index) {
              return Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 18.0, vertical: 0),
                child: TaskCard(task: testTaskData[index]),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _ScaffoldBar extends StatelessWidget {
  const _ScaffoldBar({super.key, required this.handleOnPressed});
  final void Function() handleOnPressed;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      toolbarHeight: 25,
      actions: [
        IconButton(
          onPressed: handleOnPressed,
          // onPressed: () {
          //   setState(() {
          //     showDialog<void>(
          //       context: context,
          //       barrierDismissible: false, // user must tap button!
          //       builder: (BuildContext context) {
          //         return CupertinoAlertDialog(
          //           title: const Text('Dev Main II'),
          //           content: const Text('File: dev_main_ii.dart'),
          //           actions: <Widget>[
          //             CupertinoDialogAction(
          //               child: const Text('OK'),
          //               onPressed: () {
          //                 Navigator.of(context).pop();
          //               },
          //             ),
          //           ],
          //         );
          //       },
          //     );
          //   });
          // },
          icon: const Icon(
            Icons.edit_note_outlined,
            color: Colors.black26,
            size: 18,
          ),
        ),
      ],
      backgroundColor: CupertinoColors.white,
      // title: Text('Tasks'),
    );
  }
}


class TaskCard extends StatefulWidget {
  final TaskModel task;

  const TaskCard({super.key, required this.task});

  @override
  State<TaskCard> createState() => _TaskCardState();
}

// Ω
// Task Card State.
class _TaskCardState extends State<TaskCard> {
  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      shape: const LinearBorder(),
      leading: TaskPriorityFlag(priority: widget.task.priority),
      title: Text(widget.task.description,
          style: Theme.of(context).textTheme.titleMedium),
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width - 40,
          child: Column(children: [
            ...widget.task.actionItems
                .map((e) => ActionView(actionItem: e))
                // .map((e) => TextButton(onPressed: ()=> print('prezzed'), child: Text(e.toString())))
                .toList()
          ]),
        ),
      ],
    );
  }
}

///   📗
/// Task Priority Flag.
class TaskPriorityFlag extends StatelessWidget {
  final TaskPriority priority;

  const TaskPriorityFlag({super.key, required this.priority});

  @override
  Widget build(BuildContext context) {
    final color = priority == TaskPriority.high
        ? Colors.red
        : priority == TaskPriority.normal
            ? Colors.amber
            : Colors.green;
    return Icon(Icons.flag, color: color, size: 14);
  }
}

/// 📗
///  Actions View.
class ActionView extends StatefulWidget {
  final ActionItemModel actionItem;

  const ActionView({super.key, required this.actionItem});

  @override
  State<ActionView> createState() => _ActionViewState();
}

class _ActionViewState extends State<ActionView> {
  TextStyle? _labelStyle(context) => Theme.of(context).textTheme.labelSmall;
  late TextEditingController _textEditingController;
  late bool isSelected = false;
  late bool isEditing = false;

  @override
  void initState() {
    super.initState();
    _textEditingController =
        TextEditingController(text: widget.actionItem.action);
  }

  @override
  dispose() {
    _textEditingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(8.0),
        foregroundDecoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(color: Colors.black12, width: 1),
          ),
        ),
        child: Column(
          children: [
            Row(
                textBaseline: TextBaseline.ideographic,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CupertinoCheckbox(
                    side: const BorderSide(
                        style: BorderStyle.solid, width: .3, color: Colors.red),
                    value: isSelected,
                    onChanged: (a) {
                      setState(() {
                        isSelected = !isSelected;
                      });
                    },
                  ),
                  Expanded(
                      child: SizedBox(
                    height: 30,
                    width: MediaQuery.of(context).size.width - 40,
                    child: TextField(
                      autofocus: true,
                      readOnly: !isEditing,
                      onTapOutside: (s) {
                        setState(() {
                          isEditing = false;
                        });
                      },
                      decoration: InputDecoration(
                        prefixText: 'Action: ',
                        prefixStyle: _labelStyle(context),
                        hintText: 'Enter action',
                        border: InputBorder.none,
                      ),
                      onTap: () {
                        setState(() {
                          isEditing = true;
                        });
                      },
                      style: const TextStyle(
                        fontFamily: 'SF Pro Text',
                        fontSize: 13,
                        fontWeight: FontWeight.w400,
                        color: Colors.black87,
                      ),
                      controller: _textEditingController,
                    ),
                  ))
                ]),
            Row(
              children: [
                SizedBox(
                  height: 60,
                    width: 300,
                    child: DatePickerMacOs2(
                        onDateSelected: (d) => print(d))
                ),
              ],
            ),
          ],
        ));
  }
}

