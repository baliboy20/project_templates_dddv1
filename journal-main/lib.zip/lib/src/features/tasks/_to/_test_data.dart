
 import '../domain/entities/task_entity.dart';

final testTaskData = [
  TaskModel(
    id: '1',
    description: 'I want to sell mince pies',
    from: DateTime.now(),
    to: DateTime.now().add(Duration(days: 1)),
    status: ActionStatus.pending,
    priority: TaskPriority.normal,
    actionItems: [
      ActionItemModel(
        id: '1',
        action: 'Buy the right flour',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '2',
        action: 'Mix it up',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
    ],
  ),
  TaskModel(
    id: '2',
    description: 'Present for xmas',
    from: DateTime.now(),
    to: DateTime.now().add(Duration(days: 1)),
    status: ActionStatus.pending,
    priority: TaskPriority.normal,
    actionItems: [
      ActionItemModel(
        id: '1',
        action: 'Buy presents for everyone, but in the event I cant find the one i want to buy, I will have to make it',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '2',
        action: 'Design Xmas cards',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '3',
        action: 'Decorate presents with ribbons',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
       ///...again
      ActionItemModel(
        id: '4',
        action: 'Wrap for posting',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '5',
        action: 'Goto the post office',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '6',
        action: 'Write greetings cards',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
      ActionItemModel(
        id: '7',
        action: 'Buy stamps',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.pending,
        completedOn: null,
      ),
    ],
  ),
  TaskModel(
    id: '3',
    description: 'Task 3',
    from: DateTime.now(),
    to: DateTime.now().add(Duration(days: 1)),
    status: ActionStatus.pending,
    priority: TaskPriority.high,
    actionItems: [
      ActionItemModel(
        id: '1',
        action: 'Action 1',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)),
        status: ActionStatus.inProgress,
        completedOn: null,

      ),
      ActionItemModel(
        id: '2',
        action: 'Action 2',
        from: DateTime.now(),
        completeBy: DateTime.now().subtract(Duration(days: 10)),
        status: ActionStatus.completed,
        completedOn:  DateTime.now().subtract(Duration(days: 3),
      )),
    ],
  ),



];