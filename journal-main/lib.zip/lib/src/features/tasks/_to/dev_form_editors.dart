part of 'dev_main.dart';

class TaskEditor extends StatefulWidget {
  final TaskModel task;

  const TaskEditor({super.key, required this.task});

  @override
  State<TaskEditor> createState() => _TaskEditorState();
}

class _TaskEditorState extends State<TaskEditor> {
  late final TextEditingController _descriptionController;
  late final List<ActionItemModel> _actionItems;
  late DateTime? _fromDate;
  late DateTime? _toDate;
  late TaskPriority _priority;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _descriptionController = TextEditingController(text: widget.task.description);
  }
  TextStyle _labelStyle(context) => Theme.of(context).textTheme.labelSmall!.copyWith(color:  Colors.grey.shade600);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context,constaints){
        print('maxHeight: ${constaints.minWidth}');
        return  ConstrainedBox(
            constraints: BoxConstraints(
                maxHeight: 400,
                maxWidth: MediaQuery.of(context).size.width,
            ),

              child: CustomScrollView(
                shrinkWrap: false,

                slivers: [
                  SliverAppBar(
                    pinned: false,
                    floating: true,
                    flexibleSpace: FlexibleSpaceBar(
                      title:  Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: TextField(
                          controller: _descriptionController,
                          decoration: InputDecoration(
                            prefixText: 'Task: ',
                            prefixStyle: _labelStyle(context),
                            hintText: 'Enter task name',
                          ),
                        ),
                      ),
                    ),
                  ),
                  SliverList.list(children:[
                  // TextField(
                  //   controller: _descriptionController,
                  //   decoration: InputDecoration(
                  // prefixText: 'Task: ',
                  //     prefixStyle: _labelStyle(context),
                  //
                  //     hintText: 'Enter task name',
                  //   ),
                  // ),
                ]),
                    SliverList.list(children: [
                      ..._actionsBuilder(widget.task.actionItems),
                    ])

        ]
              )
        );
      }
    );
  }

  List<Widget> _actionsBuilder(List<ActionItemModel> actionItems) {
    return actionItems
        .map<Widget>((arg) => ActionEditor(actionItemModel: arg))
        .toList();
  }
}

class ActionEditor extends StatefulWidget {
  final ActionItemModel actionItemModel;

  const ActionEditor({super.key, required this.actionItemModel});

  @override
  State<ActionEditor> createState() => _ActionEditorState();
}

class _ActionEditorState extends State<ActionEditor> {
  late final TextEditingController _controller;
  late DateTime _from;
  late DateTime? _completeBy;


@override
  void didUpdateWidget(covariant ActionEditor oldWidget) {
    if (oldWidget.actionItemModel != widget.actionItemModel) {
      _controller.text = widget.actionItemModel.action;
      _from = widget.actionItemModel.from;
      _completeBy = widget.actionItemModel.completeBy;
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.actionItemModel.action);
    _from = widget.actionItemModel.from;
    _completeBy = widget.actionItemModel.completeBy;
  }

  String get _fromFormatted => _from != null ? '${_from.day}-${_from.month}-${_from.year}' : '';

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width,
          maxHeight: 100),
      color: Colors.blue.shade50,
      // padding: const EdgeInsets.all(38.0),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                prefixText: 'Action: ',
                prefixStyle: Theme.of(context).textTheme.labelSmall!.copyWith(color: Colors.grey.shade600),
                hintText: 'Enter action',
              ),
            ),
          ),
          Expanded(
            child: TextButton.icon(
                label: Text('From: ${_fromFormatted}'),
                onPressed: ()=>_chooseDate(_from), icon: Icon(Icons.calendar_today)),
          ),
         ],

      ),
    );
  }

  _chooseDate(DateTime? arg) async {
    final date = await showDatePicker(
      context: context,
      initialDate: arg ?? DateTime.now(),
      firstDate: DateTime.now().subtract(const Duration(days: 7)),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (date != null) {
      setState(() {
        _from = date;
      });
    }
  }
}
