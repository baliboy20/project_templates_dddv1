
// Example test data with varied titles, categories, bodies, and authors
import 'package:bson/bson.dart';

import '../../../domain/entities/snippet_entity.dart';
import '../../models/snippet_vo.dart';

final List<SnippetVo> SnippetsTestData = [
   SnippetVo(
    title: 'Introduction to Flutter',
    categories: ['Programming', 'Flutter'],
    body: 'Learn the basics of Flutter development.',
    createdOn: DateTime(2023, 1, 15),
    postedBy: 'Alice',
    id: null,
  ),
  SnippetVo(
    title: 'Advanced Dart Tips',
    categories: ['Programming', 'Dart'],
    body: 'Explore advanced techniques in Dart.',
    id: null,    createdOn: DateTime(2023, 2, 5),
    postedBy: 'Bob',
  ),
  SnippetVo(
    title: 'Flutter State Management',
    categories: ['Flutter', 'State Management'],
    body: 'Understand state management in Flutter.',
    id: null,    createdOn: DateTime(2023, 2, 20),
    postedBy: 'Alice',
  ),
  SnippetVo(
    title: 'Dependency Injection in Flutter',
    categories: ['Flutter', 'DI'],
    body: 'How to use dependency injection effectively.',
    id: null,    createdOn: DateTime(2023, 3, 1),
    postedBy: 'Charlie',
  ),
  SnippetVo(
    title: 'Networking in Flutter',
    categories: ['Networking', 'Flutter'],
    body: 'Integrate REST APIs in your Flutter apps.',
    id: null,    createdOn: DateTime(2023, 3, 10),
    postedBy: 'Alice',
  ),
  SnippetVo(
    title: 'Error Handling in Dart',
    categories: ['Programming', 'Error Handling'],
    body: 'Handle errors gracefully in Dart.',
    id: null,
    createdOn: DateTime(2023, 3, 15),
    postedBy: 'Bob',
  ),
  SnippetVo(
    title: 'Animations in Flutter',
    categories: ['Flutter', 'UI'],
    body: 'Create smooth animations in Flutter.',
    id: null,
    createdOn: DateTime(2023, 3, 25),
    postedBy: 'Alice',
  ),
  SnippetVo(
    title: 'Debugging Dart Code',
    categories: ['Programming', 'Debugging'],
    body: 'Effective debugging techniques for Dart.',
    id: null,
    createdOn: DateTime(2023, 4, 5),
    postedBy: 'Charlie',
  ),
  SnippetVo(
    title: 'Responsive Design in Flutter',
    categories: ['Flutter', 'UI', 'Design'],
    body: 'Build responsive layouts in Flutter.',
    id: null,
    createdOn: DateTime(2023, 4, 15),
    postedBy: 'Alice',
  ),
  SnippetVo(
    title: 'Local Database with SQLite',
    categories: ['Flutter', 'Database'],
    body: 'Learn how to use SQLite in Flutter.',
    id: null,
    createdOn: DateTime(2023, 4, 20),
    postedBy: 'Bob',
  ),
  SnippetVo(
    title: 'Custom Widgets in Flutter',
    categories: ['Flutter', 'UI'],
    body: 'Create reusable custom widgets.',
    id: null,
    createdOn: DateTime(2023, 5, 1),
    postedBy: 'Alice',
  ),

];
