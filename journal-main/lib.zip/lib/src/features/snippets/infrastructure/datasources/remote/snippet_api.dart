import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/datasources/mappers/json_snippetvo_mappers.dart';

import '../../models/snippet_vo.dart';



class SnippetApi extends CrudHttpApiImpl<SnippetVo> {


  SnippetApi(
       {required String baseUrl}
      ):super(
    fromJsonFactory: JsonSnippetVoMapper.decodeJsonList,
    toJsonFactory: JsonSnippetVoMapper.encodeSnippetVo,
    baseUrl: baseUrl,
  );

  @override
  Future<SnippetVo> createItem(SnippetVo item) async{
    return super.createItem(item);
  }

  @override
  Future<bool> deleteItemById(String id) async{
    return super.deleteItemById(id);
  }

  @override
  Future<List<SnippetVo>> filterItems(Map<String, dynamic> criteria) {
    return super.filterItems(criteria);
  }

  @override
  Future<SnippetVo> findItemById(String id) {
    return super.findItemById(id);
  }

  @override
  Future<List<SnippetVo>> findItemsByTitle(String title) {
    return super.findItemsByTitle(title);
  }

  @override
  Future<List<SnippetVo>> getAllItems() {
    return super.getAllItems();
  }

  @override
  Future<bool> sayHello() {
    return super.sayHello();
  }

  @override
  Future<SnippetVo> updateItem(SnippetVo item) {
    return super.updateItem(item);
  }

// Future<bool> sayHello() async {
//     final response = await http.get(Uri.parse('$baseUrl/hello'));
//     if (response.statusCode == 200) {
//       return true;
//     } else {
//       throw Exception('Failed to say hello');
//     }
// }
//   // Fetch all snippets
//   Future<List<dynamic>> getAllSnippets() async {
//     final response = await http.get(Uri.parse('$baseUrl/findAll'));
//     if (response.statusCode == 200) {
//       final str = jsonDecode(response.body) as List;
//       return str;
//     } else {
//       throw Exception('Failed to load snippets');
//     }
//   }
//
//   // Find snippets by title
//   Future<List<dynamic>> findSnippetsByTitle(String title) async {
//     final response = await http.get(Uri.parse('$baseUrl/findBy?title=$title'));
//     if (response.statusCode == 200) {
//       return jsonDecode(response.body) as List;
//     } else {
//       throw Exception('Failed to find snippets by title');
//     }
//   }
//
//   // Create a new snippet
//   Future<Map<String, dynamic>> createSnippet(SnippetVo snippet) async {
//     final response = await http.post(
//       Uri.parse('$baseUrl/add-one'),
//       headers: {'Content-Type': 'application/json'},
//       body: jsonEncode(snippet.toJson()),
//     );
//     if (response.statusCode == 200) {
//       return jsonDecode(response.body);
//     } else {
//       throw Exception('Failed to create snippet');
//     }
//   }
//
//   // Update an existing snippet
//   Future<bool> updateSnippet(SnippetVo snippet) async {
//    try {
//      print('id');
//      print(snippet.id);
//       final response = await http.post(
//         Uri.parse('$baseUrl/updateOne'),
//         headers: {'Content-Type': 'application/json'},
//         body: jsonEncode(snippet.toJson()),
//       );
//       if (response.statusCode == 200) {
//         return true;
//       } else {
//         throw Exception('Failed to update snippet');
//       }
//     } catch (e) {
//       throw Exception('Failed to update snippet: $e');
//     }
//   }
//
//   // Delete a snippet by ID
//   Future<Map<String, dynamic>> deleteSnippetById(String id) async {
//     final response = await http.delete(Uri.parse('$baseUrl/deleteById/$id'));
//     if (response.statusCode == 200) {
//       return jsonDecode(response.body);
//     } else {
//       throw Exception('Failed to delete snippet');
//     }
//   }
//
//   // Filter snippets based on criteria
//   Future<List<dynamic>> filterSnippets(Map<String, dynamic> criteria) async {
//     final response = await http.post(
//       Uri.parse('$baseUrl/filterItems'),
//       headers: {'Content-Type': 'application/json'},
//       body: jsonEncode(criteria),
//     );
//     if (response.statusCode == 200) {
//       return jsonDecode(response.body) as List;
//     } else {
//       throw Exception('Failed to filter snippets');
//     }
//   }
}
