import 'package:bson/bson.dart';
import 'package:equatable/equatable.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';

import '../../infrastructure/models/snippet_vo.dart';


class SnippetEntity extends Equatable  implements EntityMappable{
  final String title;
  final List<String> categories;
  final String body;
  final String? id; // Unique identifier
  final DateTime createdOn;
  final String postedBy;

  SnippetEntity({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  });

  /// Factory method to create an Entity from a Value Object (Vo)
  factory SnippetEntity.fromVo(SnippetVo vo) {
    return SnippetEntity(
      title: vo.title,
      categories: vo.categories,
      body: vo.body,
      id: vo.id ?? '', // Ensure non-null id (or assign default if needed)
      createdOn: vo.createdOn,
      postedBy: vo.postedBy,
    );
  }

  dynamic copyWith(arg) {
    return SnippetEntity(
      title: title,
      categories: categories,
      body: body,
      id: id,
      createdOn: createdOn,
      postedBy: postedBy,
    );
  }

  /// Method to convert the Entity back to a Value Object (Vo)
 ValueObjectMappable  toVo() {
    return SnippetVo(
      title: title,
      categories: categories,
      body: body,
      id:  id  ?? ObjectId().$oid, // Ensure non-null id (or assign default if needed)
      createdOn: createdOn,
      postedBy: postedBy,
    );
  }





  /// Define props for Equatable to consider `id` as the unique property
  @override
  List<Object?> get props => [id];

  factory SnippetEntity. empty() {
    return SnippetEntity(
      title: '',
      categories: [],
      body: '',
      id: ObjectId().toHexString(),
      createdOn: DateTime.now(),
      postedBy: 'William',
    );
  }
}
