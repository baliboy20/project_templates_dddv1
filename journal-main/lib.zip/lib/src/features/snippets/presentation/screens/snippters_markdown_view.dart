import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:journal_macos/src/features/snippets/domain/entities/snippet_entity.dart';

class SnippetsMarkdownView extends StatefulWidget {
  final List<SnippetEntity> snippets;

  const SnippetsMarkdownView({super.key, required this.snippets});

  @override
  State<SnippetsMarkdownView> createState() => _SnippetsMarkdownViewState();
}

class _SnippetsMarkdownViewState extends State<SnippetsMarkdownView> {
  @override
  Widget build(BuildContext context) {
    return NestedScrollView(
      body: CustomScrollView(
        shrinkWrap: true,
        slivers: [
          SliverList(
            delegate: SliverChildBuilderDelegate(
              childCount: widget.snippets.length,
              (BuildContext context, int index) {
                return Card(
                    elevation: 10,
                    margin: EdgeInsets.all(30),
                    color: Colors.blueGrey[100],

                    // height: 100,

                    // width: MediaQuery.sizeOf(context ).width -200,

                    // child: Text(widget.snippets[index].body));
                    child: ConstrainedBox(constraints: BoxConstraints(maxHeight: 3500),

                        child: MarkdownBody(data: widget.snippets[index].body)));
              },
            ),
          ),
        ],
      ),
      headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
        return <Widget>[];
      },
    );
  }
}
