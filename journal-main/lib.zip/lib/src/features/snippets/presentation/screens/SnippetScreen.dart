// Import necessary packages
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:journal_macos/src/features/snippets/presentation/screens/snippters_markdown_view.dart';
import '../../domain/entities/snippet_entity.dart';
import '../blocs/snippet_bloc.dart';
import '../blocs/snippet_events.dart';
import '../blocs/snippet_states.dart';

class SnippetsScreen extends StatefulWidget {
  static const routeName = '/snippets';
  static const routeLabel = 'Snippets';

  const SnippetsScreen({super.key});

  static MaterialPageRoute genRoute() {
    return MaterialPageRoute(
      settings: const RouteSettings(name: routeName),
      builder: (_) => const SnippetsScreen(),
    );
  }

  @override
  State<SnippetsScreen> createState() => _SnippetsScreenState();
}

class _SnippetsScreenState extends State<SnippetsScreen>
    with SingleTickerProviderStateMixin {
  bool _isPreviewState = false;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80),
        child: AppBar(
            backgroundColor: Colors.teal,
            scrolledUnderElevation: 40,
            actions: [
              Container(
                width: 75,
                margin: const EdgeInsets.only(right: 20),
                color: Colors.teal[200]?.withOpacity(.7),
                child: OverflowBar(
                  spacing: -15,
                  alignment: MainAxisAlignment.end,
                  children: [
                    SizedBox(width: 20),
                    IconButton(
                        icon: const Icon(
                          Icons.preview,
                          color: Colors.white70,
                        ),
                        onPressed: () => _tabController.index = 0),
                    SizedBox(width: 20),
                    IconButton(
                        icon: const Icon(
                          Icons.edit_document,
                          color: Colors.white70,
                        ),
                        onPressed: () => _tabController.index = 1),
                  ],
                ),
              ),
            ],
            leading: IconButton(
              icon: const Icon(
                Icons.arrow_back_ios_rounded,
                color: Colors.white,
              ),
              onPressed: () => Navigator.pop(context),
            )),
      ),
      body: BlocConsumer<SnippetBloc, SnippetState>(
        listener: (context, state) {
          if (state is SnippetError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text(state.message), backgroundColor: Colors.red),
            );
          } else if (state is SnippetNotification) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text(state.message), backgroundColor: Colors.green),
            );
          }
        },
        listenWhen: (previous, current) =>
            current is SnippetError || current is SnippetNotification,
        builder: (context, state) {
          if (state is Loading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is SnippetsLoaded) {
            return SnippetListingView(snippets: state.snippets);
            // return TabBarView(controller: _tabController, children: [
            //   SnippetListingView(snippets: state.snippets),
            //   SnippetsMarkdownView(snippets: state.snippets),
            // ]);
          } else if (state is SnippetSaving) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is SnippetSelectedForChanging) {
            return SnippetFormScreen(snippet: state.snippet);
          } else if (state is SnippetError) {
            return Center(child: Text('Error: ${state.message}'));
          } else {
            return const Center(child: Text('Welcome to the Snippet Manager!'));
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showBottomSheetNew(context, SnippetEntity.empty()),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showBottomSheetNew(BuildContext context, SnippetEntity snippet) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: SnippetFormScreen(snippet: snippet),
        );
      },
    );
  }
}

class SnippetListingView extends StatefulWidget {
  final List<SnippetEntity> snippets;

  SnippetListingView({super.key, required this.snippets});

  @override
  State<SnippetListingView> createState() => _SnippetListingViewState();
}

class _SnippetListingViewState extends State<SnippetListingView> {
  SnippetEntity? _snippet;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      shrinkWrap: true,
      itemCount: widget.snippets.length,
      itemBuilder: (context, index) {
        final snippet = widget.snippets[index];
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 18.0),
          child: _SnippetTile(snippet: snippet),
        );
      },
    );
  }

  Future<bool> _showMarkdownDialog(
      BuildContext context, SnippetEntity snippet) async {
    return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text(snippet.title),
              content: Container(
                height: MediaQuery.sizeOf(context).height - 100,
                width: MediaQuery.sizeOf(context).width,
                child: Markdown(
                    styleSheet: MarkdownStyleSheet.fromTheme(Theme.of(context)),
                    data: snippet.body),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Close'),
                ),
              ],
            );
          },
        ) ??
        false;
  }

// Future<bool> _showDeleteConfirmationDialog(
//     BuildContext context, String snippetBody) async {
//   return await showDialog(
//         context: context,
//         builder: (BuildContext context) {
//           return AlertDialog(
//             title: const Text('Confirm Delete'),
//             content: Text(snippetBody),
//             actions: [
//               TextButton(
//                 onPressed: () => Navigator.of(context).pop(false),
//                 child: const Text('Cancel'),
//               ),
//               TextButton(
//                 onPressed: () => Navigator.of(context).pop(true),
//                 child:
//                     const Text('Delete', style: TextStyle(color: Colors.red)),
//               ),
//             ],
//           );
//         },
//       ) ??
//       false;
// }

// void _showBottomSheet(BuildContext context, SnippetEntity snippet) {
//   showModalBottomSheet(
//     context: context,
//     isScrollControlled: true,
//     builder: (BuildContext context) {
//       return Padding(
//         padding:
//             EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
//         child: SnippetFormScreen(snippet: snippet),
//       );
//     },
//   );
// }
}

class _SnippetTile extends StatefulWidget {
  final dynamic
      snippet; // Replace 'dynamic' with the appropriate type for 'snippet'

  const _SnippetTile({
    Key? key,
    required this.snippet,
  }) : super(key: key);

  @override
  _SnippetTileState createState() => _SnippetTileState();
}

class _SnippetTileState extends State<_SnippetTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _radiusAnimation;
  final ScrollController _scrollController = ScrollController();
  late bool _showMarkdown = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _showMarkdown = true;
    if (!_controller.isAnimating) _controller.toggle();
  }

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );
    //

    _radiusAnimation = Tween<double>(begin: .5, end: 6).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.linear,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _radiusAnimation,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            border: Border.all(color: Colors.yellow.shade500, width: 2),
            gradient: RadialGradient(
              colors: [Colors.red, Colors.yellow, Colors.blue],
              // Gradient colors
              center: Alignment.center,
              // Center of the gradient
              radius: _radiusAnimation.value, // Animated radius
            ),
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.red,
                offset: const Offset(0, 14),
                blurRadius: 1,
              ),
              BoxShadow(
                color: Colors.yellow,
                offset: const Offset(0, 10),
                blurRadius: 1,
              ),
              BoxShadow(
                color: Colors.orange,
                offset: const Offset(0, 4),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _TileTitleLine(
                  title: widget.snippet.title,
                  EditFn: () => _showBottomSheet(
                      context, widget.snippet)), // Adjusted widget name
              const SizedBox(height: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    _showMarkdown = !_showMarkdown;
                    setState(() {});
                  },
                  child: Container(
                    constraints: BoxConstraints(

                      minWidth: MediaQuery.of(context).size.width - 30,
                      maxWidth: MediaQuery.of(context).size.width - 30,
                    ),
                    margin: const EdgeInsets.symmetric(vertical: 28.0),
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: _showMarkdown ? Colors.white.withOpacity(.8)
                      : Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: (_showMarkdown)
                        ? MarkdownBody(data: widget.snippet.body)
                        : Text(
                            widget.snippet.body,
                            softWrap: true,
                            overflow: TextOverflow.ellipsis,
                          ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  void _showBottomSheet(BuildContext context, SnippetEntity snippet) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: SnippetFormScreen(snippet: snippet),
        );
      },
    );
  }
}

class _TileTitleLine extends StatefulWidget {
  final String title;
  final Function EditFn;

  const _TileTitleLine({
    Key? key,
    required this.EditFn,
    required this.title,
  }) : super(key: key);

  @override
  State<_TileTitleLine> createState() => _TileTitleLineState();
}

class _TileTitleLineState extends State<_TileTitleLine> {
  late double _blurRadius = 0.3;

  @override
  Widget build(BuildContext context) {
    return Flexible(
      fit: FlexFit.loose,
      child: Container(
        padding: const EdgeInsets.all(16.0),
        alignment: Alignment.center,
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width,
          minWidth: MediaQuery.of(context).size.width,
          maxHeight: 70,
        ),
        color: Colors.red.withOpacity(.9),
        child: InkWell(
          hoverColor: Colors.blueGrey.withOpacity(.2),
          splashColor: Colors.black,
          onLongPress: () {
            print('Tapped');
            widget.EditFn();
          },
          onHover: (hovering) {
            print('Hovering: $hovering');
            _blurRadius = hovering ? 4.1 : 0.3;
            setState(() {});
          },
          child: RichText(
            text: TextSpan(
              children: [

                TextSpan(
                  text: ' ${widget.title}', // Add a space to separate the icon and text
                  style: TextStyle(
                    shadows: [
                      Shadow(
                        color: Color(0xFFF6C2B0),
                        offset: Offset(.01 * _blurRadius, .1),
                        blurRadius: _blurRadius,
                      ),
                    ],
                    height: 2,
                    color: Colors.black87,
                    fontSize: 18,
                    fontFamily: 'SF Pro Display',
                    fontWeight: FontWeight.w400,
                    letterSpacing: 1.6,
                  ),
                ),
                WidgetSpan(
                  baseline: TextBaseline.ideographic,
                  child: Icon(
                    Icons.edit,
                    size: 13, // Match the font size of the text
                    color: Colors.orangeAccent,
                    shadows: [
                      Shadow(
                        color: Color(0xFFF6F4F3),
                        offset: Offset(.3 * _blurRadius, .1),
                        blurRadius: _blurRadius,
                      ),
                    ],
                  ),
                  alignment: PlaceholderAlignment.top, // Align icon vertically with the text
                )
              ],
            ),
            softWrap: false,
            overflow: TextOverflow.ellipsis,
          )
          ,
        ),
      ),
    );
  }
}

class SnippetFormScreen extends StatelessWidget {
  final SnippetEntity? snippet;

  SnippetFormScreen({this.snippet});

  @override
  Widget build(BuildContext context) {
    final titleController = TextEditingController(text: snippet?.title ?? '');
    final contentController = TextEditingController(text: snippet?.body ?? '');

    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Snippet',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal, Colors.tealAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(
                labelText: 'Title',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: contentController,
              maxLines: 39,
              decoration: InputDecoration(
                labelText: 'Content',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                OutlinedButton.icon(
                  onPressed: () {
                    BlocProvider.of<SnippetBloc>(context).add(SaveChanges(
                      SnippetEntity(
                        id: snippet!.id,
                        title: titleController.text,
                        body: contentController.text,
                        categories: [],
                        createdOn: DateTime.now(),
                        // categories: selectedCategories.toList(),

                        postedBy: snippet!.postedBy,
                      ),
                    ));
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.save),
                  label: const Text('Save'),
                ),
                OutlinedButton.icon(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.cancel),
                  label: const Text('Cancel'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
