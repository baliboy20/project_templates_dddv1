//============================================================
// template created on: 2023-06-14 16:48:22.699667
// version: 1.1
//============================================================





import 'package:flutter/cupertino.dart';

class FadingListTile extends StatefulWidget {
  final Widget customTile;
  FadingListTile({Key? key, required this.customTile}) : super(key: key);

  @override
  _FadingListTileState createState() => _FadingListTileState();
}

class _FadingListTileState extends State<FadingListTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();
    super.initState();
    // print('init state fading list tile');
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: widget.customTile ?? Text('CustomTile not appearing'),
    );
  }
}
