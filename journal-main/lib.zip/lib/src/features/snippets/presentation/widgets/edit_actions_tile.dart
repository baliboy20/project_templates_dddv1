//============================================================
// template created on: 2023-06-14 16:48:22.698892
// version: 1.1
//============================================================

import 'package:flutter/material.dart';
import 'package:journal_macos/src/features/dev_journal/presentation/widgets/records_actions_toolbar.dart';

import 'fading_list_tile.dart';

class EditActionsTile extends StatefulWidget {
  // final void Function(OperationType? operationType) operationFn;
  final String line1;
  final String line2;
  final String line3;
  final String searchTerms;
  final List<String> lines = List.filled(3, "");
  final Function addItemfn;
  final Function removeItemfn;
  final Function amendItemfn;

  // EditActionsTile({Key? key}) : super(key: key);
  EditActionsTile(
      {required this.addItemfn,
      required this.amendItemfn,
      required this.removeItemfn,
      required this.line1,
      required this.line2,
      required this.line3,
      required this.searchTerms}
      );

  @override
  State<EditActionsTile> createState() => _EditActionsTileState();
}

class _EditActionsTileState extends State<EditActionsTile> {
  final TextEditingController _searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 12),
      child: Container(
        decoration: BoxDecoration(
            color: Colors.blueGrey.shade50,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3),
              )
            ]),
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: FadingListTile(
              customTile: Column(
            children: [
              RecordsActionsToolbar(
                additem: widget.addItemfn,
                removeItem: widget.removeItemfn,
                amendItem: widget.amendItemfn,
              ),
              _highlightText(widget.line1, widget.searchTerms),
              SizedBox(height: 10,),
              _highlightText(widget.line2, widget.searchTerms),
              SizedBox(height: 10,),
              _highlightText(widget.line3, widget.searchTerms),
            ],
          )),
        ),
      ),
    );
  }

  RichText _highlightText(String mytext, String termz) {
    final RegExp exp = RegExp(termz, caseSensitive: false);
    final List<dynamic> matches =
        exp.allMatches(mytext).map((match) => match.group(0)).toList();

    final List<TextSpan> textSpans = [];
    final List<String> substrings = mytext.split(exp);

    for (var i = 0; i < substrings.length; i++) {
      if (substrings[i].isNotEmpty) {
        textSpans.add(TextSpan(
          text: substrings[i],
          style: TextStyle(color: Colors.grey.shade700),
        ));
      }
      if (i < matches.length) {
        //    print('matches? ${matches}');
        textSpans.add(TextSpan(
          text: matches[i],
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red.shade400),
        ));
      }
    }

    return RichText(
      text: TextSpan(children: textSpans),
    );
  }
}
