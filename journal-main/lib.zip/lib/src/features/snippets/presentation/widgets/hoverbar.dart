/*
 * Toolbar that appears when hovering over a tile.
 */
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HoverBar extends StatefulWidget {
  // widget to behave as a bar.
  final Widget bar;

  const HoverBar({Key? key, required this.bar}) : super(key: key);

  @override
  State<HoverBar> createState() => _HoverBarState();
}

class _HoverBarState extends State<HoverBar> {
  double _opacity = 0.2;
  double _width = 210;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      child: OverflowBox(
        maxWidth: 240,
        minWidth: 90,
        maxHeight: 140,
        minHeight: 80,


        child: AnimatedContainer(
          color: Colors.blueAccent,
          width: _width,
            height: 60,
            duration: Duration(milliseconds: 550),
            child: Opacity(opacity: _opacity, child: widget.bar)),
      ),
      onEnter: (event) => setState(() {
        _opacity = 1;
        _width = 90;
        
      }),
      onExit: (event) => setState(() {
        _opacity = 0.1;
        _width = 210;
      }),
    );
  }
}

// 🐤
class HoverIcon extends StatefulWidget {
  const HoverIcon({super.key});

  @override
  _HoverIconState createState() => _HoverIconState();
}

class _HoverIconState extends State<HoverIcon> {
  Color _iconColor = Colors.grey;
  final double _exitSize = 12;
  final double _enterSize = 19;
  late double _boundSize = 10;

  @override
  void initState() {
    _boundSize = _exitSize;
    super.initState();
  }

  void _onEnter(PointerEvent details) {
    setState(() {
      _iconColor = Colors.blue;
      _boundSize = _enterSize;
    });
  }

  void _onExit(PointerEvent details) {
    setState(() {
      _iconColor = Colors.grey;
      _boundSize = _exitSize;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: _onEnter,
      onExit: _onExit,
      child: Icon(
        Icons.favorite,
        color: _iconColor,
        size: _boundSize,
      ),
    );
  }
}
