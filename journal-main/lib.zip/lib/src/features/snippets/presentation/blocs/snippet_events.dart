// journal_event.dart
import 'package:equatable/equatable.dart';
import '../../domain/entities/snippet_entity.dart';


abstract class SnippetEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class InitSnippets extends SnippetEvent {}



class LoadSnippets extends SnippetEvent {}

class DeleteSnippet extends SnippetEvent {
  final String id;
  DeleteSnippet(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectSnippet extends SnippetEvent {
  final SnippetEntity id;
  SelectSnippet(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends SnippetEvent {
  final SnippetEntity journal;
  SaveChanges(this.journal);

  @override
  List<Object?> get props => [journal];
}

