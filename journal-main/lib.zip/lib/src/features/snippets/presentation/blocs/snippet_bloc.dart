// journal_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/models/snippet_vo.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_events.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_states.dart';

import '../../domain/entities/snippet_entity.dart';

 

class    SnippetBloc extends Bloc<SnippetEvent, SnippetState> {
  final List<SnippetEntity> items = [];
  final CrudRepositoryImpl<SnippetEntity,SnippetVo> repository;

  SnippetBloc({required this.repository}) : super(Loading()) {
    on<LoadSnippets>(_onLoadSnippets);
    on<DeleteSnippet>(_onDeleteSnippet);
    on<SelectSnippet>(_onSelectSnippet);
    on<SaveChanges>(_onSaveChanges);

  }

  void _onLoadSnippets(LoadSnippets event, Emitter<SnippetState> emit) async {

    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    final List<SnippetEntity> items = await repository.getAllItems();
    emit(SnippetsLoaded(items..sort((a, b) => b.createdOn.compareTo(a.createdOn))));
  }

  void _onDeleteSnippet(DeleteSnippet event, Emitter<SnippetState> emit)async {
   try {
      final result = repository.deleteItemById(event.id);
      final List<SnippetEntity> items = await repository.getAllItems();
      emit(SnippetsLoaded(items));
    } catch (e) {
      emit(SnippetError('Fail : $e'));
    }
  }

  void _onSelectSnippet(SelectSnippet event, Emitter<SnippetState> emit) {
    // find index of selected journal and remplace it with the new one
    final selectedSnippet = items.firstWhere(
      (journal) => journal.id == event.id,
      orElse: () => SnippetEntity(
          id: '',
          title: '',
          body: '',
          categories: [],
          createdOn: DateTime.now(),
          postedBy: ''),
    );
    emit(SnippetSelectedForChanging(selectedSnippet));
  }

  void _onSaveChanges(SaveChanges event, Emitter<SnippetState> emit) async {
    emit(SnippetSaving());
    try {
      final reply = await repository.updateItem(event.journal);
      emit(SnippetsLoaded(reply));
      emit(SnippetNotification('Changes saved'));

    } catch (e) {
      emit(SnippetError('Fail : $e'));
      await Future.delayed(Duration(milliseconds: 500));
      final List<SnippetEntity> items = await repository.getAllItems();
      emit(SnippetsLoaded(items));
    }
  }

}
