// journal_state.dart
import 'package:equatable/equatable.dart';
import 'package:journal_macos/src/features/snippets/domain/entities/snippet_entity.dart';
 
 

abstract class SnippetState extends Equatable {
  @override
  List<Object?> get props => [];
}

class Loading extends SnippetState {}

class SnippetsLoaded extends SnippetState {
  final List<SnippetEntity> snippets;
  SnippetsLoaded(this.snippets);

  @override
  List<Object?> get props => [snippets];
}

class SnippetSelectedForChanging extends SnippetState {
  final SnippetEntity snippet;
  SnippetSelectedForChanging(this.snippet);

  @override
  List<Object?> get props => [snippet];
}

/// shows progress button.
class SnippetSaving extends SnippetState {}

class SnippetNotification extends SnippetState {
  final String message;
  SnippetNotification(this.message);

  @override
  List<Object?> get props => [message];
}

class NewSnippet extends SnippetState {}

class SnippetError extends SnippetState {
  final String message;
  SnippetError(this.message);

  @override
  List<Object?> get props => [message];
}