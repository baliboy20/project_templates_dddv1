// journal_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/features/journals/infrastructure/models/journal_vo.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_events.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_states.dart';

import '../../domain/entities/journal_entity.dart';
import '../../infrastructure/repositories/journal_interface.dart';

class    JournalBloc extends Bloc<JournalEvent, JournalState> {
  final List<JournalEntity> _journals = [];
  final JournalRepository repository;

  JournalBloc({required this.repository}) : super(Loading()) {
    on<LoadJournals>(_onLoadJournals);
    on<DeleteJournal>(_onDeleteJournal);
    on<SelectJournal>(_onSelectJournal);
    on<SaveChanges>(_onSaveChanges);

  }

  void _onLoadJournals(LoadJournals event, Emitter<JournalState> emit) async {

    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    final List<JournalEntity> _journals = await repository.getAllJournals();
      _journals.sort((a, b) => b.createdOn.compareTo(a.createdOn));
    emit(JournalsLoaded(_journals));
  }

  void _onDeleteJournal(DeleteJournal event, Emitter<JournalState> emit)async {
   try {
      final result = repository.deleteJournalById(event.id);
      final List<JournalEntity> _journals = await repository.getAllJournals()..sort((a, b) => b.createdOn.compareTo(a.createdOn));
      emit(JournalsLoaded(_journals));
    } catch (e) {
      emit(JournalError('Fail : $e'));
    }
  }

  void _onSelectJournal(SelectJournal event, Emitter<JournalState> emit) {
    // find index of selected journal and remplace it with the new one
    final selectedJournal = _journals.firstWhere(
      (journal) => journal.id == event.id,
      orElse: () => JournalEntity(
          id: '',
          title: '',
          body: '',
          categories: [],
          createdOn: DateTime.now(),
          postedBy: ''),
    );
    emit(JournalSelectedForChanging(selectedJournal));
  }

  void _onSaveChanges(SaveChanges event, Emitter<JournalState> emit) async {
    emit(JournalSaving());
    try {
      final List reply = await repository.updateJournal(event.journal);
      if (reply.isEmpty) {
        emit(JournalNotification('Failed to save changes'));
        return;
      } else {
        emit(JournalNotification('Changes saved'));
      }

      final List<JournalEntity> _journals = await repository.getAllJournals()..sort((a, b) => b.createdOn.compareTo(a.createdOn));
      print('Journals updated: $_journals');
      emit(JournalsLoaded(_journals));

    } catch (e) {
      emit(JournalError('Fail : $e'));
      await Future.delayed(Duration(milliseconds: 500));
      emit(JournalsLoaded(_journals));
    }
  }

}
