// journal_event.dart
import 'package:equatable/equatable.dart';

import '../../domain/entities/journal_entity.dart';


abstract class JournalEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class InitJournals extends JournalEvent {}



class LoadJournals extends JournalEvent {}

class DeleteJournal extends JournalEvent {
  final String id;
  DeleteJournal(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectJournal extends JournalEvent {
  final JournalEntity id;
  SelectJournal(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends JournalEvent {
  final JournalEntity journal;
  SaveChanges(this.journal);

  @override
  List<Object?> get props => [journal];
}

