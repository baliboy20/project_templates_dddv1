import 'package:flutter/material.dart';

import 'generic_searchba.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
  List<String> _items = testData;



  void Function(String) get _callback => (arg) {
    print('arg is $arg');
    final result = testData.where((word) => word.contains(arg)).toList();
    _items = result;
    print(result);
    setState(() {});
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          SizedBox(
            width: 200,
            child: GenericSearchbar(
              callback: _callback,
              debounceTime: 500,
            ),
          ),
        ],
        title: IconButton(onPressed: () => null, icon: Icon(Icons.search)),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(150),
          child: Container(
            height: 150,
            color: Colors.blue,
            child: Center(
              child: Text('Hello, world!'),
            ),
          ),
        ),
      ),
      body: ListView.builder(

        key: _listKey,
        itemCount: _items.length,
        itemBuilder: (BuildContext context, int index) {
          return _buildItem(_items[index]);
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=> null,//_addItem,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _buildItem(String item) {
    return SizeTransition(

      sizeFactor: CurvedAnimation(
        parent: AnimationController(
          duration: const Duration(milliseconds: 500),
          vsync: this,
        )..forward(),
        curve: Curves.easeOut,
        reverseCurve: Curves.easeIn,
      ),
      child: Card(
        color: Colors.amber,
        child: ListTile(
          title: Center(child: Text('$item')),
          trailing: IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => null,
          ),
        ),
      ),
    );
  }
}

List<String> testData = [
  'apple',
  'banana',
  'cherry',
  'date',
  'elderberry',
  'fig',
  'grape',
  'honeydew',
  'kiwi',
  'lemon',
  'mango',
  'nectarine',
  'orange',
  'pear',
  'quince',
  'raspberry',
  'strawberry',
  'tangerine',
  'ugli',
  'vanilla',
  'watermelon',
  'ximenia',
  'yuzu',
  'zucchini',
];
