import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/core/app_core.dart';
import 'package:journal_macos/src/features/journals/domain/entities/journal_entity.dart';
import 'package:journal_macos/src/features/journals/infrastructure/datasources/remote/journal_api.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_bloc.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_states.dart';

import '../../../snippets/presentation/screens/SnippetScreen.dart';
import '../../infrastructure/datasources/remote/journal_repository_impl.dart';
import '../blocs/journal_events.dart';

void main() {
  final loadJournals = LoadJournals();
  runApp(BlocProvider(
    create: (context) => JournalBloc(repository: JournalRepositoryImpl(JournalApi(
        baseUrl: AppSettings.serverUrl
    )))..add(loadJournals),
    child: const JournalApp(),
  ));
}

class JournalApp extends StatelessWidget {
  const JournalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const JournalScreen(),
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        appBarTheme: AppBarTheme(
          color: Colors.lightBlueAccent,
          centerTitle: true,
          titleTextStyle: TextStyle(color: Colors.grey[900], fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

class JournalScreen extends StatefulWidget {
  static const routeName = '/journals';
  static const routeLabel = 'Journals';

  const JournalScreen({super.key});

  static MaterialPageRoute genRoute() {
    return MaterialPageRoute(
      settings: const RouteSettings(name: routeName),
      builder: (_) => const JournalScreen(),
    );
  }

  @override
  State<JournalScreen> createState() => _JournalScreenState();
}

class _JournalScreenState extends State<JournalScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Journals'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: BlocConsumer<JournalBloc, JournalState>(
        listener: (context, state) {
          if (state is JournalError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message), backgroundColor: Colors.red),
            );
          } else if (state is JournalNotification) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(state.message), backgroundColor: Colors.green),
            );
          }
        },
        listenWhen: (previous, current) => current is JournalError || current is JournalNotification,
        builder: (context, state) {
          if (state is Loading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is JournalsLoaded) {
            return JournalsLoadedView(journals: state.journals);
          } else if (state is JournalSaving) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is JournalSelectedForChanging) {
            return JournalEditForm(journal: state.journal);
          } else if (state is JournalError) {
            return Center(child: Text('Error: ${state.message}'));
          } else {
            return const Center(child: Text('Welcome to the Journals App!'));
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showBottomSheetNew(context, JournalEntity.empty()),
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showBottomSheetNew(BuildContext context, JournalEntity journal) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: JournalEditForm(journal: journal),
        );
      },
    );
  }
}

class JournalsLoadedView extends StatelessWidget {
  final List<JournalEntity> journals;

  const JournalsLoadedView({super.key, required this.journals});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: journals.length,
      itemBuilder: (context, index) {
        final journal = journals[index];
        return Dismissible(
          key: Key(journal.id!),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            color: Colors.red.withOpacity(0.8),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: const Icon(Icons.delete, color: Colors.white),
          ),
          confirmDismiss: (direction) async => await _showDeleteConfirmationDialog(context, journal.id!),
          onDismissed: (direction) {
            BlocProvider.of<JournalBloc>(context).add(DeleteJournal(journal.id!));
          },
          child: Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),

            child: ListTile(
              contentPadding: const EdgeInsets.all(16.0),

              title: Text(
                journal.title,
                style: const TextStyle(
                    height: 2,
                    decoration: TextDecoration.underline,
                    fontSize: 18, fontWeight: FontWeight.w400),
              ),
              subtitle: Column(
                children: [
                  Text.rich(
                    TextSpan(
                      text: "\n${journal.body}",
                      style: const TextStyle(fontSize: 13),
                    ),
                    maxLines: 8,
                    overflow: TextOverflow.ellipsis,

                  ),
                   SizedBox(height: 20),
                   Container(
                     width: double.infinity,
                     //color: Colors.red[100],
                     child: Wrap(

                       alignment: WrapAlignment.start,
                      spacing: 8.0,
                      children: journal.categories.map((category) {
                        final isSelected = journal.categories.contains(category);
                        return Chip(

                          labelPadding: EdgeInsets.all(2),
                          label: Text(category),
                          backgroundColor:  Colors.purple[100]  ,
                        );
                      }).toList(),
                     ),
                   ),


                  Text.rich(
                    TextSpan(
                        text: "\n${journal.postedBy}",
                        style: const TextStyle(fontSize: 13),
                    ),
                    maxLines: 8,
                    overflow: TextOverflow.ellipsis,

                  ),
                  Text.rich(
                    textAlign: TextAlign.end,
                    TextSpan(

                      text: '\n\nCreated on: ${journal.formattedDate()}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                ],
              ),


              onTap: () => _showBottomSheet(context, journal),
            ),
          ),
        );
      },
    );
  }

  Future<bool> _showDeleteConfirmationDialog(BuildContext context, String journalId) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Delete'),
          content: Text('Are you sure you want to delete this journal?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              focusNode: FocusNode(skipTraversal: false)..requestFocus(),
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    ) ??
        false;
  }

  void _showBottomSheet(BuildContext context, JournalEntity journal) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: JournalEditForm(journal: journal),
        );
      },
    );
  }
}

class JournalEditForm extends StatefulWidget {
  final JournalEntity journal;

  const JournalEditForm({super.key, required this.journal});

  @override
  State<JournalEditForm> createState() => _JournalEditFormState();
}

class _JournalEditFormState extends State<JournalEditForm> {
  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;
  late Set<String> _selectedCategories;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.journal.title);
    _bodyController = TextEditingController(text: widget.journal.body);
    _selectedCategories = Set<String>.from(widget.journal.categories ?? []);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(26.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(labelText: 'Journal Title'),
          ),
          const SizedBox(height: 16.0),
          TextField(
            maxLines: 30,
            controller: _bodyController,
            decoration: const InputDecoration(labelText: 'Journal Body'),
          ),
          const SizedBox(height: 16.0),
          Wrap(
            spacing: 8.0,
            children: _selectedCategories.map((category) {
              final isSelected = _selectedCategories.contains(category);
              return ChoiceChip(
                label: Text(category),
                selected: isSelected,
                onSelected: (selected) {
                  setState(() {
                    if (selected) {
                      _selectedCategories.add(category);
                    } else {
                      _selectedCategories.remove(category);
                    }
                  });
                },
              );
            }).toList(),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  BlocProvider.of<JournalBloc>(context).add(SaveChanges(
                    JournalEntity(
                      id: widget.journal.id,
                      title: _titleController.text,
                      body: _bodyController.text,
                      categories: _selectedCategories.toList(),
                      createdOn: widget.journal.createdOn,
                      postedBy: widget.journal.postedBy,
                    ),
                  ));
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.save),
                label: const Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: () async {
                  final confirmed = await _showDeleteConfirmationDialog(context);
                  if (confirmed) {
                    BlocProvider.of<JournalBloc>(context).add(DeleteJournal(widget.journal.id!));
                  }
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.delete),
                label: const Text('Delete'),
              ),
              OutlinedButton.icon(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.cancel),
                label: const Text('Cancel'),
              ),
            ],
          )
        ],
      ),
    );
  }

  Future<bool> _showDeleteConfirmationDialog(BuildContext context) async {
    return await showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content: const Text('Are you sure you wish to delete this journal? This action cannot be undone.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
            ),
          ],
        );
      },
    ) ??
        false;
  }
}
