import 'package:bson/bson.dart';
import 'package:equatable/equatable.dart';
import 'package:journal_macos/src/core/validation/json_validator.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';

abstract interface class Encodable<T> {
  Map<String, dynamic> toJson();

  T fromJson(Map<String, dynamic> json);
}

class JournalVo extends Equatable implements  ValueObjectMappable {
  final String title;
  final List<String> categories;
  final String body;
  final String? id;
  final DateTime createdOn;
  final String postedBy;

  JournalVo({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  });

  DateTime getDateFromObjectId(String objectId) {
    try {
      // Convert the first 8 characters (representing the timestamp) to a 4-byte integer
      final timestampHex = objectId.substring(0, 8);
      final timestamp = int.parse(timestampHex, radix: 16);
      // Convert Unix timestamp to a DateTime object
      return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000, isUtc: true);
    } catch (e) {
      throw FormatException('Invalid ObjectId format: $e');
    }
  }

  factory JournalVo.fromJson(Map<String, dynamic> json) {

    String idstr;
    if(json['_id'] is ObjectId) {
      idstr = json['_id'].toHexString();
    } else {
      idstr = json['_id'] ?? '';
    }

    final vo = JournalVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      id: idstr,
      createdOn: JsonValidation(fragment: json, key: "_id", altValue: "")
          .isDateTimeFromObjectIdPartAsString()
          .asDateTime,
      postedBy: json['postedBy'] ?? 'Guest poster',
    );

    return vo;
  }

  @override
  List<Object> get props => [title, categories, body, id!, createdOn, postedBy];

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'categories': categories,
      'body': body,
      'id': id ?? '',
      'createdOn': createdOn.toIso8601String(),
      'postedBy': postedBy,
    };
  }

  static JournalVo newInstance() {
    return JournalVo(
      title: '',
      categories: [],
      body: '',
      id: null,
      createdOn: DateTime.now(),
      postedBy: '',
    );
  }

  String concatenateFields() {
    return '${title}${categories.join()}${body}${postedBy}';
  }

  @override
  JournalVo fromJson(Map<String, dynamic> json) {
    return JournalVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      id: json['id'] ?? null,
      createdOn: json['createdOn'],
      postedBy: json['postedBy'],
    );
  }
}
