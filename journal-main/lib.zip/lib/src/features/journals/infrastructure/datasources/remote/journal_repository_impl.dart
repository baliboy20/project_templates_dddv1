// journal_repository_impl.dart
import '../../../domain/entities/journal_entity.dart';
import '../../models/journal_vo.dart';
import '../../repositories/journal_interface.dart';
import 'journal_api.dart';

class JournalRepositoryImpl implements JournalRepository {
  final JournalApi api;

  JournalRepositoryImpl(this.api);

  @override
  Future<List<JournalEntity>> getAllJournals() async {
    final journals = await api.getAllItems();
    return journals.map((e) => JournalEntity.fromVo(e)).toList();
  }

  @override
  Future<List<JournalVo>> findJournalsByTitle(String title) async {
    final journals = await api.filterItems({});
    return journals;
  }

  @override
  Future<List<JournalEntity>> createJournal(JournalEntity journal)async {

    final  res = await api.createItem(journal.toVo());
    if(res != null){
      return  getAllJournals();
    }
    throw Exception('Failed to create journal');
  }

  @override
  Future<List<JournalEntity>> updateJournal(JournalEntity journal) async {
    final res = await api.updateItem(journal.toVo());
    if(res != null){
      return  getAllJournals();
    }
    throw Exception('Failed to create journal');
  }


  @override
  Future<List<JournalEntity>> deleteJournalById(String id) async {
   final res = await api.deleteItemById(id);

    if(res != null){
      return await  getAllJournals();
    }
    throw Exception('Failed to create delete journal');
  }

  @override
  Future<List<JournalVo>> filterJournals(Map<String, dynamic> criteria) async {
    throw UnimplementedError('Filtering not implemented or tested');
    // final journals = await api.filterJournals(criteria);
    // return journals.map((json) => JournalVo.fromJson(json)).toList();
  }

}
