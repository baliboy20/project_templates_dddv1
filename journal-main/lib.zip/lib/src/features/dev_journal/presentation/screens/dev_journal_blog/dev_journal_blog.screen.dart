//============================================================
// template created on: 2023-06-14 16:48:22.680788
// version: 1.1
//============================================================

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import './dev_journal_blog_edit.screen.dart';
import '../../../data/models/dev_journal.model.dart';
import '../../blocs/dev_journal/dev_journal_bloc.dart';
import '../../widgets/edit_actions_tile.dart';
import '../../widgets/searchbar_bloc/searchbar_bloc.dart';

class DevJournalBlogScreen extends StatefulWidget {
  static const routeLabel = 'Dev Journal Blogs';
  static const routeName = '/dev_journal_blog';

  static MaterialPageRoute genRoute() {
    return MaterialPageRoute(
        settings: RouteSettings(name: routeName),
        builder: (_) => DevJournalBlogScreen());
  }

  const DevJournalBlogScreen({Key? key}) : super(key: key);

  @override
  State<DevJournalBlogScreen> createState() => _DevJournalBlogScreenState();
}

class _DevJournalBlogScreenState extends State<DevJournalBlogScreen>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  TextEditingController searchBarController = new TextEditingController();

  @override
  void initState() {
    BlocProvider.of<DevJournalBloc>(context)
        .add(DbLoadDevJournal(criteria: {}));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: BlocConsumer<DevJournalBloc, DevJournalStates>(
            listener: (context, state) {
      if (state is DevJournalError) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("${state.errorMessage}"),
        ));
      }
      if (state is SnackBarMessage)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            duration: Duration(seconds: 10),
            content: Text("${state.message}")));
    }, builder: (context, state) {
      // print('state is comming home ${state}');
      if (state is LoadedDevJournals) {
        return CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              expandedHeight: 200,
              title: Text('Promts for ai'),
              snap: true,
              pinned: false,
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    Positioned(
                      bottom: 0,
                      left: 10,
                      right: 10,
                      child: SearchbarDevJournal(
                        searchController: searchBarController,
                      ),
                    )
                  ],
                ),
              ),
            ),
            SliverList(
                delegate: SliverChildBuilderDelegate(childCount: state.len,
                    (context, index) {
              DevJournal itm = state.devJournals[index];
              return EditActionsTile(
                line1: "${itm.title}",
                line2: "${itm.body}",
                line3: "${itm.postedBy}, ${itm.createdOn.day}-${itm.createdOn.month}-${itm.createdOn.year}",
                searchTerms: searchBarController.text,
                addItemfn: () => _navToEdit(DevJournal.empty(), context),
                amendItemfn: () => _navToEdit(itm, context),
                removeItemfn: () => _removeItem(itm, context),
              );
            })),
          ],
        );
      }

      return Text(state.toString());
    }));
  }

  void _removeItem(DevJournal devJournal, context) {
    Bloc bloc = BlocProvider.of<DevJournalBloc>(context);
    bloc.add(DbDeleteDevJournal(devJournal: devJournal));
  }



  /**
   * is ths ok
   */
  void _navToEdit(DevJournal devJournal, BuildContext context) async {
    // devJournal
    Bloc bloc = BlocProvider.of<DevJournalBloc>(context);
    bloc.add(DoEditDevJournal(item:devJournal));
    //await Future.delayed(Duration(milliseconds: 100));
    Navigator.push(
        context,
        MaterialPageRoute(
            settings: RouteSettings(name: DevJournalBlogEditScreen.routeName),
            builder: (_) => DevJournalBlogEditScreen(
                  item: devJournal,
                )));
  }


  @override
  // TODO: implement wantKeepAlive
  bool get wantKeepAlive => false;
}
