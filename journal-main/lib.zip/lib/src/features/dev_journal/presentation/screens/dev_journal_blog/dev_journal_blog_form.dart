//============================================================
// template created on: 2023-06-14 16:48:22.703608
// version: 1.1
//============================================================

part of './dev_journal_blog_edit.screen.dart';

class DevJournalBlogForm extends StatefulWidget {
  final DevJournal devJournal;

  DevJournalBlogForm({required this.devJournal});

  @override
  _DevJournalBlogFormState createState() => _DevJournalBlogFormState();
}

class _DevJournalBlogFormState extends State<DevJournalBlogForm> {
  final _formKey = GlobalKey<FormState>();
  List<String> _categories = [];

//todo: customise to reflect the names of the fields of the vo.
  final TextEditingController _urname1Controller = TextEditingController();
  final TextEditingController _urname2Controller = TextEditingController();
  final TextEditingController _urname3Controller = TextEditingController();

  @override
  initState() {
    final state = BlocProvider.of<DevJournalBloc>(context).state;
    if (state is EditingDevJournal) setControllerValues(state.devJournal);
    super.initState();
  }

  void setControllerValues(DevJournal devJournal) {
    _urname1Controller.text = devJournal.title;
    _urname2Controller.text = devJournal.body;
    _urname3Controller.text = devJournal.postedBy;
    _categories = devJournal.categories;
  }

  List<String> _selectedCategories = [];
  String _selectedCategory = '';

  String? _validateField(String? value) {
    if (value == null || value.isEmpty) {
      return 'This field is required';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<DevJournalBloc, DevJournalStates>(
        listener: (context, state) {
      if (state is EditingDevJournal) setControllerValues(state.devJournal);
    },
// listenWhen: (previous, current) => current is EditingdevJournal,
        builder: (context, state) {
      if (state is EditingDevJournal) {

        return Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: ListView(
              children: [
                _AutoChip(state.categories),
                _TextFieldMultline(
                    'Title', _urname1Controller, _validateField,
                    multiline: false),
                _TextFieldMultline('Body', _urname3Controller, _validateField),
                _TextFieldMultline(
                    'Posted by', _urname2Controller, _validateField, multiline: false),
                SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
// =============
// Saving Button
//
                    ElevatedButton(
                      child: Text('Save'),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          print('Form is valid, save the data');
//todo: edit fieldnames accordingly.
                          DevJournal changed = state.devJournal.copyWith(
                              title: _urname1Controller.text,
                              body: _urname2Controller.text,
                              postedBy: _urname3Controller.text,
                              categories: _categories);
                          BlocProvider.of<DevJournalBloc>(context).add(
//todo: changed named parmater to item.
                              DbUpsertDevJournal(item: changed));
                          Navigator.pop(context);
                        } else {
                          print('Form is not valid, please correct the errors');
                        }
                      },
                    ),
                    ElevatedButton(
                      child: Text('Cancel'),
                      onPressed: () {
// Cancel the editing
                        BlocProvider.of<DevJournalBloc>(context)
                            .add(DbLoadDevJournal(criteria: null));
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Editing cancelled'),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      } else {
        return  Container(
        height: 100,
        width: 100,
            alignment: Alignment.center,
            child: const CircularProgressIndicator(backgroundColor: Colors.red),
        );}
    });
  }

  _TextFieldMultline(String label, TextEditingController controller,
      String? Function(String?) validator,
      {bool multiline = true}) {
    return TextFormField(
      maxLines: multiline ? 35 :  1,
      maxLength: 2000,
      decoration:
          InputDecoration(border: OutlineInputBorder(), labelText: label),
      keyboardType: TextInputType.text,
// keyboardType: multiline ? TextInputType.multiline : TextInputType.text,
      controller: controller,
      validator: validator,
      onChanged: (value) => null,
    );
  }

  _DropdownButtonFormField(String label) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(labelText: label),
      items: _categories
          .map((category) => DropdownMenuItem<String>(
                value: category,
                child: Text(category),
              ))
          .toList(),
      onChanged: (value) {
        setState(() {
          _selectedCategory = value!;
        });
      },
      validator: _validateField,
      value: _selectedCategory.isNotEmpty ? _selectedCategory : null,
    );
  }

  _AutoChip(dynamic categories) {
    return AutoChip<String>(
// initial: categories,
        initial: ['category'],
        updateModel: (List<AutoChipOption<dynamic>> d) =>
            _selectedCategories = d.map((c) => c.option.toString()).toList(),
        optionFactory: (v) => v,
        options: categories,
        extractLabelFn: (a) => a);
  }
}
