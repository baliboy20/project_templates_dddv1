import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_formz/auto_chip/auto_chip.exports.dart';

// import 'package:zz_widget/bloc/devJournal/devJournal_actions.dart';

import '../../../data/models/dev_journal.model.dart';
import '../../blocs/dev_journal/dev_journal_bloc.dart';

part 'dev_journal_blog_form.dart';

class DevJournalBlogEditScreen extends StatefulWidget {
  // this should be paramCase.
  static const routeLabel = 'DevJournal Edit';
  static const routeName = '/dev_journal-edit';
  final DevJournal item;

  static MaterialPageRoute genArgRoute(DevJournal devJournal) {
    return MaterialPageRoute(
        settings: RouteSettings(name: routeName),
        builder: (_) => DevJournalBlogEditScreen(
              item: devJournal,
            ));
  }

  const DevJournalBlogEditScreen({Key? key, required this.item})
      : super(key: key);

  @override
  State<DevJournalBlogEditScreen> createState() =>
      _DevJournalBlogEditScreenState();
}

class _DevJournalBlogEditScreenState extends State<DevJournalBlogEditScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('DevJournal Editor'),
        ),
        body: Padding(
            padding: const EdgeInsets.symmetric(vertical: 28.0, horizontal: 16),
            child: Column(
              children: [
                Expanded(
                    child: DevJournalBlogForm(
                  devJournal: widget.item,
                ))
              ],
            )));
  }
}
