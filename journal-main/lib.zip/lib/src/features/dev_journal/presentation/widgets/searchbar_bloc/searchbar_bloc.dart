//============================================================
// template created on: 2023-06-14 16:48:22.701639
// version: 1.1
//============================================================



import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';


import '../../blocs/dev_journal/dev_journal_bloc.dart';

class SearchbarDevJournal extends StatefulWidget  {
  final TextEditingController searchController;
   SearchbarDevJournal({Key? key, required this.searchController}) : super(key: key);

  @override
  State<SearchbarDevJournal> createState() => _SearchbarDevJournalState();
}

class _SearchbarDevJournalState extends State<SearchbarDevJournal>  with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {

  String lastval ='';
  @override
  bool get wantKeepAlive => true;
  @override
  initState() {

    super.initState();
    widget.searchController.addListener(() {
      if (widget.searchController.text.length <= 1 ) return;
      if(widget.searchController.text == lastval) return;
      lastval = widget. searchController.text;
      Debouncer.instanceOf(millis: 500)..run( (){
        BlocProvider.of<DevJournalBloc>(context)
            .add(DbFilterDevJournals(criteria: {"find": widget.searchController.text}));
      });
    });
  }
  @override
  Widget build(BuildContext context) {
    return TextField(
          controller: widget.searchController,
          decoration: InputDecoration(

            suffix: IconButton(
              icon: Icon(Icons.close),
              onPressed: () {
               widget.searchController.text ='';
              },
            ),
            filled: true,
            fillColor: Colors.white30,
            hintText: 'Enter search terms separated by comma ',
            border: OutlineInputBorder(
              gapPadding: 60,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        );
  }
}

//todo: add this.
class Debouncer {
  final int milliseconds;
  static Timer? _timer;
  static Debouncer? _debouncer;

  static Debouncer instanceOf({int millis = 200}) {
    return _debouncer ?? Debouncer(milliseconds: millis);
  }

  Debouncer({required this.milliseconds});

  run(VoidCallback action) {
    if (_timer == null)
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    else {
      _timer?.cancel();
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    }
  }
}
