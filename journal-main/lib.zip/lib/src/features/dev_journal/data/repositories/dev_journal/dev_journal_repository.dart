// amended 2nd july.
import 'dart:async';

import 'package:mongo_dart/mongo_dart.dart';

 import '../../../domain/repositories/dev_journal_repository_base.dart';  //////
import '../../models/dev_journal.model.dart';



class DevJournalRepositoryLocal implements DevJournalRepositoryBase { /////////
  final String dbString;
  final String collectionName;
  Db? _db;
  bool isChanged = true;
  List<DevJournal> _prompts = [];

  DevJournalRepositoryLocal({required this.dbString, required this.collectionName}) {
    _connect();
  }

  Future<void> _connect() async {
    try {
      if (_db?.state != State.OPEN || _db?.state != State.open) {
        _db = await Db(dbString);
        await _db?.open();
      }
      if (_db?.state != State.OPEN || _db?.state != State.open) {
        if (_db?.state == State.OPENING || _db?.state == State.opening) {
          int i = 0;
          while (i < 10) {
            await Future.delayed(Duration(milliseconds: 100));
            if (_db?.state == State.OPEN || _db?.state == State.open) {
              break;
            }
            i++;
            // print('... waiting for db to open');
          }
          throw Exception('Error opening database');
        }
      }
    } catch (e) {
      print('Error opening database: $e');
      throw Exception('Function _connect(), Error opening database: $e');
    }
  }

  @override
  Future<List<DevJournal>> getItems() async {
    // print('getting prompts');
    List<DevJournal> results;
    if (isChanged == false) {
      print('returning cached prompts');
      return Future.value(_prompts);
    }

    List<DevJournal> retval = [];

    try {
      await _connect();
      DbCollection collection = _db!.collection(collectionName);
      final data = await collection.find().toList();
      retval = data.map((e) => DevJournal.fromJson(e)).toList() as List<DevJournal>;
    } catch (e) {
      throw Exception('Error getting prompt data: $e');
    } finally {
      _db?.close();
    }
    _prompts = retval ?? [];
    isChanged = false;
    return retval;
  }








  @override
  Future<DevJournal> addItem(DevJournal item) async {
    await _connect();
    DevJournal result;
    try {
      DbCollection collection = _db!.collection(collectionName);
      // await collection.update(where.eq('_id', prompt.id), prompt.toJson());
      var modifyOperation;
      //  var modifyOperation = modify.set('prompts', prompt.prompts)
      //  .set('categories', prompt.categories)
      //  .set('notes', prompt.notes)
      //  .set('versions', prompt.versions);
      assert (modifyOperation != null);
      await collection.updateOne(
        where.eq('_id', item.id),
        modifyOperation,
        upsert: true,
      );
      isChanged = true;
      result = item;
      print('result is ok....');
    } catch (e) {
      throw Exception('Error getting blog posts: $e');
    } finally {
      _db?.close();
    }
    return result;
  }

  @override
  Future deleteItem(DevJournal item)async{
    await _connect();
    Map<String, dynamic> result;
    try {
      DbCollection collection = _db!.collection(collectionName);
      result = await collection.remove(where.id(item.id));
      isChanged = true;
    } catch (e) {
      throw Exception('Error getting blog posts: $e');
    } finally {
      _db?.close();
    }
    return result;
  }

  @override
  Future<List<DevJournal>?> filterItems(Map<String, dynamic> map) async {
    await _connect();
    List<DevJournal> results = [];
    try {
      DbCollection collection = _db!.collection(collectionName);
      final data = await collection.find(map).toList();
      results = data.map((e) => DevJournal.fromJson(e)).toList();
    } catch (e) {
      throw Exception('Error getting blog posts: $e');
    } finally {
      _db?.close();
    }
    return results;
  }

  @override
  Future<List<DevJournal>> findItemsWhere(Map<String, dynamic> criteria) async {
    await _connect();
    List<DevJournal> results = [];
    try {
      DbCollection collection = _db!.collection(collectionName);
      final data = await collection.find(criteria).toList();
      results = data.map((e) => DevJournal.fromJson(e)).toList() as List<DevJournal>;
    } catch (e) {
      throw Exception('Error getting blog posts: $e');
    } finally {
      _db?.close();
    }
    return results;
  }

  // done
  @override
  Future<DevJournal> updateItem(DevJournal item) async {
    await _connect();
    DevJournal result;
    try {
      DbCollection collection = _db!.collection(collectionName);
      // await collection.update(where.eq('_id', prompt.id), prompt.toJson());
      var modifyOperation;
      //  var modifyOperation = modify.set('prompts', prompt.prompts)
      //  .set('categories', prompt.categories)
      //  .set('notes', prompt.notes)
      //  .set('versions', prompt.versions);
      assert (modifyOperation != null);
      await collection.updateOne(
        where.eq('_id', item.id),
        modifyOperation,
        upsert: true,
      );
      isChanged = true;
      result = item;
      print('result is ok....');
    } catch (e) {
      throw Exception('Error getting blog posts: $e');
    } finally {
      _db?.close();
    }
    return result;
  }

  @override
  Future<List<String>> getList() {
    try {
    return  Future.value(['Personal', 'Work', 'Family', 'Friends', 'Hobbies', 'Other']);
    } catch (e){
      throw Exception('e');
    }

  }


}

Future<Set<String>> fetchUniqueCategories() async {
  // Replace with your connection string
  const connectionString =
      'mongodb://<username>:<password>@host:port/database_name';

  final db = Db(connectionString);
  await db.open();

  // Access the 'DevJournals' collection
  final promptsCollection = db.collection('DevJournals');

  // Use aggregation to get the unique categories
  final pipeline = [
    {
      '\$unwind': '\$categories',
    },
    {
      '\$group': {
        '_id': null,
        'uniqueCategories': {
          '\$addToSet': '\$categories',
        },
      },
    },
  ];

  final Map<String, dynamic> result =
      await promptsCollection.aggregate(pipeline);

  await db.close();

  if (result.isNotEmpty) {
    return Set<String>.from(result['uniqueCategories']);
  } else {
    return Set<String>();
  }
}

