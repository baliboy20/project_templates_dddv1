import 'dart:async';
//updated 4 jul.
import 'package:mongo_dart/mongo_dart.dart';

import '../../models/dev_journal.model.dart';
import './test_data.dart';
import '../../../domain/repositories/dev_journal_repository_base.dart';

class DevJournalRepositoryMock implements DevJournalRepositoryBase {
  static List<DevJournal> _testData = getTestDataSet();

  static List<DevJournal> get testData => _testData;

  @override
  Future<List<DevJournal>> get devJournals async {
    return Future.value(_testData);
  }

  @override
  Future<List<String>> getList() async {
    return  Future.value(['Personal', 'Work', 'Family', 'Friends', 'Hobbies', 'Other']);
  }

  @override
  Future<List<DevJournal>> findItemsWhere(Map<String, dynamic> criteria) async {
    List<DevJournal> results = _testData.where((devJournal) {
      for (var key in criteria.keys) {
        Map<String, dynamic> json = devJournal.toJson();
        final ckey = criteria[key];
        if (devJournal.toJson()["_id"] != criteria[key]) {
          return false;
        }
      }
      return true;
    }).toList();
    return Future.value(results);
  }

  @override
  Future<DevJournal> addItem(DevJournal devJournal) async {
    int index = _testData.indexWhere((p) => p.id == devJournal.id);
    if (index != -1) {
      // Update existing devJournal
      // _testData[index] = devJournal;
      _testData.replaceRange(index, index + 1, [devJournal]);
    } else {
      // Insert new devJournal
      _testData.add(devJournal);
    }
    return Future.value(devJournal);
  }

  @override
  Future<DevJournal> updateItem(DevJournal devJournal) async {
    int index = _testData.indexWhere((p) => p.id == devJournal.id);
    if (index != -1) {
      // Update existing devJournal
      // _testData[index] = devJournal;
      _testData.replaceRange(index, index + 1, [devJournal]);
    } else {
      // Insert new devJournal
      _testData.add(devJournal);
    }
    return Future.value(devJournal);
  }

  @override
  Future<DevJournal> deleteItem(DevJournal item) async {
    DevJournal? deletedDevJournal;
    _testData = _testData.where((devJournal) {
      if (devJournal.id == item.id) {
        deletedDevJournal = devJournal;
        return false;
      }
      return true;
    }).toList();
    if (deletedDevJournal != null) {
      return Future.value(deletedDevJournal);
    } else {
      throw Exception('DevJournal not found');
    }
  }

  @override
  Future<List<DevJournal>> getItems() {
    return Future.value(_testData);
  }



@override
Future<List<DevJournal>> filterItems(Map<String, dynamic> map) {
List<DevJournal> filtered = [];
List<String> srcTerms = map.values.map((a) => a.toString()).toList();
filtered.addAll(_testData.where((lightBulb) {
final json = lightBulb.toJson().toString();
return srcTerms.any((src) => json.contains(src));
}).toList());
return Future.value(filtered.length == 0 ? _testData : filtered);
}

  @override
  // TODO: implement isChanged
  get isChanged => throw UnimplementedError();







}
