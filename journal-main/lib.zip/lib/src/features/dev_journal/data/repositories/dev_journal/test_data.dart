import 'package:mongo_dart/mongo_dart.dart';

import '../../models/dev_journal.model.dart';


/**
 * in dart, Create a list of  test data items of the type DevJournal. Each Trombone instance is created in this way:-
    DevJournal()
 */



List<DevJournal> getTestDataSet() {

return   [
  DevJournal(
    title: 'The Amazon Rainforest: An Overview',
    categories: ['Ecology', 'Environment'],
    body: 'The Amazon rainforest, covering much of northwestern Brazil and extending into Colombia, Peru and other South American countries, is the world’s largest tropical rainforest...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'Ecologist01',
  ),
  DevJournal(
    title: 'Amazon Rainforest Biodiversity',
    categories: ['Biodiversity', 'Wildlife'],
    body: 'Biodiversity is the variety of life in an area. The Amazon rainforest is one of the most biodiverse regions of the world, hosting a myriad of plant, animal, and insect species...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'BiologyExpert',
  ),
  DevJournal(
    title: 'Deforestation in the Amazon',
    categories: ['Climate Change', 'Deforestation'],
    body: 'The Amazon rainforest is suffering from deforestation. As the world’s largest rainforest, the Amazon plays a crucial role in keeping our planet’s carbon-dioxide levels in check...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'ClimateChangeActivist',
  ),
  DevJournal(
    title: 'Amazon River Dolphins: A Species in Danger',
    categories: ['Wildlife', 'Endangered Species'],
    body: 'The Amazon River Dolphin, also known as the pink river dolphin or boto, is becoming increasingly threatened due to habitat loss and other human activities...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'MarineBiologist',
  ),
  DevJournal(
    title: 'Indigenous Tribes of the Amazon',
    categories: ['Anthropology', 'Culture'],
    body: 'There are about 400 tribes living in the Amazon rainforest. These tribes are known for their rich culture, history, and their symbiotic relationship with their environment...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'Anthropologist',
  ),
  DevJournal(
    title: 'Medicinal Plants of the Amazon',
    categories: ['Medicine', 'Botany'],
    body: 'The Amazon rainforest is often referred to as the world\'s largest pharmacy. Many plants used in modern medicine are found here, and countless others are yet to be discovered...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'Botanist',
  ),
  DevJournal(
    title: 'The Amazon Rainforest and Climate Change',
    categories: ['Climate Change', 'Environment'],
    body: 'The Amazon rainforest plays a crucial role in regulating global climate. Yet, it is under threat from deforestation and climate change, which could have severe global consequences...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'ClimateScientist',
  ),
  DevJournal(
    title: 'Unique Creatures of the Amazon Rainforest',
    categories: ['Wildlife', 'Biodiversity'],
    body: 'The Amazon rainforest is home to a staggering array of wildlife, including many species found nowhere else on Earth...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'WildlifePhotographer',
  ),
  DevJournal(
    title: 'The Impact of Mining in the Amazon',
    categories: ['Environment', 'Economics'],
    body: 'Mining in the Amazon rainforest has increased significantly in recent decades, causing serious environmental damage and impacting local communities...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'EnvironmentalEconomist',
  ),
  DevJournal(
    title: 'The Amazon Rainforest: The Future',
    categories: ['Environment', 'Conservation'],
    body: 'With deforestation rates increasing, it is crucial to consider the future of the Amazon rainforest. This unique environment needs immediate attention and conservation efforts...',
    id: ObjectId(),
    createdOn: DateTime.now(),
    postedBy: 'Conservationist',
  ),
];

}




