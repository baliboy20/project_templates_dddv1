
class DataConfigs {
  static const String dbConnString = 'mongodb://localhost:27017/journal';
}
