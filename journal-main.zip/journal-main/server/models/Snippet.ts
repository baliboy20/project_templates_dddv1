import mongoose, { Document, Schema } from 'mongoose';


interface ISnippet extends Document {
    title: string;
    body: string;
    postedBy: string;
    id: Schema.Types.ObjectId;
    createdOn: Date;
    categories: string[];
}

const snippetSchema = new Schema<ISnippet>({
    title: String,
    body: String,
    postedBy: String,
    createdOn: Date,
    categories: [String]
});

export const SnippetModel = mongoose.model<any>('Snippet', snippetSchema, 'snippets');
// export function  Watch () {
//     var Document = new SnippetModel();
//    const changeStream = Document.watch;
//    console.log('change stream', Document.on('change', ()=>{
//        console.log('database changed');
//    })); //
//     Snippet.create({title: 'wil', body: 'somebod'})
//         .then(()=> console.log('created promise'));
//    // changeStream.on('change', ()=>{
//    //     console.log('database changed');
//    // });
// }
