import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';

import journalRoutes from './routes/journals/_journal.routes';
import  taskRoutes from './routes/tasks/_tasks_routes';
import SnippetRoute from './routes/snippets/_snippet.routes';
import projectRoute from "./routes/projects/projectRoute";
import phraseRoute from "./routes/phrases/_phrases.route";
import vocabRoute from "./routes/vocab/_vocabs_route";
import gardenBlogRoute from "./routes/garden_blog/_garden_blog.routes";

const requestLoggerMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const method = req.method;
    const url = req.originalUrl;

    console.log(`[${new Date().toISOString()}] ${method} ${url}`);
    next(); // Call next to continue processing the request
};

 const logger = ((req : express.Request, res: express.Response, next : NextFunction ) => {
    console.log(`My Route: ${req.method} ${req.originalUrl}`);
    next();
});

export const app = express();
app.use(express.json());
app.use("/uploads",express.static( path.join(__dirname,"uploads")));
// app.use("uploads",express.static("uploads"));
app.use(express.urlencoded({ extended: true }));
app.use(cors()); //
app.use('/projects', projectRoute );
app.use('/journals', journalRoutes);
app.use('/garden-blog', gardenBlogRoute);
app.use('/tasks', taskRoutes);
app.use('/snippets', SnippetRoute);
app.use('/phrases', phraseRoute);
app.use('/vocab', vocabRoute);

export default app;
//


