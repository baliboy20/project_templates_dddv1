import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:journal_macos/dev_utils/console_log.dart';
import 'package:journal_macos/src/features/projects/domain/entities/project_entity.dart';
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';

import 'package:rxdart/rxdart.dart';

main() {
  getRequest();
}

BehaviorSubject<int> subject = BehaviorSubject<int>();


  // final transformed$ = subject.switchMap((event) {
  //   return getValue(event).asStream();
  // });

  // transformer
  transformedFn(int value1){
    final value = value1.toString();
      return Stream.fromFuture(findAllProjectsApi("null")); //getValue(event).asStream();
      // return Stream.fromFuture(getValue(value)); //getValue(event).asStream();
  }


  //http
  Future<String> findAllProjectsApi(String name) async {
 final uri = Uri.parse('http://localhost:3010/projects/findAll');
 final response = await http.get(uri);
 return (response.body);
  }

  // decode
 List<ProjectVo> decode(String response) {
    return JsonProjectVoMapper.fromJsonEncoded(response);//  fromJsonStr(response);;
 }

 List<ProjectEntity> tuEntities(List<ProjectVo> vos) {
    return ProjectEntityMapper.fromVoList(vos);
 }

  // Random
  Future<int> getValue(int val) async {
    var a = Random().nextInt(10) * val;
    return Future.value(a);
  }

  // Msin fn
  void getRequest() async {
  final Stream<String> stm$ =  Stream.fromFuture(findAllProjectsApi("name"));
 final Stream<List<ProjectEntity>> stm2$ =  stm$.map<List<ProjectVo>>((a)=> JsonProjectVoMapper.fromJsonEncoded(a))
  .map<List<ProjectEntity>>((b)=> ProjectEntityMapper.fromVoList(b))
 // .map<List<ProjectEntity>>((c)=> throw Exception('error'));
  ;

  stm2$.listen((List<ProjectEntity> d){
       print(d);
       wpLog(d.length);
  },
      onDone: (){
    print('done');
      },
  onError: (e){
    print('error');
  });

}
