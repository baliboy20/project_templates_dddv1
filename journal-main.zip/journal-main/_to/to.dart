import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:journal_macos/src/features/snippets/infrastructure/datasources/remote/snippets.testdata.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/models/snippet_vo.dart';

class SnippetUploader {
  final String baseUrl = "http://localhost:3001";

  SnippetUploader();

  // Method to upload multiple SnippetVo objects
  Future<void> uploadSnippets(List<SnippetVo> snippets) async {


    final endpoint = Uri.parse('$baseUrl/snippets/add-one');
    List<http.Response> responses = [];

    for (SnippetVo snippet in snippets) {
    try  {
        final response = await http.post(
          endpoint,
          headers: {
            'Content-Type': 'application/json',
          },
          body: jsonEncode(snippet.toJson()),
        );

        if (response.statusCode != 200) {
          print('Failed to upload snippet: ${response.body}');
        } else {
          print('Successfully uploaded snippet: ${snippet.title}');
        }
      } catch (e){
      print(e);
    }
    }

  }
}
main(){
  final s = SnippetUploader();
  s.uploadSnippets(SnippetsTestData);
}
