import 'package:flutter/material.dart';

// 1. Custom Controller
class MultipleSelectController<T> extends ValueNotifier<List<T>> {
  MultipleSelectController([List<T>? value]) : super(value ?? []);

  void add(T item) {
    value = [...value, item]; // Add item to the list
  }

  void remove(T item) {
    value = value.where((element) => element != item).toList(); // Remove item
  }

  void toggle(T item) {
    if (value.contains(item)) {
      remove(item);
    } else {
      add(item);
    }
  }

  bool isSelected(T item) => value.contains(item);

  void clear() {
    value = [];
  }
}

// 2. Custom Multiple Select Widget
class MultipleSelect<T> extends StatefulWidget {
  final List<T> items;
  final MultipleSelectController<T> controller; // Controller
  final Widget Function(T item) itemBuilder; //To build the display
  final ValueChanged<List<T>>? onChanged;

  const MultipleSelect({
    Key? key,
    required this.items,
    required this.controller,
    required this.itemBuilder,
    this.onChanged,
  }) : super(key: key);

  @override
  _MultipleSelectState<T> createState() => _MultipleSelectState<T>();
}

class _MultipleSelectState<T> extends State<MultipleSelect<T>> {
  @override
  void initState() {
    super.initState();
    widget.controller.addListener(_updateSelection);
  }

  @override
  void dispose() {
    widget.controller.removeListener(_updateSelection);
    super.dispose();
  }

  void _updateSelection() {
    setState(() {
      // Rebuild the UI when the controller's value changes
    });
    widget.onChanged?.call(widget.controller.value);

  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: widget.items.map((item) {
        return CheckboxListTile(
          title: widget.itemBuilder(item),
          value: widget.controller.isSelected(item),
          onChanged: (bool? newValue) {
            widget.controller.toggle(item);
          },
        );
      }).toList(),
    );
  }
}

// 3. Example Usage in a Form
class MyForm extends StatefulWidget {
  @override
  _MyFormState createState() => _MyFormState();
}

class _MyFormState extends State<MyForm> {
  final _formKey = GlobalKey<FormState>();
  final MultipleSelectController<String> _selectController =
  MultipleSelectController<String>(); // Initialize the controller

  @override
  void dispose() {
    _selectController.dispose(); // Dispose of the controller
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Multiple Select Form')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              MultipleSelect<String>(
                items: const ['Apple', 'Banana', 'Orange', 'Grapes'],
                controller: _selectController,
                onChanged: (selectedItems) {
                  print("Selected items: $selectedItems"); // Example callback
                },
                itemBuilder: (item) => Text(item),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    // Form is valid, access selected values from the controller
                    List<String> selectedValues = _selectController.value;
                    print('Form submitted with selected values: $selectedValues');
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

void main() {
  runApp(MaterialApp(home: MyForm()));
}
