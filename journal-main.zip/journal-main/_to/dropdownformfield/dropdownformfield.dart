

import 'package:flutter/material.dart';

main() {
  runApp(
      MaterialApp(home: DevHome(),)
  );
}

class DevHome extends StatefulWidget {
  const DevHome({super.key});

  @override
  State<DevHome> createState() => _DevHomeState();
}

class _DevHomeState extends State<DevHome> {
  @override
  Widget build(BuildContext context) {
    return   Material(
      child: Column(
        children: [
          Expanded(child: Text("sdf")),
         Expanded( child:DropdownMenu<String>(
           alignmentOffset: Offset(0,40),
              enableFilter: true,
              dropdownMenuEntries: [
            DropdownMenuEntry( label: "sdf", value: "sdf"),
            DropdownMenuEntry( label: "sdf2", value: "sdf2"),
            DropdownMenuEntry( label: "en", value: "ir3"),

          ]))
        ],
      ),
    );
  }
}
