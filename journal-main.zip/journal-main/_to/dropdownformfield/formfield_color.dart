import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Simple Flutter App'),
        ),
        body: const Center(
          child: HomeScreen(),
        ),
      ),
    ),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(38.0),
          child: TextField(
            controller: _controller,
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.red,
              hintText: 'Enter your name',
              labelText: 'Name',
            ),
          ),
        )
      ],
    );
  }
}
