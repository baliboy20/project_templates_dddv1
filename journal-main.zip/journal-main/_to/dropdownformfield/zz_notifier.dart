import 'package:flutter/material.dart';
import 'package:journal_macos/dev_utils/console_log.dart';

import 'zz_mutiple_select.dart';

main(){
   runApp(MyApp());

}


class MyApp extends StatelessWidget {
  final MultipleSelectController _controller = MultipleSelectController<String>(["ss"]);
   MyApp({super.key}){
     _controller.addListener((){
       wpLog("I Listneing once first ${_controller.value}");

     });

     _controller.addListener((){
       wpLog(" II Listneing second ${_controller.value}");

     });

     wpLog(" construcotr ${_controller.value}");
   }

  @override
  Widget build(BuildContext context) {

wpLog('buld');
    return MaterialApp(
      home: Center(child:TextButton(child: Text('helllo'), onPressed: (){
        _controller.add("item added");
      },)) ,
    );
  }
}



