main(){
  List<String> categories = ['Category 1', 'Category 2', 'Category 3'];

  for(var cat in categories){
    try{

    }catch (e){

    }
  }



}