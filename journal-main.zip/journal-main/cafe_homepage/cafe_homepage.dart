import 'package:flutter/material.dart';

void main() {
  runApp(SconeCafeApp());
}

class SconeCafeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Scone Cafe',
      theme: ThemeData(
        primaryColor: Colors.brown,
        scaffoldBackgroundColor: Colors.brown[50],
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(

        children: [
          SplashScreen(),
          MenuScreen(),
          Container(color: Colors.red, child: Text('Page 1')),
        ],
      ),
    );
  }
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: double.infinity,
        alignment: Alignment.center,
        color: Colors.blue,
        child: Text('Splash Screen'),
      ),
    );
  }
}


class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: double.infinity,
        alignment: Alignment.center,
        color: Colors.green[50],
        child: Text('Splash Screen'),
      ),
    );
  }
}



