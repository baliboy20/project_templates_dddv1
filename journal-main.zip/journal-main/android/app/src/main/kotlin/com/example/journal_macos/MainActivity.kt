package com.example.journal_macos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
