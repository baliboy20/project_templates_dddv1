import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';
import 'package:journal_macos/src/features/gardening_blog/domain/entities/garden_blog_entity.dart';
import 'package:journal_macos/src/features/gardening_blog/domain/repositories/garden_blog.repository.dart';
import 'package:journal_macos/src/features/gardening_blog/infrastructure/mappers/json_gardenblogvo_mappers.dart';
import 'package:journal_macos/src/features/gardening_blog/infrastructure/models/garden_blog.dart';
import 'package:journal_macos/src/features/gardening_blog/presentation/blocs/garden_blog_bloc.dart';
import 'package:journal_macos/src/features/gardening_blog/presentation/blocs/garden_blog_events.dart';
import 'package:journal_macos/src/features/journals/domain/entities/journal_entity.dart';
import 'package:journal_macos/src/features/journals/infrastructure/mappers/json_journalvo_mappers.dart';
import 'package:journal_macos/src/features/journals/infrastructure/models/journal_vo.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_bloc.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_events.dart';
import 'package:journal_macos/src/features/projects/domain/entities/project_entity.dart';
import 'package:journal_macos/src/features/projects/domain/repositories/project_repository.dart';
import 'package:journal_macos/src/features/projects/infrastructure/models/project_vo.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_bloc.dart';
import 'package:journal_macos/src/features/projects/presentation/bloc/project_event.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/mappers/json_taskvo_mappers.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/models/task_vo.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/repo/task_repository_impl.dart';
import 'package:journal_macos/src/features/tasks/presentation/bloc/task_bloc.dart';
import 'package:journal_macos/src/features/tasks/presentation/bloc/task_events.dart';

import 'src/core/routes/routes.dart';
import 'src/features/home/presentation/screens/screens.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    // final ICrudHttpApi<SnippetVo> snippetApi = CrudHttpApiImpl<SnippetVo>(
    //   route: '/snippets',
    //   baseUrl: 'http://localhost:3010',
    //   fromEncodedJsonString: SnippetMapper.fromJsonString,
    //   toEncodedJsonString: SnippetMapper.toJsonString,
    // );


    // journals api
    final ICrudHttpApi<JournalVo> journalApi = CrudHttpApiImpl<JournalVo>(
      route: '/journals',
      baseUrl: 'http://localhost:3010',
      fromEncodedJsonString: JsonJournalVoMapper.decodeJsonList,
      toEncodedJsonString: JsonJournalVoMapper.encodeJournalVo,
    );
    // journals api
    final ICrudHttpApi<GardenBlogVo> gardenBlogApi = CrudHttpApiImpl<GardenBlogVo>(
      route: '/garden-blog',
      baseUrl: 'http://localhost:3010',
      fromEncodedJsonString: JsonGardenBlogVoMapper.decodeJsonList,
      toEncodedJsonString: JsonGardenBlogVoMapper.encodeJournalVo,
    );

    // task api
    final ICrudHttpApi<TaskVo> taskApi = CrudHttpApiImpl<TaskVo>(
      route: '/tasks',
      baseUrl: 'http://localhost:3010',
      fromEncodedJsonString: TaskVoMapper.decodeJsonList,
      toEncodedJsonString: TaskVoMapper.encodeTaskVo,
    );


    // snip bloc/repo
    // final SnippetBloc snippetBloc = SnippetBloc(
    //   repository: CrudRepositoryImpl<SnippetEntity, SnippetVo>(
    //     fromVoMapper: SnippetEntityMapper.fromVo,
    //     toVoMapper: SnippetEntityMapper.toVo,
    //     crudHttpApi: snippetApi,
    //   ),
    // );

    /// journal bloc/repo
    final JournalBloc journalBloc = JournalBloc(
      repository: CrudRepositoryImpl<JournalEntity, JournalVo>(
        fromVoMapper: JournalEntityMapper.fromVo,
        toVoMapper: JournalEntityMapper.toVo,
        crudHttpApi: journalApi,
      ),
    );
 /// gardenblog bloc/repo
    final GardenBlogBloc gardenBlogBloc = GardenBlogBloc(
      repository: GardenBlogRepositoryImpl(

      ),
    );

    /// project bloc/repo
    final ProjectBloc projectBloc = ProjectBloc(
      repository: ProjectRepository()

    );

    /// task bloc/repo
    final TaskBloc taskBloc = TaskBloc(
      repository: TaskRepositoryImpl(taskApi),
    );



    return MultiBlocProvider(
        providers: [
          BlocProvider<ProjectBloc>(
              create: (context) => projectBloc..add(LoadProjects())),
          BlocProvider<JournalBloc>(
              create: (context) => journalBloc..add(LoadJournals())),
          BlocProvider<GardenBlogBloc>(
              create: (context) => gardenBlogBloc),
              // create: (context) => gardenBlogBloc..add(LoadGardenBlogs())),

          BlocProvider<TaskBloc>(
              create: (context) => taskBloc..add(LoadTasks())),
          // BlocProvider<SnippetBloc>(
          //     create: (context) => snippetBloc..add(LoadSnippets())),

        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          initialRoute: HomeScreen.routeName,
          onGenerateRoute: AppRouter.onGenerateRoute,
          title: 'Flutter Demo',
          // theme: ThemeData(
          //   primarySwatch: Colors.blue,
          //   primaryColorDark: Colors.blue.shade900,
          //   primaryColorLight: Colors.blue.shade50,
          // ),
          home: const HomeScreen(),
        ));
  }
}