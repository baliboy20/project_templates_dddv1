import 'package:journal_macos/dev_utils/console_log.dart';

import '../../src/core/error/app_error.dart';

import 'http_crud_api.dart';

abstract  class CrudRepository2<E, V> {
  E Function(V vo) fromVoMapper;
  V Function (E entity) toVoMapper;
  CrudRepository2({
    required this.fromVoMapper,
    required this.toVoMapper,
  });
  Future<ResultRecord<AppException, List<E>>> getAll();

  Future<ResultRecord<AppException, E>> createOne(E entity);

  Future<ResultRecord<AppException, E>> updateOne(E entity);

  Future<ResultRecord<AppException, bool>> deleteImage(String filename);

  Future<ResultRecord<AppException, bool>> deleteOne(String id);

  Future<ResultRecord<AppException, List<E>>> filterOn(
      Map<String, dynamic> criteria );
}

class CrudRepositoryImpl<E, V> implements CrudRepository2<E, V> {
  final ICrudHttpApi<V> crudHttpApi;


  late E Function(V) _fromVoMapper;
  late V Function(E) _toVoMapper;

  CrudRepositoryImpl({
    required this.crudHttpApi,
    required E Function(V) fromVoMapper,
    required V Function(E) toVoMapper,
  }) {
    _fromVoMapper = fromVoMapper;
    _toVoMapper = toVoMapper;
  }

  E Function(V) get fromVoMapper => _fromVoMapper;
  set fromVoMapper(E Function(V) value) => _fromVoMapper = value;

  V Function(E) get toVoMapper => _toVoMapper;
  set toVoMapper(V Function(E) value) => _toVoMapper = value;

  @override
  Future<ResultRecord<AppException, List<E>>> getAll() async {
    try {
      final vos = await crudHttpApi.getAllItems();
      final entities = vos.map((vo) => fromVoMapper(vo)).toList();

      final reval = ResultRecord.returnTheValue(entities);
      return reval;
    } catch (e) {
      return ResultRecord.returnAnError(AppException(e.toString()));
    }
  }

  @override
  Future<ResultRecord<AppException, E>> createOne(E entity) async {
    try {
      final vo = toVoMapper(entity);
      final createdVo = await crudHttpApi.createItem(vo);
      final createdEntity = fromVoMapper(createdVo);
      return ResultRecord.returnTheValue(createdEntity);
    } catch (e) {
      return ResultRecord.returnAnError(AppException(e.toString()));
    }
  }

  @override
  Future<ResultRecord<AppException, E>> updateOne(E entity) async {
    try {
      final vo = toVoMapper(entity);
      final updatedVo = await crudHttpApi.updateItem(vo);
      final updatedEntity = fromVoMapper(updatedVo);
      return ResultRecord.returnTheValue(updatedEntity);
    } catch (e) {
      return ResultRecord.returnAnError(AppException(e.toString()));
    }
  }

  @override
  Future<ResultRecord<AppException, bool>> deleteOne(String id) async {
    try {
      final result = await crudHttpApi.deleteItemById(id);
      return ResultRecord.returnTheValue(result);
    } catch (e) {
      return ResultRecord.returnAnError(AppException(e.toString()));
    }
  }

  @override
  Future<ResultRecord<AppException, List<E>>> filterOn(
      Map<String, dynamic> criteria) async {
    try {
      final volist = await crudHttpApi.findItemsByTitle(criteria.values.first);
      if (volist.isEmpty) {
        return ResultRecord.returnResultWithError(
            AppException("no records"),
            []);
      }
      else if(volist.isNotEmpty){
        final en =  volist.map((e)=>fromVoMapper(e)).toList();
        return ResultRecord.returnTheValue(en);
      }
      // rewraps the existing exception for type safety
    } catch (e) {
      return ResultRecord.returnAnError(AppException(e.toString()));
    }
    throw Exception("should never reach here");
  }



@override
Future<ResultRecord<AppException, bool>> deleteImage(String filename) async{
    throw UnimplementedError();

    return ResultRecord.returnTheValue(true);
}

}


