import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:path/path.dart';

import '../../src/core/app_core.dart';

typedef Json = Map<String, dynamic>;

abstract class ICrudHttpApi<T> {
  final String baseUrl;

  ICrudHttpApi({required this.baseUrl});

  /// Say hello to test the API.
  Future<bool> sayHello();

  /// Fetch all items from the API.
  Future<List<T>> getAllItems();

  /// Find items by title.
  Future<List<T>> findItemsByTitle(String title);

  Future<T> findItemById(String id);

  /// Create a new item in the API.
  Future<T> createItem(T item);

  /// Update an existing item in the API.
  Future<T> updateItem(T item);

  /// Delete an item by its ID.
  Future<bool> deleteItemById(String id);

  Future<bool> deleteImage(String name);

  /// Filter items based on criteria.
  Future<List<T>> filterItems(Map<String, dynamic> criteria);


  Future<(String?,String?)>uploadImage(File _image);
}

class CrudHttpApiImpl<T> implements ICrudHttpApi<T> {
  final String baseUrl;
  final String route;
  final dynamic Function(String) fromEncodedJsonString;
  final String Function(dynamic) toEncodedJsonString;

  CrudHttpApiImpl(
      {required this.route, // = '/api/journal',
      required this.fromEncodedJsonString,
      required this.toEncodedJsonString,
      this.baseUrl = AppSettings.serverUrl});

  Future<bool> sayHello() async {
    final url = ('$baseUrl$route/sayhello');
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to say hello');
    }
  }

  // Fetch all journals
  Future<List<T>> getAllItems() async {
    try {
      final url = ('$baseUrl$route/findAll');
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = this.fromEncodedJsonString(response.body);
        final reval = data.cast<T>();
        return reval;
      } else {
        throw Exception('Failed to load journals');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Find journals by title
  Future<List<T>> findItemsByTitle(String title) async {
    final response =
        await http.get(Uri.parse('$baseUrl$route/filterItems?title=$title'));
    if (response.statusCode == 200) {
      return this.fromEncodedJsonString(response.body);
    } else {
      throw Exception('Failed to find snippet by title');
    }
  }

  Future<T> findItemById(String id) async {
    final response = await http.get(Uri.parse('$baseUrl$route/findById/$id'));
    if (response.statusCode == 200) {
      return this.fromEncodedJsonString(response.body);
    } else {
      throw Exception('Failed to find journals by title');
    }
  }

  // Create a new journal
  Future<T> createItem(T item) async {
    try {
      final str = this.toEncodedJsonString(item);

      final endpoint = ('$baseUrl$route/addOne');
      final response = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: str,
      );
      if (response.statusCode == 200) {
        return this.fromEncodedJsonString(response.body);
      } else {
        throw Exception(
            'Failed to create journal ${response.statusCode} ${response.body}.');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Update an existing journal
  Future<T> updateItem(T journal) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl$route/update'),
        headers: {'Content-Type': 'application/json'},
        body: toEncodedJsonString(journal),
      );
      if (response.statusCode == 200) {
        final vo = this.fromEncodedJsonString(response.body);
        return vo;
      } else {
        throw Exception(
            'Failed to update journal : ${response.statusCode}, ${response.body}');
      }
    } catch (e) {
      throw Exception('Failed to update journal: $e');
    }
  }

  // Delete a journal by ID
  Future<bool> deleteItemById(String id) async {
    print('deleteing');
    final response =
        await http.delete(Uri.parse('$baseUrl$route/deleteById/$id'));
    if (response.statusCode == 200) {
      return Future.value(true);
    } else {
      throw Exception('Failed to delete journal ${response.body}.');
    }
  }

  // Filter journals based on criteria
  Future<List<T>> filterItems(Map<String, dynamic> criteria) async {
    throw UnimplementedError('Filtering not implemented or tested');
  }

  Future<(String?,String?)> uploadImage(File _image) async {
    if (_image == null) return (null,null);
    final url = Uri.parse('$baseUrl$route/upload');
    var uri = Uri.parse('${url}/'); // Change URL
    var request = http.MultipartRequest('POST', uri);
    request.files.add(
      await http.MultipartFile.fromPath('image', _image!.path,
          filename: basename(_image!.path)),
    );
  final responseStream = await  request.send();
  if(responseStream.statusCode == 200) {
    final response = await http.Response.fromStream(responseStream);
    final body = response.body;
    final data =  jsonDecode(body);

    return (data["filename"] as String, data["path"] as String);
  }else
    throw Exception('Failed to upload image ${responseStream.statusCode}');
  }

  Future<bool> deleteImage(String name) async{
    try{
      final response = await http.delete(Uri.parse('$baseUrl$route/delete-file/$name'));
      if(response.statusCode != 200)
        throw Exception('Failed to delete image $name');

      return true;
    }catch (e){
      throw Exception('Failed to delete image $name');
    }


  }
}

////
//// CRUD repository implementation
////

class CrudHttpApiRawImpl implements ICrudHttpApi<Json> {
  final String baseUrl;
  final String route;


  CrudHttpApiRawImpl(
      {required this.route, // = '/api/journal',

        this.baseUrl = AppSettings.serverUrl});

  Future<bool> sayHello() async {
    final url = ('$baseUrl$route/sayhello');
    final response = await http.get(Uri.parse(url));
    if (response.statusCode == 200) {
      return true;
    } else {
      throw Exception('Failed to say hello');
    }
  }

  // Fetch all journals
  Future<List<Json>> getAllItems() async {
    try {
      final url = ('$baseUrl$route/findAll');
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final reval = data.cast<Json>();
        return reval;
      } else {
        throw Exception('Failed to load journals');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Find journals by title
  Future<List< Json>> findItemsByTitle(String title) async {
    final response =
    await http.get(Uri.parse('$baseUrl$route/filterItems?title=$title'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to find snippet by title');
    }
  }

  Future< Json> findItemById(String id) async {
    final response = await http.get(Uri.parse('$baseUrl$route/findById/$id'));
    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('Failed to find journals by title');
    }
  }

  // Create a new journal
  Future< Json> createItem(Json item) async {
    try {
      final str = jsonEncode(item);

      final endpoint = ('$baseUrl$route/addOne');
      final response = await http.post(
        Uri.parse(endpoint),
        headers: {'Content-Type': 'application/json'},
        body: str,
      );
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
            'Failed to create journal ${response.statusCode} ${response.body}.');
      }
    } catch (e) {
      rethrow;
    }
  }

  // Update an existing journal
  Future< Json> updateItem(Json journal) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl$route/update'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(journal),
      );
      if (response.statusCode == 200) {
        final vo = jsonDecode(response.body);
        return vo;
      } else {
        throw Exception(
            'Failed to update journal : ${response.statusCode}, ${response.body}');
      }
    } catch (e) {
      throw Exception('Failed to update journal: $e');
    }
  }

  // Delete a journal by ID
  Future<bool> deleteItemById(String id) async {
    print('deleteing');
    final response =
    await http.delete(Uri.parse('$baseUrl$route/deleteById/$id'));
    if (response.statusCode == 200) {
      return Future.value(true);
    } else {
      throw Exception('Failed to delete journal ${response.body}.');
    }
  }

  // Filter journals based on criteria
  Future<List<Json>> filterItems(Map<String, dynamic> criteria) async {
    throw UnimplementedError('Filtering not implemented or tested');
  }

  Future<(String?,String?)> uploadImage(File _image) async {
    if (_image == null) return (null,null);
    final url = Uri.parse('$baseUrl$route/upload');
    var uri = Uri.parse('${url}/'); // Change URL
    var request = http.MultipartRequest('POST', uri);
    request.files.add(
      await http.MultipartFile.fromPath('image', _image!.path,
          filename: basename(_image!.path)),
    );
    final responseStream = await  request.send();
    if(responseStream.statusCode == 200) {
      final response = await http.Response.fromStream(responseStream);
      final body = response.body;
      final data =  jsonDecode(body);

      return (data["filename"] as String, data["path"] as String);
    }else
      throw Exception('Failed to upload image ${responseStream.statusCode}');
  }

  Future<bool> deleteImage(String name) async{
    try{
      final response = await http.delete(Uri.parse('$baseUrl$route/delete-file/$name'));
      if(response.statusCode != 200)
        throw Exception('Failed to delete image $name');

      return true;
    }catch (e){
      throw Exception('Failed to delete image $name');
    }


  }
}