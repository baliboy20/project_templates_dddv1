

class WpCodeTime {
  final Stopwatch _stopwatch = Stopwatch();
  final List<(Duration, String)> _checkpoints = [];

  /// Starts the timer and clears previous checkpoints
  void start() {
    _stopwatch.reset();
    _stopwatch.start();
    _checkpoints.clear();
    _checkpoints.add((_stopwatch.elapsed, "Start"));
  }

  /// Adds a checkpoint with the current elapsed time and label
  void addCheckpoint(String label) {
    if (!_stopwatch.isRunning) return;
    final str = "$label \n${_getCallerInfo()}";
    _checkpoints.add((_stopwatch.elapsed, str));
  }

  /// Evaluates the time intervals between checkpoints and total duration
  String evaluate() {
    if (_checkpoints.isEmpty) return "No checkpoints recorded.";

    final buffer = StringBuffer();
    buffer.writeln("=== Execution Time Report ===");

    for (int i = 1; i < _checkpoints.length; i++) {
      final previous = _checkpoints[i - 1];
      final current = _checkpoints[i];
      final interval = current.$1 - previous.$1;

      buffer.writeln(
          "[${current.$1.inMilliseconds} ms] ${current.$2} (Δ ${interval.inMilliseconds} ms)");
    }

    buffer.writeln(
        "Total Execution Time: ${_stopwatch.elapsed.inMilliseconds} ms");
    _stopwatch.stop();



    return buffer.toString();
  }

 String _getCallerInfo() {
    try {
      final trace = StackTrace.current.toString().split('\n')[2];
      final match = RegExp(r'(#\d+\s+)?(.+)\s+\(([^)]+)\)').firstMatch(trace);
      if (match != null) {
        final functionName = match.group(2)?.trim() ?? 'Unknown';
        final location = match.group(3) ?? 'Unknown';
        return '$functionName at $location';
      }
    } catch (_) {}
    return 'Unknown Location';
  }



}

// void main() {
//   final timer = WpCodeTime();
//
//   timer.start();
//   Future.delayed(Duration(milliseconds: 200), () {
//     timer.addCheckpoint("Checkpoint 1");
//   });
//
//   Future.delayed(Duration(milliseconds: 400), () {
//     timer.addCheckpoint("Checkpoint 2");
//     print(timer.evaluate());
//   });
// }
