class wpLog {

  static const String _clear = '\x1B[2J\x1B[0;0H'; // Clears the screen and moves the cursor to the top-left
  static const String reset = '\x1B[0m';
  static const String red = '\x1B[31m';
  static const String green = '\x1B[32m';
  static const String yellow = '\x1B[33m';
  static const String blue = '\x1B[34m';
  static const String cyan = '\x1B[36m';
  static const String lightGrey = '\x1B[90m';

static List<String> messages = [];

static clearMessages()=> messages.clear();
static clearTerminal()=> print('\x1B[2J\x1B[0;0H');
static printMessages()=> messages.forEach(print);

  static bool _showAll = true;
  static  showAll() => _showAll = true;
  static  hideAall() => _showAll = false;

  wpLog.simple(arg) {
    print(arg);
  }
  wpLog(message,{overrideHide = false}){
    if (!_showAll && !overrideHide) {
      print(' ${lightGrey}  ...');
      return;
    }
    var callerInfo = '';
    callerInfo = _getCallerInfo();
    print('${'\x1B[33m'}[$callerInfo] $message$reset');
  }
  static void log(String message,
      {off = false, String color = reset, includeCallerInfo = true}) {
    if (off) return;
    var callerInfo = '';
    if (includeCallerInfo) {
      callerInfo = _getCallerInfo();
      print('$color[$callerInfo] $message$reset');
    } else {
      print('$color[$callerInfo] $message$reset');
    }
  }

  void call(message, {overrideHide = false}) {
    if (!_showAll && !overrideHide) {
      print(' ${lightGrey}  ...');
      return;
    }
    var callerInfo = '';
    callerInfo = _getCallerInfo();
    print('${'\x1B[33m'}[$callerInfo] $message$reset');
  }

  static void error(String message) => log(message, color: red);

  static void success(String message) => log(message, color: green);

  static void warning(String message) => log(message, color: yellow);

  static void info(String message) => log(message, color: blue);

  static void debug(String message) => log(message, color: cyan);

  static String _getCallerInfo() {
    try {
      final trace = StackTrace.current.toString().split('\n')[2];
      final match = RegExp(r'(#\d+\s+)?(.+)\s+\(([^)]+)\)').firstMatch(trace);
      if (match != null) {
        final functionName = match.group(2)?.trim() ?? 'Unknown';
        final location = match.group(3) ?? 'Unknown';
        return '$functionName at $location';
      }
    } catch (_) {}
    return 'Unknown Location';
  }
}
