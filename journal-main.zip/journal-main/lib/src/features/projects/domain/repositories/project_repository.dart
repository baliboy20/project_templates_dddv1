import 'package:parse_utils/infrastructure/api/parse_generic_service_api.dart';

import '../entities/project_entity.dart';

class ProjectRepository {
  final ParseApiService _apiService;

  ProjectRepository() : _apiService = ParseApiService('projects');

  Future<List<ProjectEntity>> getAllProjects() async {
    try {
      final results = await _apiService.getItems();
      return results.map((json) => ProjectEntity.fromJson(json)).toList();
    } catch (e) {
      print('Error fetching projects: $e');
      return [];
    }
  }

  Future<ProjectEntity?> getProjectById(String id) async {
    try {
      final result = await _apiService.getById(id);
      return result != null ? ProjectEntity.fromJson(result) : null;
    } catch (e) {
      print('Error fetching project by ID: $e');
      return null;
    }
  }

  Future<ProjectEntity?> addProject(ProjectEntity project) async {
    try {
      final result = await _apiService.addOne(project.toJson());
      return result != null ? ProjectEntity.fromJson(result) : null;
    } catch (e) {
      print('Error adding project: $e');
      return null;
    }
  }

  Future<ProjectEntity?> updateProject(ProjectEntity project) async {
    try {
      if (project.id == null) throw Exception('Project ID missing');
      final result = await _apiService.updateOne(project.id!, project.toJson());
      return result != null ? ProjectEntity.fromJson(result) : null;
    } catch (e) {
      print('Error updating project: $e');
      return null;
    }
  }

  Future<bool> deleteProject(String id) async {
    try {
      return await _apiService.deleteOne(id);
    } catch (e) {
      print('Error deleting project: $e');
      return false;
    }
  }
}




