
enum ProjectStatus { active, inactive, completed }