import 'package:journal_macos/dev_utils/console_log.dart';
import 'package:journal_macos/src/core/enums/editOrNew.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';
import '../../infrastructure/models/project_vo.dart';

class ProjectEntity {
  final String id;
  final String projectName;
  final String description;
  final List<String> snippetsId;
  final List<String> taskId;
  final List<String> journalId;
  final String projectStatus;
  final String projectPath;
  final DateTime? createdOn;

  ProjectEntity({
    required this.id,
    required this.projectName,
    required this.description,
    required this.snippetsId,
    required this.taskId,
    required this.journalId,
    required this.projectStatus,
    required this.projectPath,
    this.createdOn,
  });

  @override
  copyWith(args) {
    return ProjectEntity(
      id: args['id'] ?? id,
      projectName: args['projectName'] ?? projectName,
      description: args['description'] ?? description,
      snippetsId: args['snippetsId'] ?? snippetsId,
      taskId: args['taskId'] ?? taskId,
      journalId: args['journalId'] ?? journalId,
      projectStatus: args['projectStatus'] ?? projectStatus,
      projectPath: args['projectPath'] ?? projectPath,
      createdOn: args['createdOn'] ?? createdOn,
    );
  }

  @override
  toVo() {
    return ProjectVo(
      id: id,
      projectName: projectName,
      description: description,
      snippetsId: snippetsId,
      taskId: taskId,
      journalId: journalId,
      projectStatus: projectStatus,
      projectPath: projectPath,
      createdOn: createdOn,
    );
  }


  factory ProjectEntity.fromJson(Map<String, dynamic> json) {
    return ProjectEntity(
      id: json['objectId'] ?? "",
      projectName: json['projectName'] ?? '',
      description: json['description'] ?? '',
      snippetsId: List<String>.from(json['snippetsId'] ?? []),
      taskId: List<String>.from(json['taskId'] ?? []),
      journalId: List<String>.from(json['journalId'] ?? []),
      projectStatus: json['projectStatus'] ?? '',
      projectPath: json['projectPath'] ?? '',
      createdOn:
      json['createdOn'] != null ? DateTime.parse(json['createdOn']) : null,
    );
  }

  /// Converts the object to JSON.
  Map<String, dynamic> toJson() {
    return {
      'projectName': projectName,
      'description': description,
      'snippetsId': snippetsId,
      'taskId': taskId,
      'journalId': journalId,
      'projectStatus': projectStatus,
      'projectPath': projectPath,
      'id': id ?? '',
      'createdOn': createdOn?.toIso8601String(),
    };
  }


  factory ProjectEntity.empty() {
    return ProjectEntity(
      id: '',
      projectName: '',
      description: '',
      snippetsId: [],
      taskId: [],
      journalId: [],
      projectStatus: '',
      projectPath: '',
      createdOn: null,
    );
  }
}
