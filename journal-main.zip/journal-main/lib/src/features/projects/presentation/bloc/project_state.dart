import 'package:equatable/equatable.dart';

import '../../domain/entities/project_entity.dart';



abstract class ProjectState extends Equatable {
  @override
  List<Object?> get props => [];
}

class Loading extends ProjectState {}

class ProjectsLoaded extends ProjectState {
  final List<ProjectEntity> projects;
  ProjectsLoaded(this.projects);

  @override
  List<Object?> get props => [projects];
}

class ProjectSelectedForChanging extends ProjectState {
  final ProjectEntity project;
  ProjectSelectedForChanging(this.project);

  @override
  List<Object?> get props => [project];
}

class ProjectSaving extends ProjectState {}

class ProjectNotification extends ProjectState {
  final String message;
  ProjectNotification(this.message);

  @override
  List<Object?> get props => [message];
}

class NewProject extends ProjectState {}

class ProjectError extends ProjectState {
  final String message;
  ProjectError(this.message);

  @override
  List<Object?> get props => [message];
}
