import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/entities/project_entity.dart';
import '../../domain/repositories/project_repository.dart';
import 'project_event.dart';
import 'project_state.dart';

class ProjectBloc extends Bloc<ProjectEvent, ProjectState> {
  final List<ProjectEntity> items = [];
  final ProjectRepository repository;

  ProjectBloc({required this.repository}) : super(Loading()) {
    on<LoadProjects>(_onLoad);
    on<DeleteProject>(_onDeleteOne);
    on<SelectProject>(_onSelectProject);
    on<UpdateOne>(_onUpdateOne);
    on<CreateOne>(_onCreateOne);
  }

  Future<void> _getAll(Emitter<ProjectState> emit) async {
    final projects = await repository.getAllProjects();
    if (projects.isNotEmpty) {
      projects.sort((a, b) => b.createdOn != null && a.createdOn != null
          ? b.createdOn!.compareTo(a.createdOn!)
          : 0);
      emit(ProjectsLoaded(projects));
    } else {
      emit(ProjectError('No projects found'));
    }
  }

  void _onLoad(LoadProjects event, Emitter<ProjectState> emit) async {
    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    await _getAll(emit);
  }

  void _onDeleteOne(DeleteProject event, Emitter<ProjectState> emit) async {
    final success = await repository.deleteProject(event.id);
    if (success) {
      await _getAll(emit);
    } else {
      emit(ProjectError('Failed to delete project'));
    }
  }

  void _onUpdateOne(UpdateOne event, Emitter<ProjectState> emit) async {
    emit(ProjectSaving());
    final updatedProject = await repository.updateProject(event.project);
    if (updatedProject != null) {
      emit(ProjectNotification('Changes saved'));
       await _getAll(emit);

    } else {
      emit(ProjectError('Failed to save changes'));
    }
  }
// void _onSaveChanges(SaveChanges event, Emitter<ProjectState> emit) async {
//     emit(ProjectSaving());
//     final updatedProject = await repository.updateProject(event.project);
//     if (updatedProject != null) {
//       await _getAll(emit);
//       emit(ProjectNotification('Changes saved'));
//     } else {
//       emit(ProjectError('Failed to save changes'));
//     }
//   }

  void _onCreateOne(CreateOne event, Emitter<ProjectState> emit) async {
    emit(ProjectSaving());
    final updatedProject = await repository.addProject(event.project);
    if (updatedProject != null) {
      await _getAll(emit);
      emit(ProjectNotification('Changes saved'));
    } else {
      emit(ProjectError('Failed to save changes'));
    }
  }

  void _onSelectProject(SelectProject event, Emitter<ProjectState> emit) {
    // Implement project selection logic here
    throw UnimplementedError('SelectProject method not yet implemented');
  }
}
