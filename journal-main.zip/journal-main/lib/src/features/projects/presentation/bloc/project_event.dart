import 'package:equatable/equatable.dart';

import '../../domain/entities/project_entity.dart';




abstract class ProjectEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class LoadProjects extends ProjectEvent {}

class DeleteProject extends ProjectEvent {
  final String id;
  DeleteProject(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectProject extends ProjectEvent {
  final String id;
  SelectProject(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends ProjectEvent {
  final ProjectEntity project;

  SaveChanges(this.project);
}

class CreateOne extends ProjectEvent {
  final ProjectEntity project;

  CreateOne(this.project);
}


class SaveNew extends ProjectEvent {
  final ProjectEntity project;

  SaveNew(this.project );

  @override
  List<Object?> get props => [project];
}

class UpdateOne extends ProjectEvent {
  final ProjectEntity project;

  UpdateOne(this.project );

  @override
  List<Object?> get props => [project];
}



