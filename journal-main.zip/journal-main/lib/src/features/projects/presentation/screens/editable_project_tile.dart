part of 'projects_screen.dart';

class EditableProjectTile extends StatefulWidget {
  final ProjectEntity project;
  final ProjectBloc projectBloc;

  const EditableProjectTile(
      {Key? key, required this.projectBloc, required this.project})
      : super(key: key);

  @override
  State<EditableProjectTile> createState() => _EditableProjectTileState();
}

class _EditableProjectTileState extends State<EditableProjectTile> {
  late TextEditingController _nameController;
  late TextEditingController _statusController;
  late TextEditingController _pathController;
  late bool _isEditing = false;
  late GlobalKey _key = GlobalKey();

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.project.projectName);
    _statusController =
        TextEditingController(text: widget.project.projectStatus);
    _pathController = TextEditingController(text: widget.project.projectPath);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _statusController.dispose();
    _pathController.dispose();
    super.dispose();
  }

  void _updateProject(String field, String value) {
    final updatedProject = widget.project.copyWith({field: value});
    context.read<ProjectBloc>().add(UpdateOne(updatedProject));
  }

  void _deleteProject() {
    context.read<ProjectBloc>().add(DeleteProject(widget.project.id));
  }

  @override
  Widget build(BuildContext context) {

    return Card(
      key: _key,
      margin: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 8.0,
          children: [
            DeleteToolbar(
              removeItem: () => _deleteProject(),
            ),
            EditableTileTextField(
              updateProject: _updateProject,
              label: 'Name',
              field: 'projectName',
              value: widget.project.projectName,
            ),
            EditableTileTextField(
              field: 'projectPath',
              updateProject: _updateProject,
              label: 'path',
              value: widget.project.projectPath,
            ),
            EditableTileTextField(
              field: 'description',
              updateProject: _updateProject,
              label: 'Description',
              value: widget.project.description,
            ),
            EditableTileTextField(
              field: 'projectStatus',
              updateProject: _updateProject,
              label: 'Status',
              value: widget.project.projectStatus,
            ),
            LinearProgressIndicator(
              value: 0.5,
              valueColor: AlwaysStoppedAnimation(Colors.green),
              backgroundColor: Colors.grey.shade300,
            )
          ],
        ),
      ),
    );
  }
}

class EditableTileTextField extends StatefulWidget {
  final String label;
  final String value;
  final String field;
  final void Function(String field, String value) updateProject;

  const EditableTileTextField(
      {super.key,
      required this.field,
      required this.updateProject,
      required this.label,
      required this.value});

  @override
  State<EditableTileTextField> createState() => _EditableTileTextFieldState();
}

class _EditableTileTextFieldState extends State<EditableTileTextField> {
  late bool _isEditing = false;
  late TextEditingController controller;
  late FocusNode focusNode;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.value);
    focusNode = FocusNode();
    focusNode.addListener(() {
      if (!focusNode.hasFocus) {
        setState(() {
          _isEditing = false;

          if (widget.value != controller.text) {
            widget.updateProject(widget.field, controller.text);
          }
        });
      }
    });
  }

  @override
  void didUpdateWidget(covariant EditableTileTextField oldWidget) {
    super.didUpdateWidget(oldWidget);
    print('did update widget');
  }

  @override
  dispose() {
    controller.dispose();
    focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('building editable tile text field');
    return GestureDetector(
      onDoubleTap: () {
        setState(() {
          if (!_isEditing) {
            _isEditing = !_isEditing ? true : false;
            focusNode.requestFocus();
          }
        });
        // FocusScope.of(context).requestFocus(FocusNode());
      },
      child: _isEditing
          ? TextField(
              textInputAction: TextInputAction.done,
              focusNode: focusNode,
              controller: controller,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.zero,
                floatingLabelBehavior: FloatingLabelBehavior.always,
                labelText: widget.label,
                border: InputBorder.none,
              ),
            )
          : Text(controller.value.text ?? '   ?   ',
              style: TextStyle(
                  color: Colors.deepPurple, fontWeight: FontWeight.bold)),
    );
  }
}
