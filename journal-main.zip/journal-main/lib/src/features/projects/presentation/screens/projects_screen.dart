import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/src/core/enums/editOrNew.dart';
import 'package:journal_macos/src/features/dev_journal/presentation/widgets/hoverbar.dart';
import '../../../dev_journal/presentation/widgets/records_actions_toolbar.dart';
import '../bloc/project_bloc.dart';
import '../../domain/entities/project_entity.dart';
import '../bloc/project_event.dart';
import '../bloc/project_state.dart';
import '../widgets/records_actions_toolbar.dart';

part 'editable_project_tile.dart';

class ProjectsScreen extends StatefulWidget {
  static const routeName = '/projects';
  static const routeLabel = 'Projects';

  static genRoute() {
    return MaterialPageRoute(
      settings: RouteSettings(name: routeName),
      builder: (context) => ProjectsScreen(),
    );
  }

  const ProjectsScreen({Key? key}) : super(key: key);

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    print('initState');
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }


  @override
  Widget build(BuildContext context) {
    final ProjectBloc projectBloc = BlocProvider.of<ProjectBloc>(context);
    projectBloc.add(LoadProjects());
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(80),
          child: AppBar(
            backgroundColor: Colors.teal,
            actions: [
              Container(
                width: 75,
                margin: const EdgeInsets.only(right: 20),
                color: Colors.teal[200]?.withOpacity(.7),
                child: OverflowBar(
                  spacing: -15,
                  alignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.list, color: Colors.white70),
                      onPressed: () => _tabController.index = 0,
                    ),
                    IconButton(
                      icon:
                      const Icon(Icons.edit_document, color: Colors.white70),
                      onPressed: () => _tabController.index = 1,
                    ),
                  ],
                ),
              ),
            ],
            leading: IconButton(
              icon: const Icon(
                  Icons.arrow_back_ios_rounded, color: Colors.white),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ),
        body: BlocConsumer<ProjectBloc, ProjectState>(
          listener: (context, state) {
            if (state is ProjectError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: Colors.red,
                ),
              );
            } else if (state is ProjectNotification) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: Colors.green,
                ),
              );
            }
          },
          listenWhen: (previous, current) =>
          current is ProjectError || current is ProjectNotification,
          builder: (context, state) {
            if (state is Loading) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is ProjectsLoaded) {
              return ProjectListingView(projects: state.projects);
            } else if (state is ProjectSaving) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is ProjectSelectedForChanging) {
              return ProjectFormScreen(project: state.project);
            } else if (state is ProjectError) {
              return Center(child: Text('Error: ${state.message}'));
            } else {
              return const Center(
                  child: Text('Welcome to the Project Manager!'));
            }
          },
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () =>
              _showBottomSheetNew(context, ProjectEntity.empty(), EditOrNew.New),
        child: const Icon(Icons.add),)
    ,
    );
  }

  void _showBottomSheetNew(BuildContext context, ProjectEntity project,
      EditOrNew editOrNew) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding:
          EdgeInsets.only(bottom: MediaQuery
              .of(context)
              .viewInsets
              .bottom),
          child: ProjectFormScreen(project: project, isNew: editOrNew),
        );
      },
    );
  }
}

// List of tiles of Projects
class ProjectListingView extends StatelessWidget {
  final List<ProjectEntity> projects;

  const ProjectListingView({Key? key, required this.projects})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: projects.length,
      itemBuilder: (context, index) {
        final project = projects[index];
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 10.0),
          child: EditableProjectTile(
              project: project, projectBloc: context.read<ProjectBloc>()),
        );
      },
    );
  }
}


class _ProjectTile extends StatelessWidget {
  final ProjectEntity project;

  const _ProjectTile({Key? key, required this.project}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      isThreeLine: true,
      title: Text(project.projectName,
          style: const TextStyle(
            height: 2.0,
          )),
      subtitle: _subtitle(project),
      onTap: () => _showBottomSheet(context, project),
    );
  }

  Widget _subtitle(ProjectEntity project) {
    return Text.rich(
      TextSpan(
          text: '${project.projectStatus} \n',
          style: TextStyle(
            color: project.projectStatus == 'Active'
                ? Colors.green
                : Colors.grey[600],
          ),
          children: [
            TextSpan(
                text: '${project.description}\n',
                style: TextStyle(
                  color: Colors.grey[600],
                )),


            TextSpan(
              text: 'Folder: ${project.projectPath}',
              style: TextStyle(
                color: Colors.grey[600],
              ),
            ),
          ]),
    );
  }

  void _showBottomSheet(BuildContext context, ProjectEntity project) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Padding(
          padding:
          EdgeInsets.only(bottom: MediaQuery
              .of(context)
              .viewInsets
              .bottom),
          child: ProjectFormScreen(project: project, isNew:
          EditOrNew.Edit),
        );
      },
    );
  }
}


class ProjectFormScreen extends StatefulWidget {
  final ProjectEntity? project;
  final EditOrNew isNew;

  const ProjectFormScreen({Key? key, this.project, this.isNew = EditOrNew.Edit})
      : super(key: key);

  @override
  _ProjectFormScreenState createState() => _ProjectFormScreenState();
}

class _ProjectFormScreenState extends State<ProjectFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _descriptionController;
  late TextEditingController _statusController;
  late TextEditingController _pathController;

  @override
  void initState() {
    super.initState();
    _nameController =
        TextEditingController(text: widget.project?.projectName ?? '');
    _descriptionController =
        TextEditingController(text: widget.project?.description ?? '');
    _statusController =
        TextEditingController(text: widget.project?.projectStatus ?? '');
    _pathController =
        TextEditingController(text: widget.project?.projectPath ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _statusController.dispose();
    _pathController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print('jello');
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew == EditOrNew.New ? 'New Project ..' : 'Edit Project aa'),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.orange, Colors.tealAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              spacing: 20,
              children: [
                TextFormField(
                  //project name field
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Project Name',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? 'Please enter the project name'
                      : null,
                ),

                // project description field.
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 4,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? 'Please enter a description'
                      : null,
                ),
                // project status field.
                TextFormField(
                  controller: _statusController,
                  decoration: const InputDecoration(
                    labelText: 'Status',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? 'Please enter the project status'
                      : null,
                ),

                // project path field.
                TextFormField(
                  controller: _pathController,
                  decoration: const InputDecoration(
                    labelText: 'Path',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) =>
                  value == null || value.isEmpty
                      ? 'Please enter the project path'
                      : null,
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () {
                        if (_formKey.currentState?.validate() ?? false) {
                          final changes = ProjectEntity(
                            id: widget.project?.id ?? '',
                            projectName: _nameController.text,
                            description: _descriptionController.text,
                            snippetsId: widget.project?.snippetsId ?? [],
                            taskId: widget.project?.taskId ?? [],
                            journalId: widget.project?.journalId ?? [],
                            projectStatus: _statusController.text,
                            projectPath: _pathController.text,
                          );

                          context.read<ProjectBloc>().add(
                              widget.isNew == EditOrNew.Edit
                                  ? SaveChanges(changes)
                                  : CreateOne(changes)
    );

                          Navigator.pop(context);

                      }},
                      icon: const Icon(Icons.save),
                      label: const Text('Save'),
                    )
    ,
                    OutlinedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.cancel),
                      label: const Text('Cancel'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


