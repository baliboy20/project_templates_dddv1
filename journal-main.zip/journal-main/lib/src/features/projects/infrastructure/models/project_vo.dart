import 'dart:convert';

import 'package:bson/bson.dart';
import 'package:equatable/equatable.dart';

import '../../../../../dev_utils/console_log.dart';

class ProjectVo extends Equatable {
  final String projectName;
  final String description;
  final List<String> snippetsId;
  final List<String> taskId;
  final List<String> journalId;
  final String projectStatus;
  final String projectPath;
  final String? id;
  final DateTime? createdOn;

  const ProjectVo({
    required this.projectName,
    required this.description,
    required this.snippetsId,
    required this.taskId,
    required this.journalId,
    required this.projectStatus,
    required this.projectPath,
    this.id,
    this.createdOn,
  });

  /// Factory constructor to create an instance from JSON.
  factory ProjectVo.fromJson(Map<String, dynamic> json) {
    String idstr;
    if (json['_id'] is ObjectId) {
      idstr = (json['_id'] as ObjectId).toHexString();
    } else if (json['_id'] is String) {
      idstr = json['_id'];
    } else {
      idstr = '';
    }
    return ProjectVo(
      projectName: json['projectName'] ?? '',
      description: json['description'] ?? '',
      snippetsId: List<String>.from(json['snippetsId'] ?? []),
      taskId: List<String>.from(json['taskId'] ?? []),
      journalId: List<String>.from(json['journalId'] ?? []),
      projectStatus: json['projectStatus'] ?? '',
      projectPath: json['projectPath'] ?? '',
      id: idstr,
      createdOn:
          json['createdOn'] != null ? DateTime.parse(json['createdOn']) : null,
    );
  }

  /// Converts the object to JSON.
  Map<String, dynamic> toJson() {
    return {
      'projectName': projectName,
      'description': description,
      'snippetsId': snippetsId,
      'taskId': taskId,
      'journalId': journalId,
      'projectStatus': projectStatus,
      'projectPath': projectPath,
      'id': id ?? '',
      'createdOn': createdOn?.toIso8601String(),
    };
  }

  /// Static method to create a new instance with default values.
  static ProjectVo newInstance() {
    return ProjectVo(
      projectName: '',
      description: '',
      snippetsId: [],
      taskId: [],
      journalId: [],
      projectStatus: '',
      projectPath: '',
      id: null,
      createdOn: null,
    );
  }

  /// Concatenates fields into a single string.
  String concatenateFields() {
    return '$projectName$description${snippetsId.join()}${taskId.join()}${journalId.join()}$projectStatus$projectPath';
  }

  /// Override the `props` for Equatable comparison.
  @override
  List<Object?> get props => [
        projectName,
        description,
        snippetsId,
        taskId,
        journalId,
        projectStatus,
        projectPath,
        id,
        createdOn,
      ];

  /// Implements the `fromJson` method required by `ValueObjectMappable`.
  @override
  ProjectVo fromJson(Map<String, dynamic> json) {
    return ProjectVo.fromJson(json);
  }
}

class JsonProjectVoMapper {
  static ProjectVo fromJson(Map<String, dynamic> json) {
    return ProjectVo.fromJson(json);
  }

  static Map<String, dynamic> toJson(ProjectVo value) {
    return value.toJson();
  }

  static List<ProjectVo> fromJsonList(List<Map<String, dynamic>> jsonList) {
    return jsonList.map((json) => ProjectVo.fromJson(json)).toList();
  }

  static List<Map<String, dynamic>> toMapList(List<ProjectVo> value) {
    return value.map((value) => value.toJson()).toList();
  }

  static List<ProjectVo> fromJsonEncoded(String jsonStr) {
    final List<dynamic> jsonList = jsonDecode(jsonStr);
    final List<Map<String, dynamic>> json = jsonList.cast<Map<String, dynamic>>();
   var retval =  JsonProjectVoMapper.fromJsonList(json);
   return retval;
  }
  static String toJsonString(value) {
    return jsonEncode(JsonProjectVoMapper.toMapList(value));
  }
}
