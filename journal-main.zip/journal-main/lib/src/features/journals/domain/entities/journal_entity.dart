import 'package:bson/bson.dart';
import 'package:equatable/equatable.dart';

import '../../infrastructure/models/journal_vo.dart';


class JournalEntity extends Equatable {
  final String title;
  final List<String> categories;
  final String body;
  final String? id; // Unique identifier
  final DateTime createdOn;
  final String postedBy;

  JournalEntity({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  });

  /// Factory method to create an Entity from a Value Object (Vo)
  factory JournalEntity.fromVo(JournalVo vo) {

    return JournalEntity(
      title: vo.title,
      categories: vo.categories,
      body: vo.body,
      id: vo.id ?? '', // Ensure non-null id (or assign default if needed)
      createdOn: vo.createdOn,
      postedBy: vo.postedBy,
    );
  }

  /// Method to convert the Entity back to a Value Object (Vo)
  JournalVo toVo() {
    return JournalVo(
      title: title,
      categories: categories,
      body: body,
      id:  id , // Ensure non-null id (or assign default if needed)
      createdOn: createdOn,
      postedBy: postedBy,
    );
  }

  String formattedDate() {
    return '${createdOn.day}-${createdOn.month}-${createdOn.year}';
  }


  /// Define props for Equatable to consider `id` as the unique property
  @override
  List<Object?> get props => [id];

  factory JournalEntity. empty() {
    return JournalEntity(
      title: '',
      categories: [],
      body: '',
      id: ObjectId().toHexString(),
      createdOn: DateTime.now(),
      postedBy: 'William',
    );
  }
}


class JournalEntityMapper {
  static JournalEntity fromVo(JournalVo vo) {
    return JournalEntity.fromVo(vo);

  }
  static JournalVo toVo(JournalEntity value) {
    return value.toVo();
  }
  static List<JournalEntity> fromVoList(List<JournalVo> voList) {
    return voList.map((vo) => fromVo(vo)).toList();
    }
  static List<JournalVo> toVoList(List<JournalEntity> entityList) {
    return entityList.map((entity) => toVo(entity)).toList();
  }
}
