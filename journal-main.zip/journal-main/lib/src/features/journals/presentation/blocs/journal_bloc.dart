
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/src/core/error/app_error.dart';
import 'package:journal_macos/src/features/journals/infrastructure/models/journal_vo.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_events.dart';
import 'package:journal_macos/src/features/journals/presentation/blocs/journal_states.dart';

import '../../domain/entities/journal_entity.dart';

class    JournalBloc extends Bloc<JournalEvent, JournalState> {
  final List<JournalEntity> _journals = [];
  final CrudRepositoryImpl<JournalEntity, JournalVo> repository;

  JournalBloc({required this.repository}) : super(Loading()) {
    on<LoadJournals>(_onLoadJournals);
    on<DeleteJournal>(_onDeleteJournal);
    on<AddOne>(_onAddOne);
    on<SaveChanges>(_onSaveChanges);

  }

  void _getAll(emitter) async {
    final result = await repository.getAll();
    if (result.hasValue()) {
      final List<JournalEntity>journals = result.value!;
      journals.sort((a, b) => b.createdOn.compareTo(a.createdOn));
      emit(JournalsLoaded(journals));
      if (result.hasError()) {
        emit(JournalError(result.error!.message));
      }
    }
  }

  void _onLoadJournals(LoadJournals event, Emitter<JournalState> emit) async {

    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    _getAll(emit);
  }

  void _onDeleteJournal(DeleteJournal event, Emitter<JournalState> emit)async {
    final result = await repository.deleteOne(event.id);
    if (result.hasValue())
      _getAll(emit);

    if (result.hasError()) {
      emit(JournalError(result.error!.message));
    }
  }




    void _onSaveChanges(SaveChanges event, Emitter<JournalState> emit) async {
      emit(JournalSaving());

      final result = await repository.updateOne(event.journal);
      if (result.hasValue()) {
        _getAll(emit);
        emit(JournalNotification('Changes saved'));
      }


      if (result.hasError()) {
      // await  Future.delayed(Duration(milliseconds: 1500));
        emit(JournalError(result.error!.message));
      }
    }

  void _onAddOne(AddOne event, Emitter<JournalState> emit) async {
    emit(JournalSaving());

    final result = await repository.createOne(event.journal);
    if (result.hasValue()) {
      _getAll(emit);
      emit(JournalNotification('Changes saved'));
    }

    if (result.hasError()) {
      emit(JournalError(result.error!.message));
    }
  }


  }
