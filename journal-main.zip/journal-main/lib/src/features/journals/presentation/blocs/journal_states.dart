// journal_state.dart
import 'package:equatable/equatable.dart';
import '../../domain/entities/journal_entity.dart';
 

abstract class JournalState extends Equatable {
  @override
  List<Object?> get props => [];
}

class Loading extends JournalState {}

class JournalsLoaded extends JournalState {
  final List<JournalEntity> journals;
  JournalsLoaded(this.journals);

  @override
  List<Object?> get props => [journals];
}

class JournalSelectedForChanging extends JournalState {
  final JournalEntity journal;
  JournalSelectedForChanging(this.journal);

  @override
  List<Object?> get props => [journal];
}

/// shows progress button.
class JournalSaving extends JournalState {}

class JournalNotification extends JournalState {
  final String message;
  JournalNotification(this.message);

  @override
  List<Object?> get props => [message];
}

class NewJournal extends JournalState {}

class JournalError extends JournalState {
  final String message;
  JournalError(this.message);

  @override
  List<Object?> get props => [message];
}