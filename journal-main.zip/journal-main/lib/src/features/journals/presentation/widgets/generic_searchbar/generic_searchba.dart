//============================================================
// template created on: 2023-06-14 16:48:22.701639
// version: 1.1
//============================================================

import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';



/// A generic search bar that can be used in any screen.
/// It takes a callback function that is called when the user types in the search bar.
/// The callback function is debounced to avoid calling it too frequently.
/// The debounce time can be set by the user.
/// ```dart
/// class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
///  final GlobalKey<AnimatedListState> _listKey = GlobalKey<AnimatedListState>();
///  List<String> _items = testData;
///
///
///
///  void Function(String) get _callback => (arg) {
///    print('arg is $arg');
///    final result = testData.where((word) => word.contains(arg)).toList();
///    _items = result;
///    print(result);
///    setState(() {});
///  };
///
///  @override
///  Widget build(BuildContext context) {
///    return Scaffold(
///      appBar: AppBar(
///        actions: [
///          SizedBox(
///            width: 200,
///            child: GenericSearchbar(
///              callback: _callback,
///              debounceTime: 500,
///            ),
///          ),
///        ],
///        title: IconButton(onPressed: () => null, icon: Icon(Icons.search)),
///        bottom: PreferredSize(
///          preferredSize: Size.fromHeight(150),
///          child: Container(
///            height: 150,
///            color: Colors.blue,
///            child: Center(
///              child: Text('Hello, world!'),
///            ),
///          ),
///        ),
///      ),
///      body: ListView.builder(
///
///        key: _listKey,
///        itemCount: _items.length,
///        itemBuilder: (BuildContext context, int index) {
///          return _buildItem(_items[index]);
///        },
///      ),
///      floatingActionButton: FloatingActionButton(
///        onPressed: ()=> null,//_addItem,
///        child: Icon(Icons.add),
///      ),
///    );
///  }
///
///  Widget _buildItem(String item) {
///    return SizeTransition(
///
///      sizeFactor: CurvedAnimation(
///        parent: AnimationController(
///          duration: const Duration(milliseconds: 500),
///          vsync: this,
///        )..forward(),
///        curve: Curves.easeOut,
///        reverseCurve: Curves.easeIn,
///      ),
///      child: Card(
///        color: Colors.amber,
///        child: ListTile(
///          title: Center(child: Text('$item')),
///          trailing: IconButton(
///            icon: Icon(Icons.delete),
///            onPressed: () => null,
///          ),
///        ),
///      ),
///    );
///  }
///}
///
/// ```
class GenericSearchbar extends StatefulWidget {

  final int debounceTime;
  final Function(String inputValue) callback;

  GenericSearchbar({Key? key, required
  this.debounceTime,
    required this.callback
  }) : super(key: key);

  @override
  State<GenericSearchbar> createState() => _GenericSearchbarState();
}

class _GenericSearchbarState extends State<GenericSearchbar>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  late TextEditingController _searchController;
  String lastval = '';

  @override
  bool get wantKeepAlive => true;

  @override
  initState() {
    super.initState();
    _searchController = TextEditingController();
    print('init state');
    _searchController.addListener(() {
      print('listening');
      if (_searchController.text.length <= 1) return;
      if (_searchController.text == lastval) return;
      lastval = _searchController.text;
      Debouncer.instanceOf(millis: 500)
        ..run(() {
          widget.callback(_searchController.text);
          // BlocProvider.of<JournalBloc>(context)
          //     .add(DbFilterJournals(criteria: {"find": widget.searchController.text}));
        });
    });
  }

  @override
  Widget build(BuildContext context) {
    return TextField(

      controller: _searchController,
      decoration: InputDecoration(

        suffix: IconButton(
          icon: Icon(Icons.close),
          onPressed: () {
            _searchController.text = '';
          },
        ),
        filled: true,
        fillColor: Colors.white30,
        hintText: 'Enter search terms separated by comma ',
        border: OutlineInputBorder(
          gapPadding: 60,
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}

//todo: add this.
class Debouncer {
  final int milliseconds;
  static Timer? _timer;
  static Debouncer? _debouncer;

  static Debouncer instanceOf({int millis = 200}) {
    return _debouncer ?? Debouncer(milliseconds: millis);
  }

  Debouncer({required this.milliseconds});

  run(VoidCallback action) {
    if (_timer == null || !_timer!.isActive)
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    else {
      _timer?.cancel();
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    }
  }
}
