import 'dart:convert';

import 'package:bson/bson.dart';
import 'package:ddd_framework_assets/core/validation/json_validator.dart';
import 'package:equatable/equatable.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';

abstract interface class Encodable<T> {
  Map<String, dynamic> toJson();

  T fromJson(Map<String, dynamic> json);
}

class JournalVo extends Equatable {
  final String title;
  final List<String> categories;
  final String body;
  final String? id;
  final DateTime createdOn;
  final String postedBy;

  JournalVo({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  });

  DateTime getDateFromObjectId(String objectId) {
    try {
      // Convert the first 8 characters (representing the timestamp) to a 4-byte integer
      final timestampHex = objectId.substring(0, 8);
      final timestamp = int.parse(timestampHex, radix: 16);
      // Convert Unix timestamp to a DateTime object
      return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000, isUtc: true);
    } catch (e) {
      throw FormatException('Invalid ObjectId format: $e');
    }
  }

  factory JournalVo.fromJson(Map<String, dynamic> json) {

    String idstr;
    if(json['_id'] is ObjectId) {
      idstr = json['_id'].toHexString();
    } else {
      idstr = json['_id'] ?? '';
    }

    final vo = JournalVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      id: idstr,
      createdOn: DateTime.parse(idstr),
      postedBy: json['postedBy'] ?? 'Guest poster',
    );

    return vo;
  }

  @override
  List<Object> get props => [title, categories, body, id!, createdOn, postedBy];

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'categories': categories,
      'body': body,
      'id': id ?? '',
      'createdOn': createdOn.toIso8601String(),
      'postedBy': postedBy,
    };
  }

  static JournalVo newInstance() {
    return JournalVo(
      title: '',
      categories: [],
      body: '',
      id: null,
      createdOn: DateTime.now(),
      postedBy: '',
    );
  }

  String concatenateFields() {
    return '${title}${categories.join()}${body}${postedBy}';
  }

  @override
  JournalVo fromJson(Map<String, dynamic> json) {
    return JournalVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      id: json['id'] ?? null,
      createdOn: json['createdOn'],
      postedBy: json['postedBy'],
    );
  }
}

class JournalVoMapper{
  static JournalVo fromJson(Map<String, dynamic> json) {
    return JournalVo.fromJson(json);
  }
  static fromJsonList(List<Map<String, dynamic>> jsonList) {
    return jsonList.map((json) => JournalVo.fromJson(json)).toList();

  }
  static Map<String, dynamic> toJson(JournalVo value) {
    return value.toJson();
  }
  static List<Map<String, dynamic>> toMapList(List<JournalVo> value) {
    return value.map((value) => value.toJson()).toList();
  }
  static String toJsonString(value) {
    if(value is JournalVo)
      return jsonEncode(value.toJson());
    else if(value is List<JournalVo>)
    return jsonEncode(toMapList(value));
    else
      throw Exception('unsupported type should be list or JounnalVo ${value}');

  }
  static dynamic fromJsonEncoded(String jsonStr) {
   try {
      final json = jsonDecode(jsonStr);
      print(json is List<dynamic>);
      print(json is List);
      print(json is List<Map>);
      print(json.runtimeType);
      if (json is Map<String, dynamic>) {
        return JournalVo.fromJson(json);
      }
      if (json is List<dynamic>) {
        final b = ['erer'];
        return fromJsonList(json.cast<Map<String, dynamic>>());
      }




      throw Exception('unsupported type should be list or JounnalVo ${json.runtimeType}');
    }catch (e) {
     print('$e');
     rethrow;
   }
  }
}
