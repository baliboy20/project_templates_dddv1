// journal_repository.dart
import '../../domain/entities/journal_entity.dart';
import '../models/journal_vo.dart';

abstract class JournalRepository {
  Future<List<JournalEntity>> getAllJournals();
  Future<List<JournalVo>> findJournalsByTitle(String title);
  Future<List<JournalEntity>> createJournal(JournalEntity journal);
  Future<List<JournalEntity>>updateJournal(JournalEntity journal);
  Future<List<JournalEntity>> deleteJournalById(String id);
  Future<List<JournalVo>> filterJournals(Map<String, dynamic> criteria);
}
