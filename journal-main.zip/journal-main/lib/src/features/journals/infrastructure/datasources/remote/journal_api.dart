import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/generic_crud/repository/http_crud_api.dart';

import '../../mappers/json_journalvo_mappers.dart';
import '../../models/journal_vo.dart';
 


//
// class  JournalApi extends CrudHttpApiImpl<JournalVo> {
//
//
//   JournalApi(
//       {required String baseUrl}
//       ):super(
//     fromJsonFactory: JsonJournalVoMapper.decodeJsonList,
//     toJsonFactory: JsonJournalVoMapper.encodeJournalVo,
//     baseUrl: baseUrl,
//   );
//
//   @override
//   Future<JournalVo> createItem(JournalVo item) async{
//     return super.createItem(item);
//   }
//
//   @override
//   Future<bool> deleteItemById(String id) async{
//     return super.deleteItemById(id);
//   }
//
//   @override
//   Future<List<JournalVo>> filterItems(Map<String, dynamic> criteria) {
//     return super.filterItems(criteria);
//   }
//
//   @override
//   Future<JournalVo> findItemById(String id) {
//     return super.findItemById(id);
//   }
//
//   @override
//   Future<List<JournalVo>> findItemsByTitle(String title) {
//     return super.findItemsByTitle(title);
//   }
//
//   @override
//   Future<List<JournalVo>> getAllItems() {
//     return super.getAllItems();
//   }
//
//   @override
//   Future<bool> sayHello() {
//     return super.sayHello();
//   }
//
//   @override
//   Future<JournalVo> updateItem(JournalVo item) {
//     return super.updateItem(item);
//   }
//
//
// }
