// import 'dart:async';
// import 'dart:convert';
// import 'package:http/http.dart' as http;
// import 'package:journal_macos/src/features/journals/domain/entities/journal_entity.dart';
// import 'package:journal_macos/src/features/journals/infrastructure/datasources/remote/journals.testdata.dart';
// import 'package:journal_macos/src/features/journals/infrastructure/models/journal_vo.dart';
//
// typedef JsonMapType = Map<String, dynamic>;
// typedef  JsonMapFnType<T> =  T Function(JsonMapType);
//
// class JsonService<T extends Encodable> {
//   final JsonMapFnType<T> decoder;
//
//   JsonService({required this.decoder});
//
//   T decode(JsonMapType arg) {
//     return decoder(arg);
//
//   }
// }
//
// ///
// /// bloc callRepoTask -> isvalid -> haspermission ->
// ///
// ///
// class Fortitude<T extends Encodable> {
//   StreamController<List<JournalVo>> stream = StreamController();
//   void findAll(){
//
//     String user = "Wil";
//     stream.stream.asyncMap((a)=>http.get(Uri.parse('path')))
//     .map((http.Response a) => a.statusCode == 200 ? a.body : throw Exception('full of smells'))
//     .map((String encoded) => jsonDecode(encoded) as List<Map<String, dynamic>>)
//     .map((List<Map<String, dynamic>> list) =>
//         list.map((e)=> JournalEntity.fromVo(JournalVo.fromJson(e))))
//
//     ;
//
//
//
//   }
//
// }
//
//
//
//
// main() async{
//
//   final headers = <String, String>{
//     'Content-Type': 'application/json; charset=UTF-8',
//   };
//
//   final  JsonMapFnType<JournalVo> fn = JournalVo.fromJson;
//  final JsonMapType json = testData.first.toJson();
//   final JsonService<JournalVo> service  = JsonService(decoder: fn);
//  final result =  service.decoder(json);
//
// print('result: $result');
// }
//
//
//
// extension JsonEncoding on Map<String, dynamic> {
//
//   String toJsonString<V extends Encodable>(List<V> arg) {
//     return jsonEncode(arg.map((e) => e.toJson()).toList());
//   }
// }
//
//
// // final JsonMapFnType<JournalVo> json = (JsonMapType json) => JournalVo.fromJson(json);
// //
// //
// // ///======== Mixin
// //   mixin class JsonVoEncoding <V extends Encodable>{
// //
// //
// //
// //   V Function(JsonMapType) get constructor => fromJson;
// //   ///==
// //     String toJsonString( List<V> arg) {
// //       return jsonEncode(arg.map((e) => e.toJson()).toList());
// //     }
// // ///==
// //     List<V> fromJsonString(String arg, V Function(Map<String, dynamic>) classConstructor) {
// //       assert(classConstructor.runtimeType is V Function(Map<String, List<dynamic>>),
// //           'constructor must be a function that takes a Map<String, dynamic> and returns V');
// //
// //       final List<JsonMapType> b = (jsonDecode(arg) as List<JsonMapType>);
// //
// //          b.map((e) => V.;
// //     }
// //
// //   }
// //
// // T> fromJsonString<T extends Encodable>(
// //       String arg, T Function(Map<String, dynamic>) classConstructor) {
// //     assert(classConstructor.runtimeType is T Function(Map<String, List<dynamic>>),
// //         'constructor must be a function that takes a Map<String, dynamic> and returns T');
// //
// //     return jsonDecode(arg).map((e) => classConstructor(e)).toList() as List<T>;
// //   }
// // }
// //
//
//
//
// class JournalDatasource<T extends Encodable> {
//   final String baseUrl;
//
//
//   JournalDatasource({
//     required this.baseUrl,
//
//   });
//
//   Future<List<T>?> getItems() async {
//     try {
//       final response = await http.get(Uri.parse('$baseUrl/findAll'));
//       if (response.statusCode == 200) {
//         Iterable list = json.decode(response.body);
//
//       //  final a =  Map<String, dynamic>().fromJsonString<T>(response.body, T.fromJson);
//
//         return null;
//       } else {
//         throw Exception('Failed to load items');
//       }
//     } catch (e) {
//       print(e.toString());
//       return [];
//     }
//   }
//
//   Future<List<T>?> findItemsWhere(Map<String, dynamic> criteria) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/findBy'),
//         headers: <String, String>{
//           'Content-Type': 'application/json; charset=UTF-8',
//         },
//         body: jsonEncode(criteria),
//       );
//       if (response.statusCode == 200) {
//         Iterable list = json.decode(response.body);
//         return null;
//         // return list.map((e) => fromJson(e as Map<String, dynamic>)).toList();
//       } else {
//         throw Exception('Failed to load items');
//       }
//     } catch (e) {
//       print(e.toString());
//       return [];
//     }
//   }
//
//   Future<T?> updateItem(T item) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/update'),
//         headers: <String, String>{
//           'Content-Type': 'application/json; charset=UTF-8',
//         },
//         body: jsonEncode(item.toJson()),
//       );
//       if (response.statusCode == 200) {
//         return null; //fromJson(json.decode(response.body));
//       } else {
//         throw Exception('Failed to update item');
//       }
//     } catch (e) {
//       print(e.toString());
//       return null;
//     }
//   }
//
//   Future<T?> addItem(T item) async {
//     try {
//       final response = await http.post(
//         Uri.parse('$baseUrl/addOne'),
//         headers: <String, String>{
//           'Content-Type': 'application/json; charset=UTF-8',
//         },
//         body: jsonEncode(item.toJson()),
//       );
//       if (response.statusCode == 200) {
//         return null;// fromJson(json.decode(response.body));
//       } else {
//         throw Exception('Failed to add item');
//       }
//     } catch (e) {
//       print(e.toString());
//       return null;
//     }
//   }
//
//   Future<dynamic> deleteItem(T item) async {
//     try {
//       final response = await http.delete(
//         Uri.parse('$baseUrl/deleteById'),
//         headers: <String, String>{
//           'Content-Type': 'application/json; charset=UTF-8',
//         },
//         body: jsonEncode(item.toJson()),
//       );
//       if (response.statusCode == 200) {
//         return json.decode(response.body);
//       } else {
//         throw Exception('Failed to delete item');
//       }
//     } catch (e) {
//       print(e.toString());
//       return null;
//     }
//   }
//
//   Future<List<T>> getList() {
//     // Implement your own logic if needed
//     throw UnimplementedError();
//   }
//
//   ///  ###### Compares timestamps between collection a ui to see if need updating. __
//   Future<bool> hasDataChanged() {
//     return Future.value(false);
//   }
// }
