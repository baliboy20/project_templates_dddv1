

import 'dart:convert';

import '../models/journal_vo.dart';

class JsonJournalVoMapper {
  static   dynamic decodeJsonList( String jsonStr) {
    final json = jsonDecode(jsonStr);
    if (json is Map<String,dynamic>) {
      return JournalVo.fromJson(json);
    } else if(json is List) {
      return json.map((e)=> JournalVo.fromJson(e)).toList();
    } else
      throw Exception('Failed to decode json from string $json');
  }

  static String encodeJournalVo(dynamic vos) {
    if(vos is List<JournalVo>) {
      return jsonEncode(vos.map((e) => e.toJson()).toList());
    } else if(vos is JournalVo){
      return jsonEncode(vos.toJson());
    } else
      throw Exception('Failed to encode ValueObjectMappable $vos');
  }
}