// task_bloc.dart

import 'package:bloc/bloc.dart';

import '../../domain/entities/task.model.dart';
import '../../domain/repositories/task_repository.dart';
import 'task_events.dart';
import 'task_states.dart';

class TaskBloc extends Bloc<TaskEvent, TaskState> {
  final List<Task> _tasks = [];
  final TaskRepository repository;

  TaskBloc({required this.repository}) : super(Loading()) {
    on<LoadTasks>(_onLoadTasks);
    on<DeleteTask>(_onDeleteTask);
    on<SelectTask>(_onSelectTask);
    on<SaveChanges>(_onSaveChanges);
  }

  void _onLoadTasks(LoadTasks event, Emitter<TaskState> emit) async {
    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));
    final List<Task> _tasks = await repository.getAllTasks();
    emit(TasksLoaded(_tasks));
  }

  void _onDeleteTask(DeleteTask event, Emitter<TaskState> emit) async {
    try {
      await repository.deleteTaskById(event.id);
      final List<Task> _tasks = await repository.getAllTasks();
      emit(TasksLoaded(_tasks));
    } catch (e) {
      emit(TaskError('Fail: $e'));
    }
  }

  void _onSelectTask(SelectTask event, Emitter<TaskState> emit) {
    // final selectedTask = _tasks.firstWhere(
    //   (task) => task. == event.id,
    //   orElse: () => Task.empty(  ),
    // );
   // emit(TaskSelectedForChanging(selectedTask));
  }

  void _onSaveChanges(SaveChanges event, Emitter<TaskState> emit) async {
    emit(TaskSaving());
    try {
      await repository.updateTask(event.task);
      final List<Task> _tasks = await repository.getAllTasks();
      emit(TasksLoaded(_tasks));
    } catch (e) {
      emit(TaskError('Fail: $e'));
      await Future.delayed(Duration(milliseconds: 500));
      emit(TasksLoaded(_tasks));
    }
  }
}
