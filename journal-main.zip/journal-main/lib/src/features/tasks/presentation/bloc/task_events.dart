// task_events.dart
import '../../domain/entities/task.model.dart';

abstract class TaskEvent {}

class LoadTasks extends TaskEvent {}

class DeleteTask extends TaskEvent {
  final String id;
  DeleteTask(this.id);
}

class SelectTask extends TaskEvent {
  final String id;
  SelectTask(this.id);
}

class SaveChanges extends TaskEvent {
  final Task task;
  SaveChanges(this.task);
}
