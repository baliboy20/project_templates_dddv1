// task_states.dart
import '../../domain/entities/task.model.dart';

abstract class TaskState {}

class Loading extends TaskState {}

class TasksLoaded extends TaskState {
  final List<Task> tasks;
  TasksLoaded(this.tasks);
}

class TaskSelectedForChanging extends TaskState {
  final Task task;
  TaskSelectedForChanging(this.task);
}

class TaskSaving extends TaskState {}

class TaskError extends TaskState {
  final String message;
  TaskError(this.message);
}
