import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

main(){runApp(MrTab());}




class MrTab extends StatefulWidget {
  @override
  State<MrTab> createState() => _MrTabState();
}

class _MrTabState extends State<MrTab>  with SingleTickerProviderStateMixin {
 late TabController  _tabController;
  late ValueNotifier<List<int>> values;
@override
  void initState() {
    super.initState();
    values.addListener(() {
      print('values: ${values.value}');
    });
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {

      print('tab index: ${_tabController.index}');
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Tabs Demo'),

        ),
        body: Builder(
          builder: (context) {
            print('rebulding');
            return Column(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(


                   borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.black),
                  ),
                  alignment: Alignment.center,
                   constraints: BoxConstraints.loose(Size(400, 50)),
                  child: TabBar(
                    controller: _tabController,
                    tabs: [
                      Tab(

                       text: 'List',
                          icon: Icon(Icons.list_alt_outlined,size: 18)
                      ),
                      Tab(
                          text: 'Day',
                          icon: Icon(Icons.calendar_today,size: 18)),
                      Tab(icon: Icon(Icons.directions_bike,size: 18)),
                    ],
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      TabContent(title: "title 1",),
                      TabContent(title: "title 2",),
                      TabContent(title: "title 3",),


                    ],
                  ),
                ),
              ],
            );
          }
        ),
      ),
    );
  }
}




class TabContent extends StatefulWidget {
  String title;
    TabContent({super.key, required this.title});

  @override
  State<TabContent> createState() => _TabContentState();
}

class _TabContentState extends State<TabContent> {
  @override
  Widget build(BuildContext context) {
    print('rebuilding: ==> ${widget.title}');
    return  Text('${widget.title}');
  }
}


////===== BLOC =====
class TabBloc extends Bloc<TabEvent,TabState>{
  TabBloc() : super(TabState(0));

  }


class TabState extends Equatable {
  final int index;
  TabState(this.index);

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}

class TabEvent extends Equatable {
  final int index;
  TabEvent(this.index);

  @override
  // TODO: implement props
  List<Object?> get props => throw UnimplementedError();
}



