import 'dart:math';

main(){
  doit();
}


getsome() async*{
  for(int i = 0; i< 10; i++){
    await Future.delayed(Duration(seconds: 1));
    yield Random().nextInt(100);
  }


}


doit(){
  final stream = getsome();

  stream.listen((event) {
    print(event);
  });
}