import 'package:journal_macos/src/features/tasks/domain/entities/task.model.dart';

import 'extensions.dart';

mainnTasklet() {
  List<Tasklet> tasklets = [
    Tasklet(
      id: '1',
      action: 'Water the plants',
      from: DateTime.now(),
      completeBy: DateTime.now().add(Duration(days: 1)),
      status: ActionStatus.pending,
      completedOn: null,
      defer: true,
    ),
    Tasklet(
      id: '2',
      action: 'Prune the bushes',
      from: DateTime.now(),
      completeBy: DateTime.now().add(Duration(days: 2)),
      status: ActionStatus.inProgress,
      completedOn: null,
      defer: false,
    ),
    Tasklet(
      id: '3',
      action: 'Fertilize the garden',
      from: DateTime.now(),
      completeBy: DateTime.now().add(Duration(days: 3)),
      status: ActionStatus.pending,
      completedOn: null,
      defer: false,
    ),
    Tasklet(
      id: '4',
      action: 'Harvest vegetables',
      from: DateTime.now(),
      completeBy: DateTime.now().add(Duration(days: 4)),
      status: ActionStatus.completed,
      completedOn: DateTime.now(),
      defer: false,
    ),
  ];

  // Use the tasklets list for development


  // Convert the tasklets list to a list of maps
  List<Map<String, dynamic>> maps = Tasklet$.toMapList(tasklets);
  ();
  print(maps);

  // Convert the list of maps back to a list of tasklets
  List<Tasklet> b = Tasklet$.fromMapList(maps);
  print(b);

  final firstitem = Tasklet$.fromMap(maps[0]);
  print(firstitem);
  print(firstitem is Tasklet);
  final seconditem = firstitem.copyWith(
    id: "ssecond",
    completeBy: DateTime.now().add(Duration(days: 1)),
  );
  print(seconditem);
  print(seconditem is Tasklet);

  List<Map<String, dynamic>> mapList = Tasklet$.toMapList(tasklets);
  // print(mapList);
  List<Tasklet> taskletList = Tasklet$.fromMapList(mapList);
  print(' is List<Map> ${taskletList.runtimeType} ||');
  // print(taskletList);
}

main() {
  final list = createTestTasks();

  // 1. toMap()
  final map = list.map((task) => task.toMap()).toList();
  print(map);

  // 2. fromMap()
  final fromMap = map.map((map) => TaskMappers$.fromMap(map)).toList();
  print(fromMap);

  // 3. copyWith()
  final Task newTask = TaskMappers$(list[0]).copyWith(
    id: '1',
    description: 'Water the garden',
    from: DateTime.now(),
    to: DateTime.now().add(Duration(days: 1)),
    status: ActionStatus.pending,
    tasklets: [
      Tasklet(
        id: '1',
        action: 'Water the plants',
        from: DateTime.now(),
        completeBy: DateTime.now().add(Duration(days: 1)), status: ActionStatus.inProgress,
        completedOn: null,
        defer: true,
      ),
    ],
    priority: TaskPriority.high,
  );
  print(newTask);


}

List<Tasklet> createTestTasklets() {
  return createTestTasks().expand((a)=> a.tasklets).toList();
}
List<Task> createTestTasks() {
  return [
    Task(
      id: '1',
      description: 'Water the garden',
      from: DateTime.now(),
      to: DateTime.now().add(Duration(days: 1)),
      status: ActionStatus.pending,
      tasklets: [
        Tasklet(
          id: '1',
          action: 'Water the plants',
          from: DateTime.now(),
          completeBy: DateTime.now().add(Duration(days: 1)),
          status: ActionStatus.pending,
          completedOn: null,
          defer: true,
        ),
      ],
      priority: TaskPriority.high,
    ),
    Task(
      id: '2',
      description: 'Prune the bushes',
      from: DateTime.now(),
      to: DateTime.now().add(Duration(days: 2)),
      status: ActionStatus.inProgress,
      tasklets: [
        Tasklet(
          id: '2',
          action: 'Prune the bushes',
          from: DateTime.now(),
          completeBy: DateTime.now().add(Duration(days: 2)),
          status: ActionStatus.inProgress,
          completedOn: null,
          defer: false,
        ),
      ],
      priority: TaskPriority.normal,
    ),
    Task(
      id: '3',
      description: 'Fertilize the garden',
      from: DateTime.now(),
      to: DateTime.now().add(Duration(days: 3)),
      status: ActionStatus.pending,
      tasklets: [
        Tasklet(
          id: '3',
          action: 'Fertilize the garden',
          from: DateTime.now(),
          completeBy: DateTime.now().add(Duration(days: 3)),
          status: ActionStatus.pending,
          completedOn: null,
          defer: false,
        ),
      ],
      priority: TaskPriority.low,
    ),
    Task(
      id: '4',
      description: 'Harvest vegetables',
      from: DateTime.now(),
      to: DateTime.now().add(Duration(days: 4)),
      status: ActionStatus.completed,
      tasklets: [
        Tasklet(
          id: '4',
          action: 'Harvest vegetables',
          from: DateTime.now(),
          completeBy: DateTime.now().add(Duration(days: 4)),
          status: ActionStatus.completed,
          completedOn: DateTime.now(),
          defer: false,
        ),
      ],
      priority: TaskPriority.high,
    ),
  ];
}
