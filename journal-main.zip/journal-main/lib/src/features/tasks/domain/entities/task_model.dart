import 'package:flutter/foundation.dart';
import 'package:journal_macos/src/features/tasks/domain/entities/task.model.dart';

class TaskModel {
  final String id;
  final String description;
  final DateTime from;
  final DateTime to;
  final ActionStatus status;
  final TaskPriority priority;
  final List<Tasklet> tasklets;

  TaskModel({
    required this.id,
    required this.description,
    required this.from,
    required this.to,
    required this.status,
    required this.priority,
    required this.tasklets,
  });

  factory TaskModel.fromJson(Map<String, dynamic> json) {
    return TaskModel(
      id: json['id'],
      description: json['description'],
      from: DateTime.parse(json['from']),
      to: DateTime.parse(json['to']),
      status: ActionStatus.values.firstWhere((e) => describeEnum(e) == json['status']),
      priority: TaskPriority.values.firstWhere((e) => describeEnum(e) == json['priority']),
      tasklets: (json['tasklets'] as List<dynamic>)
          .map((e) => Tasklet.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'description': description,
      'from': from.toIso8601String(),
      'to': to.toIso8601String(),
      'status': describeEnum(status),
      'priority': describeEnum(priority),
      'tasklets': tasklets.map((t) => t.toJson()).toList(),
    };
  }
}
