import 'package:journal_macos/src/features/tasks/domain/entities/task.model.dart';

extension Tasklet$ on Tasklet {
  static Tasklet fromMap(Map<String, dynamic> map) {
    return Tasklet(
      id: map['id'],
      action: map['action'],
      from: map['from'],
      completeBy: map['completeBy'],
      status: map['status'],
      completedOn: map['completedOn'],
      defer: map['defer'] ?? false,
    );
  }

  static List<Tasklet> fromMapList(List<Map<String, dynamic>> mapList) {
    return mapList.map((map) => Tasklet$.fromMap(map)).toList();
  }

  static List<Map<String, dynamic>> toMapList(List<Tasklet> tasklets) {
    return tasklets.map((tasklet) => Tasklet$(tasklet).toMap()).toList();
  }

  copyWith({id, action, from, completeBy, status, completedOn, defer}) {
    return Tasklet(
        id: id ?? this.id,
        action: action ?? this.action,
        from: from ?? this.from,
        completeBy: completeBy ?? this.completeBy,
        status: status ?? this.status,
        completedOn: completedOn ?? this.completedOn,
        defer: defer ?? this.defer);
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'action': action,
      'from': from,
      'completeBy': completeBy,
      'status': status,
      'completedOn': completedOn,
      'defer': defer,
    };
  }

  empty() {}

}
extension TaskMappers$ on Task{
  // toMap()
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'description': description,
      'from': from,
      'to': to,
      'status': status,
      'tasklets': Tasklet$.toMapList(tasklets),
      'priority': priority,
    };
  }
  //fromMap()
  static fromMap(Map<String, dynamic> map) {
    return Task(
        id: map['id'] ?? '',
        description: map['description'] ?? '',
        from: map['from'] ?? null,
        to: map['to'] ?? null,
        status: map['status'] ?? '',
        tasklets: (map['tasklets'] as List)
            .map((item) => Tasklet$.fromMap(item))
            .toList(),
        priority: map['priority']);
  }

  //copyWith()
  copyWith( {id, description, from, to, status, tasklets, priority}){
    return Task(
      id: id ?? this.id ,
      description: description ?? this.description,
      from: from ?? this.from,
      to: to ?? this.to,
      status: status ?? this.status,
      tasklets: tasklets ?? this.tasklets,
      priority: priority ?? this.priority,
    );

  }
  //fromMapList()
  static List<Task> fromMapList(List<Map<String, dynamic>> mapList) {
    return mapList.map((map) => TaskMappers$.fromMap(map)).toList().cast<Task>();;
  }
//toMapList()
}