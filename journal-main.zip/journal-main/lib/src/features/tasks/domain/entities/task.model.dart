// task_entity.dart

import 'package:flutter/foundation.dart';
import 'package:journal_macos/src/core/app_config/app_config.dart';
import 'package:journal_macos/src/features/tasks/domain/entities/extensions.dart';
import 'package:journal_macos/src/features/tasks/domain/entities/task_model.dart';
import 'package:journal_macos/src/features/tasks/domain/entities/tasks_dev.tests.dart';
import 'package:parse_utils/core/app_configs/app_config.dart';

enum ActionStatus {
  pending,
  completed,
  inProgress;

  toJson() => name;

  static fromJson(String name) =>
      ActionStatus.values.firstWhere((element) => element.name == name);
}

enum TaskPriority { high, normal, low;

toJson() => name;
static fromJson(String name) => values.firstWhere((element) => element.name == name);
}

/// ActionModification enum to indicate the type of modification to be made to an
/// action item.
enum ActionModification { add, remove, update }

class Tasklet {
  final String id;
  final String action;
  final DateTime from;
  final DateTime? completeBy;
  late ActionStatus status;
  final DateTime? completedOn;
  final bool defer;
  final categories = <String>['will', 'do'];

  Tasklet({
    required this.id,
    required this.action,
    required this.from,
    required this.completeBy,
    required this.status,
    required this.completedOn,
    this.defer = false,
  });

  factory Tasklet.fromJson(Map<String, dynamic> json) {
    return Tasklet(
      id: json['id'],
      action: json['action'],
      from: DateTime.parse(json['from']),
      completeBy: DateTime.parse(json['completeBy']),
      status: ActionStatus.values.firstWhere((e) => e.name == json['status']),
      completedOn: json['completedOn'] != null ? DateTime.parse(json['completedOn']) : null,
    );
  }

  String completedByFormatted() {
    return completeBy != null
        ? '${completeBy!.day}-${completeBy!.month}-${completeBy!.year}'
        : '';
  }

  toString() {
    return '\n \t\t\tTasklet{id: $id, action: $action, from: $from, completeBy: $completeBy, status: $status, completedOn: $completedOn, defer: $defer}';
  }

  toJson() {
    return {
      'id': id,
      'action': action,
      'from': from?.toIso8601String() ?? '',
      'completeBy': completeBy?.toIso8601String() ?? '',
      'status': this.status.index,
      'completedOn': completedOn?.toIso8601String() ?? '',
      'defer': defer,
    };
  }

}

///
/// Task
///
class Task {
  final String id;
  final String description;
  final DateTime from;
  final DateTime to;
  final ActionStatus status;
  final List<Tasklet> tasklets;
  final TaskPriority priority;

  Task({
    required this.id,
    required this.description,
    required this.from,
    required this.to,
    required this.status,
    required this.tasklets,
    required this.priority,
  });
  Task.empty()
      : id = '',
        description = '',
        from = DateTime.now(),
        to = DateTime.now(),
        status = ActionStatus.pending,
        tasklets = [],
        priority = TaskPriority.normal;


  String toString() {
    return '\n <===>\nTask{id: $id, description: $description, from: $from, to: $to, status: $status, priority: $priority, \ntasklets: $tasklets}';
  }
}

/// An interface to be applied to enums that containe field info.
abstract interface class ModelSchema {
  Type getType(String fieldname);

  List<String> getFieldNames();

  List<String> getNullableFieldNames();

  List<String> getDateTimeStringFieldNames();

  Map<String, Object> getDefs();
}

typedef JsonMap = Map<String, dynamic>;

abstract class JsonSchemaCheck {
  List<String> exec(JsonMap jsonMap, String fld, String identifier);

  JsonSchemaCheck();
  factory JsonSchemaCheck.datetime(){
    return DateTimeValidator();
  }
  factory JsonSchemaCheck.string(){
    return StringValidator();
  }
  factory JsonSchemaCheck.bool(){
    return BoolValidator();
  }
  factory JsonSchemaCheck.unexpectedFields(ModelSchema schema){
    return UnexpectedFieldsValidator( schema);
  }
}




///
/// _ValidatorMixin
mixin class _ValidatorMixin {
  List<String> _fieldExists(
      JsonMap json, String fldname, String jsonIdentifier) {
    List<String> errs = [];

    if (!json.containsKey(fldname)) {
      final entityIdentifier = _getEntityIdentifier(json, jsonIdentifier);
      errs.add(_errorMessge(json, fldname, jsonIdentifier, "No field \'$fldname\' found"));
    }
    return errs;
  }

  /**/

  bool _isDateTimeString(dynamic value) {
    try {
      DateTime.parse(value);
    } on FormatException {
      return false;
    }
    return true;
  }

  /**/
  String _getEntityIdentifier(Map<String, dynamic> json, String identifier) {
    try {
      return json.containsKey(identifier)
          ? '$identifier:' + json[identifier].toString()
          : 'Unknown'; // Safely access and convert to string
    } catch (e) {
      return 'Unknown'; // Handle any errors during identifier retrieval.
    }
  }

  /**/
  String _errorMessge(json, fldname, jsonIdentifier, terseErrordesc) {
    final identiervalue = _getEntityIdentifier(json, jsonIdentifier);
    final failedvalue = "$fldname : ${json[fldname]}";
    return 'Schema failure where $failedvalue, $terseErrordesc, for object where $identiervalue: ';
  }
}
///
/// DateTimeValidator
///
final class DateTimeValidator extends JsonSchemaCheck
    with _ValidatorMixin{
  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final a = _fieldExists(value, fldname, jsonIdentifier);
    final fldvalue = value[fldname];
    if (a.isNotEmpty) {
      msg.addAll(a);
      return msg;
    } else {
      if (fldvalue is! String || !_isDateTimeString(fldvalue)) {
        msg.add(
          _errorMessge(value, fldname, jsonIdentifier, "not a valid DateTime string")
        );
      }
    }
    return msg;
  }
}

final class StringValidator
    with _ValidatorMixin
    implements JsonSchemaCheck {
  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final reterr = _fieldExists(value, fldname, jsonIdentifier);
    if (reterr.isNotEmpty) {
      msg.addAll(reterr);
      return msg;
    };
    if (value is! String)
      msg.add(
          _errorMessge(value, fldname, jsonIdentifier, "should be String type"));

    return msg;
  }
}

///
///
///
final class BoolValidator with _ValidatorMixin implements JsonSchemaCheck {
  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final reterr = _fieldExists(value, fldname, jsonIdentifier);
    if (reterr.isNotEmpty) msg.addAll(reterr);
    if (value is! bool)
      msg.add(
          'Entity: $jsonIdentifier not a bool: $fldname : ${value[fldname]}');

    return msg;
  }
}

///
///  UnexpectedFieldsValidator
///
final class UnexpectedFieldsValidator with _ValidatorMixin implements JsonSchemaCheck {
  final List<String>Fields;
  UnexpectedFieldsValidator( ModelSchema modelSchema) :  Fields = modelSchema.getFieldNames();
  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final reterr = _fieldExists(value, fldname, jsonIdentifier);
    if (reterr.isNotEmpty) msg.addAll(reterr);
    if (value is! bool)
      msg.add(
          'Entity: $jsonIdentifier not a bool: $fldname : ${value[fldname]}');
    return msg;
  }
}

///
///  ActionStatusValidator
///
final class ActionStatusValidator
    with _ValidatorMixin
    implements JsonSchemaCheck {
  bool _hasActionStatus(dynamic value) {
    try {
      ActionStatus.fromJson(value);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final reterr = _fieldExists(value, fldname, jsonIdentifier);
    if (reterr.isNotEmpty) msg.addAll(reterr);
    if (!_hasActionStatus(value[fldname])) {
      var errmsg = _errorMessge(value, fldname, jsonIdentifier, "invalid ActionStatus enum:");
      msg.add(errmsg);
    }

    return msg;
  }
}
///
///  ActionStatusValidator
///
final class TaskPriorityValidator
    with _ValidatorMixin
    implements JsonSchemaCheck {
  bool _hasActionStatus(dynamic value) {
    try {
      TaskPriority.fromJson(value);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
    final reterr = _fieldExists(value, fldname, jsonIdentifier);
    if (reterr.isNotEmpty) msg.addAll(reterr);
    if (!_hasActionStatus(value[fldname])) {
      var errmsg = _errorMessge(value, fldname, jsonIdentifier, "invalid ActionStatus enum:");
      msg.add(errmsg);
    }

    return msg;
  }
}
///
///  ActionStatusValidator
///
final class TaskletsValidator
    with _ValidatorMixin
    implements JsonSchemaCheck {
  bool _hasActionStatus(dynamic value) {
    try {
      ActionStatus.fromJson(value);
      return true;
    } catch (e) {
      return false;
    }
  }

  @override
  exec(value, fldname, jsonIdentifier) {
    final List<String> msg = [];
   // is List<Tasklet>
    if(value['tasklets'] is! List){
      msg.add('tasklets is not a List<Tasklet>');
      return msg;
    }

    final v3 = SchemaCheckerManager(schema: TaskletSchema(), jsonList:value['tasklets'], takeEvery: TakeEvery.every);
    final List<String> erros = v3.call();
     msg.addAll(erros);
     return msg;
  }
}

// final class CategoryValidator extends JsonChecker{
//
// }
// final class BoolValidator extends JsonChecker{}

// final class ActionStatusValidator extends JsonChecker{
//   call(MapEntry<String, dynamic> value, [String results = "ss"]) {}
// }

class TaskletSchema implements ModelSchema {
  final Map<String, Object> defs = {
    'id': JsonSchemaCheck.string(),
    'idx': JsonSchemaCheck.string(),
    'from': JsonSchemaCheck.datetime(),
    'completeBy': JsonSchemaCheck.datetime(),
    'status': ActionStatusValidator(),
    'completedOn': JsonSchemaCheck.datetime(),
    'defer': JsonSchemaCheck.bool(),
    'action': JsonSchemaCheck.string(),
  };

  @override
  List<String> getFieldNames() {
    return defs.keys.toList();
  }

  @override
  Map<String, Object> getDefs() => defs;

  @override
  Type getType(String fieldname) {
    if (defs.containsKey(fieldname))
      return defs[fieldname] as Type;
    else
      throw Exception('Field $fieldname not found in schema');
  }

  @override
  List<String> getDateTimeStringFieldNames() =>
      ["from", "completeBy", "completedOn"];

  @override
  List<String> getNullableFieldNames() => ["from", "completeBy", "completedOn"];
}


class TaskSchema implements ModelSchema {

  // final String id;
  // final String description;
  // final DateTime from;
  // final DateTime to;
  // final ActionStatus status;
  // final List<Tasklet> tasklets;
  // final TaskPriority priority;
  final Map<String, Object> defs = {
    'id': JsonSchemaCheck.string(),
    'description': JsonSchemaCheck.string(),
    'from': JsonSchemaCheck.datetime(),
    'to': JsonSchemaCheck.datetime(),
    'status': ActionStatusValidator(),
    'tasklets': TaskletsValidator(),
    'priority': TaskPriorityValidator(),
  };

  @override
  List<String> getFieldNames() {
    return defs.keys.toList();
  }

  @override
  Map<String, Object> getDefs() => defs;

  @override
  Type getType(String fieldname) {
    if (defs.containsKey(fieldname))
      return defs[fieldname] as Type;
    else
      throw Exception('Field $fieldname not found in schema');
  }

  @override
  List<String> getDateTimeStringFieldNames() =>
      ["from", "completeBy", "completedOn"];

  @override
  List<String> getNullableFieldNames() => ["from", "completeBy", "completedOn"];
}




///
//// Tasklet Validator
///
//
enum TakeEvery {every, first, all,tenth}


class SchemaCheckerManager {
  final ModelSchema schema;
  late List<String> _errMsg = [];
  final TakeEvery takeEvery;
  final JSONList jsonList;

  JSONList getFiltered(JSONList jsonList) {
    JSONList filtered;
    if (takeEvery == TakeEvery.every) {
      filtered = jsonList;
    } else if (takeEvery == TakeEvery.first) {
      filtered = [jsonList.first];
    } else if (takeEvery == TakeEvery.tenth) {
      final Map a = jsonList.asMap();
      filtered = a.entries
          .where((entry) => entry.key % 10 == 0)
          .map((entry) => entry.value)
          .toList().cast();
    } else filtered = [];

    return filtered;
  }



  SchemaCheckerManager({required this.schema, required this.takeEvery, required this.jsonList});
  call(){
    _errMsg = [];
    for(var json in getFiltered(jsonList)){
    var list;  _execute(json);
      _errMsg.addAll(list ??[]);
    }
    return _errMsg;
  }

  _execute(JsonMap jsonMap) {
    for (var entry in schema.getDefs().entries) {
      String fldname = entry.key;
      JsonSchemaCheck checker = entry.value as JsonSchemaCheck;
      final List<String> result = checker.exec(jsonMap, fldname, "id");
      _errMsg.addAll(result);
    }
    return _errMsg;
  }
}

// class V2 {
//   final ModelSchema schema;
//   late List<String> _errMsg = [];
//   final String identifier;
//
//   V2({required this.schema, this.identifier = ''});
//
//   void reset() => _errMsg = [];
//
//   validate(MapEntry json) {
//     for (var entry in schema.getDefs().entries) {}
//   }
//
//   V2 mustHaveFields(dynamic json) {
//     for (var field in schema.getFieldNames()) {
//       if (!json.containsKey(field)) {
//         final entityIdentifier = _getEntityIdentifier(json);
//         _errMsg.add('Entity: $entityIdentifier missing required field: $field');
//       }
//     }
//     return this;
//   }
//
//   V2 unexpectedFields(dynamic json) {
//     for (var field in json.keys) {
//       if (!schema.getFieldNames().contains(field)) {
//         final entityIdentifier = _getEntityIdentifier(json);
//         _errMsg.add('Entity: $entityIdentifier has unexpected field: $field');
//       }
//     }
//     return this;
//   }
//
//   V2 correctTypes(dynamic json) {
//     for (var entry in schema.getDefs().entries) {
//       String fld = entry.key;
//       dynamic value = json[fld];
//       Type expectedType = entry.value;
//
//       if (value == null && !schema.getNullableFieldNames().contains(fld)) {
//         final entityIdentifier = _getEntityIdentifier(json);
//         _errMsg.add(
//             'Entity: $entityIdentifier field \'$fld\' cannot be null.  Expected type: $expectedType');
//       } else if (schema.getDateTimeStringFieldNames().contains(fld)) {
//         if (value is String) {
//           if (!isDateTimeString(value)) {
//             final entityIdentifier = _getEntityIdentifier(json);
//             _errMsg.add(
//                 'Entity: $entityIdentifier field \'$fld\' is not a valid DateTime string. The value is \'$value\'  ');
//           }
//         }
//       } else if (value != null &&
//           value.runtimeType != expectedType &&
//           schema.getDateTimeStringFieldNames().contains(fld) == false) {
//         final entityIdentifier = _getEntityIdentifier(json);
//         _errMsg.add(
//             'descriptor: ==>$entityIdentifier field \'$fld\' has incorrect type. Expected: $expectedType, Actual: ${value.runtimeType}');
//       }
//     }
//     return this;
//   }
//
//   List<String> values() => _errMsg;
//
//   /// Validates if a value can be a DateTime
//   bool isDateTimeString(dynamic value) {
//     try {
//       DateTime.parse(value);
//     } on FormatException {
//       return false;
//     }
//     return true;
//   }
//
//   /// Helper function to safely get the entity identifier.
//   String _getEntityIdentifier(dynamic json) {
//     try {
//       return json[identifier]?.toString() ??
//           'Unknown'; // Safely access and convert to string
//     } catch (e) {
//       return 'Unknown'; // Handle any errors during identifier retrieval.
//     }
//   }
// }
//
//
extension on List {
  toPrettyString() {
    var res = this.join("\n - ");
    return res;
  }
}

main() {
  final JSONList tasklets = createTestTasklets().map<Map<String, dynamic>>((e) => e.toJson()).toList();



  final v3 = SchemaCheckerManager(schema: TaskletSchema(), jsonList: tasklets, takeEvery: TakeEvery.tenth);
  final List erros = v3.call();
  print(erros.toPrettyString());

  return;
  // final a = vak.expectedFields(tasklet.toJson());

  // final result = V2(schema: TaskletSchema(), identifier: 'id')
  //     .mustHaveFields(json)
  //     .unexpectedFields(json)
  //     .correctTypes(json);
  // result.values().forEach(printz);
  // print(json);
}
