// task_interface.dart

import '../entities/task.model.dart';


abstract class TaskRepository {
  Future<List<Task>> getAllTasks();
  Future<Task> findTaskById(String id);
  Future<Task> createTask(Task task);
  Future<bool> updateTask(Task task);
  Future<bool> deleteTaskById(String id);
  Future<List<Task>> filterTasks(Map<String, dynamic> criteria);
}
