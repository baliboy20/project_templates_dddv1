
import 'package:flutter/material.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final List<DropdownItem> items = [
    DropdownItem(name: 'Item 1', id: 1),
    DropdownItem(name: 'Item 2', id: 2),
    DropdownItem(name: 'Item 3', id: 3),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: const Text('Custom Dropdown')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              CustomDropdownButton<DropdownItem>(
                items: items,
                initialValue: items[0],
                onChanged: (item) {
                  // Handle selected item
                  print('Selected item: ${item?.name}, ID: ${item?.id}');
                },
                hintText: 'Select an item', // Hint Text here!
                itemBuilder: (item) => Text(item.name),
              ),

              Text('Another Dropdown'),
              Text('Another Dropdown2'),
              Text('Another Dropdown3'),
              Text('Another Dropdownr'),
              Text('Another Dropdown6'),
            ],
          ),
        ),
      ),
    );
  }
}




class DropdownItem {
  final String name;
  final int id;

  DropdownItem({required this.name, required this.id});
}




class CustomDropdownButton<T> extends StatefulWidget {
  final List<T> items;
  final ValueChanged<T?>? onChanged;
  final String? hintText; // Add a hint text
  final T? initialValue;
  final Function(T)? itemBuilder; // Pass itemBuilder from parent

  const CustomDropdownButton({
    Key? key,
    required this.items,
    this.onChanged,
    this.hintText,
    this.initialValue,
    required this.itemBuilder, // Add this required param
  }) : super(key: key);

  @override
  State<CustomDropdownButton<T>> createState() => _CustomDropdownButtonState<T>();
}

class _CustomDropdownButtonState<T> extends State<CustomDropdownButton<T>> {
  bool _isOpen = false;
  T? _selectedValue;

  @override
  void initState() {
    super.initState();
    _selectedValue = widget.initialValue;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () {
            setState(() {
              _isOpen = !_isOpen;
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // show Hint Text If _selectedValue is null
                _selectedValue == null
                    ? Text(widget.hintText ?? "Select an item", style: TextStyle(color: Colors.grey))
                    : widget.itemBuilder!(_selectedValue!), // Call itemBuilder here to customize selected item display
                Icon(_isOpen ? Icons.arrow_drop_up : Icons.arrow_drop_down),
              ],
            ),
          ),
        ),
        if (_isOpen)
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: widget.items.length,
              itemBuilder: (context, index) {
                final item = widget.items[index];
                return ListTile(
                  onTap: () {
                    setState(() {
                      _selectedValue = item;
                      _isOpen = false;
                      widget.onChanged?.call(item);
                    });
                  },
                  title: widget.itemBuilder!(item), // Call itemBuilder again for items list
                );
              },
            ),
          ),
      ],
    );
  }
}



