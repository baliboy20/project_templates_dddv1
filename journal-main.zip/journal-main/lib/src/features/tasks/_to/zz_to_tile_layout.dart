import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(primarySwatch: Colors.blue).copyWith(
        expansionTileTheme: ExpansionTileThemeData(
          iconColor: Colors.red,
          textColor: Colors.red,
          shape:  RoundedRectangleBorder(
          borderRadius: BorderRadius.zero, // No border in collapsed state
        ),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('Rich text tappable Example')),
        body: CollapsibleList(),
      ),
    );
  }
}

class CollapsibleList extends StatefulWidget {
  @override
  State<CollapsibleList> createState() => _CollapsibleListState();
}

class _CollapsibleListState extends State<CollapsibleList> {
  late final TapGestureRecognizer _tapGestureRecognizer;

  @override
  void initState() {
    // TODO: implement initState
    _tapGestureRecognizer = TapGestureRecognizer()..onTap = () => print('tapped');

  }
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        margin: EdgeInsets.all(180),
        width: double.infinity,
        height: 300,
        color: Colors.blue.shade50,
        child: RichText(text: TextSpan(
             recognizer: _tapGestureRecognizer,
            text:"love to dance")),
      ),
    );

  }
}
