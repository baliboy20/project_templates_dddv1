import 'package:flutter/material.dart';


void main() {
  runApp(const MaterialApp(home: CustomDropdownDemo()));
}

class CustomDropdownDemo extends StatelessWidget {
  const CustomDropdownDemo({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Custom Dropdown with Overflow")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: CustomDropdown(
          items: ["Option 1", "Option 2", "Option 3", "Option 4"],
        ),
      ),
    );
  }
}



class CustomDropdown extends StatefulWidget {
  final List<String> items;

  const CustomDropdown({Key? key, required this.items}) : super(key: key);

  @override
  _CustomDropdownState createState() => _CustomDropdownState();
}

class _CustomDropdownState extends State<CustomDropdown> {
  final GlobalKey _key = GlobalKey();
  OverlayEntry? _dropdownOverlayEntry;
  bool _isDropdownOpen = false;
  String _selectedItem = '';

  void _toggleDropdown() {
    if (_isDropdownOpen) {
      _closeDropdown();
    } else {
      _openDropdown();
    }
  }

  void _openDropdown() {
    final RenderBox renderBox = _key.currentContext!.findRenderObject() as RenderBox;
    final Offset offset = renderBox.localToGlobal(Offset.zero);
    final Size size = renderBox.size;

    _dropdownOverlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        left: offset.dx,
        top: offset.dy + size.height,
        width: size.width,
        child: Material(
          elevation: 4.0,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(4),
            ),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: widget.items.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(widget.items[index]),
                  onTap: () => _selectItem(widget.items[index]),
                );
              },
            ),
          ),
        ),
      ),
    );

    Overlay.of(context).insert(_dropdownOverlayEntry!);
    setState(() {
      _isDropdownOpen = true;
    });
  }

  void _closeDropdown() {
    _dropdownOverlayEntry?.remove();
    _dropdownOverlayEntry = null;
    setState(() {
      _isDropdownOpen = false;
    });
  }

  void _selectItem(String item) {
    setState(() {
      _selectedItem = item;
      _isDropdownOpen = false;
    });
    _closeDropdown();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      key: _key,
      children: [
        Expanded(
          child: TextField(
            readOnly: true,
            controller: TextEditingController(text: _selectedItem),
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
        ),
        IconButton(
          icon: Icon(_isDropdownOpen ? Icons.arrow_drop_up : Icons.arrow_drop_down),
          onPressed: _toggleDropdown,
        ),
      ],
    );
  }
}
