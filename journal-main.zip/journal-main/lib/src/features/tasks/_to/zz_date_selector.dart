import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blank Flutter App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Blank Flutter App'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [

              DateBox(),
              SizedBox(height: 20),
              DropdownMenu(
               // leadingIcon: Icon(Icons.calendar_today, size: 13,),
                  trailingIcon: Icon(Icons.calendar_month, size: 13,),


                  dropdownMenuEntries:
              <DropdownMenuEntry<String>>[
                DropdownMenuEntry(value: 'item1', label: 'Item 1',leadingIcon: Icon(Icons.calendar_today, size: 13,)),
                DropdownMenuEntry(value: 'item1', label: '',labelWidget: Divider(color: Colors.black54, height: 1, thickness: 1,)),
                DropdownMenuEntry(value: 'item2', label: 'Today', labelWidget: Text('Item 2', style: TextStyle(fontSize: 12, color: Colors.black54),)),
                DropdownMenuEntry(value: 'item3', label: 'Item 3', style: ButtonStyle(backgroundColor: MaterialStateProperty.all(Colors.red))),
              ]

              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DateBox extends StatefulWidget {
  DateBox({super.key});

  @override
  State<DateBox> createState() => _DateBoxState();
}

class _DateBoxState extends State<DateBox> {
  late dynamic date = {"dateformat": '12-12-2021'};
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: "333")
      ..addListener(() {
        print('value: ${_controller.text}');
        if (_controller.text.length > 4) {
          print('Date is complete');
          _controller.text = _controller.text.substring(0, 2);
          setState(() {});
        }
      });
  }

  @override
  dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 45,
      width: 160,
      child: TextField(
        maxLines: 1,
        controller: _controller,
        decoration: InputDecoration(
          filled: true,
          prefix: IconButton(
              onPressed: () {
                print('Select date dropdown');
              },
              icon: Icon(
                Icons.date_range,
                size: 14,
                color: Colors.black54,
              )),
          suffixIcon: IconButton(

            splashColor: Colors.red,
            splashRadius: 0.1,
            hoverColor: Colors.transparent,
            icon: Icon(
              Icons.close,
              size: 14,
            ),
            onPressed: () {
              print('Clear date');
            },
            color: Colors.black54,
            mouseCursor: SystemMouseCursors.click,
            padding: EdgeInsets.zero,
            alignment: Alignment.center,
          ),
          hintText: '12-12-2021',
          contentPadding: EdgeInsets.symmetric(vertical: 0),
          border: InputBorder.none,
          // border: OutlineInputBorder(
          //     borderRadius: BorderRadius.circular(5),
          //     borderSide: BorderSide(color: Colors.black12, width: 1))
        ),
        style: TextStyle(
          fontFamily: 'SF Pro Text',
          fontSize: 12,
          fontWeight: FontWeight.w400,
          color: Colors.black87,
        ),
      ),
    );
  }
}
