
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Barebones App'),
        ),
        body: const Center(
          child: Padding(
            padding: EdgeInsets.all(28.0),
            child: TextIt(),
          ),
        ),
      ),
    );
  }
}


class TextIt extends StatefulWidget {
  const TextIt({super.key});

  @override
  State<TextIt> createState() => _TextItState();
}

class _TextItState extends State<TextIt> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
      child:  RichText(
        text: TextSpan(
          text: AboutLondon,
          style: TextStyle(
            fontSize: 20,
            color: Colors.black,
          ),
        ),
      ),
    );
  }
}

const String AboutLondon = 'London is the capital of England and the United Kingdom.'
    'It is the most populous city in the United Kingdom, with a metropolitan area of over 13 million inhabitants.'
    'Standing on the River Thames, London has been a major settlement for two millennia, its history going back to its founding by the Romans, who named it Londinium.'
    'London is a leading global city in the arts, commerce, education, entertainment, fashion, finance, healthcare, media, professional services, research and development, tourism, and transportation.'
    'It is the world\'s largest financial centre and has the fifth- or sixth-largest metropolitan area GDP in the world.'
    'London is often regarded as a world cultural capital. It is the world\'s most-visited city as measured by international arrivals and has the world\'s largest city airport system measured by passenger traffic.';
