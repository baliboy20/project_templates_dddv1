// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:intl/intl.dart';
//
// void main() {
//   runApp(MyApp());
// }
//
// class MyApp extends StatefulWidget {
//   @override
//   _MyAppState createState() => _MyAppState();
// }
//
// class _MyAppState extends State<MyApp> {
//   late DateInputController _dateInputController;
//   ValueNotifier<String> _dateNotifier = ValueNotifier<String>('hello');
//
//   @override
//   void initState() {
//     super.initState();
//     _dateInputController = DateInputController(dateChanged: dateChanged);
//   }
//
//   @override
//   void dispose() {
//     _dateInputController.dispose();
//     super.dispose();
//   }
//
//   // Called when a valid date is detected
//   void dateChanged(String formattedDate) {
//     print("Date Changed: $formattedDate");
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: Scaffold(
//         appBar: AppBar(title: Text("Date Input Handler")),
//         body: Column(
//           children: [
//             Center(
//               child: Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: TextField(
//                   inputFormatters: [
//                     DateTextInputFormatter(),
//                     LengthLimitingTextInputFormatter(10),
//                   ],
//                   controller: _dateInputController,
//                   decoration: InputDecoration(
//                     labelText: "Enter date",
//                     border: OutlineInputBorder(),
//                   ),
//                 ),
//               ),
//             ),
//             ValueListenableBuilder<String>(
//               valueListenable: _dateNotifier,
//               builder: (context, value, child) {
//                 return Text("Date: $value");
//               },
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
//
// class DateInputController extends TextEditingController {
//   final void Function(String) dateChanged;
//
//   DateInputController({required this.dateChanged}) : super() {
//     this.addListener(_onTextChanged);
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//   }
//
//   @override
//   void addListener(void Function() listener) {
//     super.addListener(listener);
//   }
//
//   void _onTextChanged() {
//     print("Text changed: ${this.text}");
//   }
// }
//
// class DateTextInputFormatter extends TextInputFormatter {
//   DateTextInputFormatter() : super() {
//     print("DateTextInputFormatter created");
//   }
//
//   @override
//   TextEditingValue formatEditUpdate(
//     TextEditingValue oldValue,
//     TextEditingValue newValue,
//   ) {
//     bool isvalid = true;
//     String newText = newValue.text;
//     String formattedText = newText.trim();
//     int caretPosition = newValue.selection.end;
//
//     // Remove non-digit characters except '/'
//     //newText = _removeInvalidChars(newText);
//
//     if (newValue.text.length < oldValue.text.length) {
//       return TextEditingValue(
//         text: newText,
//         selection: TextSelection.collapsed(offset: newText.length),
//       );
//     }
//
//     // Insert '/' at the correct positions (after 2nd and 5th character)
//
//     if (newText.length == 1) if (RegExp(r'^[0123]$').hasMatch(newText)) {
//       isvalid = true;
//     } else
//       isvalid = false;
//
//     if (newText.length == 2) if (RegExp(r'^(3[10]|[12][0-9]|0[1-9])$')
//         .hasMatch(newText)) {
//       isvalid = isValidDayInt(int.parse(newText), null, null);
//       formattedText = newText.substring(0, 2) + '/';
//     } else
//       isvalid = false;
//
//     if (newText.length == 5) if (RegExp(
//             r'^(0[1-9]|[12]\d|3[01])\/(0[1-9]|1[0-2])$')
//         .hasMatch(newText)) {
//       final vals = newText.split("/").map((e) => int.parse(e)).toList();
//       isvalid = isValidDayInt(vals[0], vals[1], null);
//       formattedText = newText.substring(0, 5) + '/';
//     } else
//       isvalid = false;
//
//     final retStr = isvalid ? formattedText : oldValue.text;
//     return TextEditingValue(
//       text: retStr,
//       selection: TextSelection.collapsed(offset: retStr.length),
//     );
//   }
//
//   String _removeInvalidChars(String newText) {
//     return newText.replaceAll(RegExp(r'[^0-9/]'), '');
//   }
//
//   bool isValidDayInt(int day, int? month, int? year) {
//     if (month == null) {
//       return day > 0 && day < 32;
//     }
//
//     if (month != null && year == null) {
//       final dim = month.getDaysInMonth(month);
//
//       if (day != null) {
//         return day > 0 && day <= dim;
//       }
//       return false;
//     }
//     if (month != null && year != null) {
//       if (month == 2) {
//         if (year.isLeapYear()) {
//           return day != null && day < 30;
//         }
//         return day != null && day < 29;
//       }
//       return day != null && day < 31;
//     }
//     throw UnimplementedError('isValidDayInt() "unexpected condition"');
//   }
// }
//
// extension on int {
//   bool validMonthNo() {
//     return this > 0 && this < 13;
//   }
//
//   int getDaysInMonth(int month) {
//     const List<int> daysInMonth = [
//       31,
//       28,
//       31,
//       30,
//       31,
//       30,
//       31,
//       31,
//       30,
//       31,
//       30,
//       31
//     ];
//     return daysInMonth[month - 1];
//   }
//
//   bool isLeapYear() {
//     if (this % 4 != 0) return false; // Not divisible by 4
//
//     if (this % 100 == 0)
//       return this % 400 ==
//           0; // Divisible by 100, check if also divisible by 400
//     else
//       return true; // Divisible by 4, and not a century year that's not divisible by 400
//   }
// }
