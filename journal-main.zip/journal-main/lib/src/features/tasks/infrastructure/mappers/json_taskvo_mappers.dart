

import 'dart:convert';

import '../models/task_vo.dart';
 
/// __Mapper for TaskVo conversions.__
/// __It  converts TaskVo to and from json.__
class TaskVoMapper {
  static   dynamic decodeJsonList( String jsonStr) {
    final json = jsonDecode(jsonStr);
    if (json is Map<String,dynamic>) {
      return TaskVo.fromJson(json);

    } else if(json is List) {
      return json.map((e)=> TaskVoMapper.fromJson(e)).toList();
    } else
      throw Exception('Failed to decode json from string $json');
  }

  static String encodeTaskVo(dynamic vos) {
    if(vos is List<TaskVo>) {
      return jsonEncode(vos.map((e) => TaskVoMapper.toJson(e)).toList());
    } else if(vos is TaskVo){
      return jsonEncode(vos.toJson());
    } else
      throw Exception('Failed to encode ValueObjectMappable $vos');
  }

  /// It converts a json map to TaskVo.
  static TaskVo fromJson( Map<String,dynamic> map) {
    return TaskVo(
      id: map['_id'] as String,
      title: map['title'] as String,
      description: map['description'] as String?,
      dueDate: map['dueDate'] != null ? DateTime.parse(map['dueDate'] as String) : null,
      priority: map['priority'] as int,
      isCompleted: map['isCompleted'] as bool,
      userId: map['userId'] as String,
      projectId: map['projectId'] as String?,
      category: map['category'] as String? ?? 'General',
    );

  }

  /// __It converts TaskVo to json map.__
  static toJson(TaskVo vo) {
    return {
      'id': vo.id,
      'title': vo.title,
      'description': vo.description,
      'dueDate': vo.dueDate?.toIso8601String(),
      'priority': vo.priority,
      'isCompleted': vo.isCompleted,
      'userId': vo.userId,
      'projectId': vo.projectId,
      'category': vo.category,
    };
  }
}