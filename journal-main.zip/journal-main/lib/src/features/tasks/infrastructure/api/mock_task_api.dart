// import 'dart:convert';
// import 'package:journal_macos/src/features/tasks/infrastructure/api/task_api.dart';
//
// import '../models/task_vo.dart';
//
// class MockTaskApi implements TaskApi {
//   final List<TaskVo> _mockTasks = List.generate(
//     20,
//         (index) => TaskVo(
//       id: 'task_$index',
//       title: 'Test Task $index',
//       description: 'Description for Task $index', userId: '',
//       // Add other fields as required by your TaskVo model
//     ),
//   );
//
//   // Test connection by saying hello
//   Future<bool> sayHello() async {
//     return Future.value(true); // Simulate a successful response
//   }
//
//   // Fetch all tasks
//   Future<List<TaskVo>> getAllTasks() async {
//     return Future.value(_mockTasks);
//   }
//
//   // Find tasks by title
//   Future<List<TaskVo>> findTasksByTitle(String title) async {
//     return Future.value(
//       _mockTasks.where((task) => task.title.contains(title)).toList(),
//     );
//   }
//
//   // Create a new task
//   Future<TaskVo> createTask(TaskVo task) async {
//     _mockTasks.add(task); // Simulate adding a task
//     return Future.value(task);
//   }
//
//   // Update an existing task
//   Future<bool> updateTask(TaskVo task) async {
//     final index = _mockTasks.indexWhere((t) => t.id == task.id);
//     if (index != -1) {
//       _mockTasks[index] = task; // Simulate updating a task
//       return Future.value(true);
//     }
//     return Future.value(false);
//   }
//
//   // Delete a task by ID
//   Future<bool> deleteTaskById(String id) async {
//     final index = _mockTasks.indexWhere((task) => task.id == id);
//     if (index != -1) {
//       _mockTasks.removeAt(index); // Simulate deleting a task
//       return Future.value(true);
//     }
//     return Future.value(false);
//   }
//
//   // Filter tasks based on criteria
//   Future<List<TaskVo>> filterTasks(Map<String, dynamic> criteria) async {
//     // For simplicity, assume criteria are based on title
//     if (criteria.containsKey('title')) {
//       String titleCriteria = criteria['title'];
//       return Future.value(
//         _mockTasks.where((task) => task.title.contains(titleCriteria)).toList(),
//       );
//     }
//     return Future.value(_mockTasks); // Return all if no criteria
//   }
//
//   Future<TaskVo> findTaskById(String id) async {
//     final task = _mockTasks.firstWhere((task) => task.id == id);
//     if (task != null) {
//       return Future.value(task);
//     } else {
//       throw Exception('Task not found');
//     }
//   }
//
//   @override
//   // TODO: implement baseUrl
//   String get baseUrl => throw UnimplementedError();
//
//   @override
//   Future<TaskVo> createItem(TaskVo item) {
//     // TODO: implement createItem
//     throw UnimplementedError();
//   }
//
//   @override
//   Future<bool> deleteItemById(String id) {
//     // TODO: implement deleteItemById
//     throw UnimplementedError();
//   }
//
//   @override
//   Future<List<TaskVo>> filterItems(Map<String, dynamic> criteria) {
//     // TODO: implement filterItems
//     throw UnimplementedError();
//   }
//
//   @override
//   Future<TaskVo> findItemById(String id) {
//     // TODO: implement findItemById
//     throw UnimplementedError();
//   }
//
//   @override
//   Future<List<TaskVo>> findItemsByTitle(String title) {
//     // TODO: implement findItemsByTitle
//     throw UnimplementedError();
//   }
//
//   @override
//   // TODO: implement fromJsonFactory
//   Function(String p1) get fromJsonFactory => throw UnimplementedError();
//
//   @override
//   Future<List<TaskVo>> getAllItems() {
//     // TODO: implement getAllItems
//     throw UnimplementedError();
//   }
//
//   @override
//   // TODO: implement toJsonFactory
//   String Function(dynamic p1) get toJsonFactory => throw UnimplementedError();
//
//   @override
//   Future<TaskVo> updateItem(TaskVo item) {
//     // TODO: implement updateItem
//     throw UnimplementedError();
//   }
// }
