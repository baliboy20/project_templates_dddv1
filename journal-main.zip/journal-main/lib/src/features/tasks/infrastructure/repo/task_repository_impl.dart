// task_repository_impl.dar
import 'package:journal_macos/src/core/app_config/app_config.dart';
import 'package:journal_macos/src/features/tasks/infrastructure/mappers/json_taskvo_mappers.dart';

import '../../../../../generic_crud/repository/http_crud_api.dart';
import '../../domain/repositories/task_repository.dart';

import '../models/task_vo.dart';
import '../../domain/entities/task.model.dart' as ent;


class TaskRepositoryImpl implements TaskRepository {
  final ICrudHttpApi<TaskVo> api;


  TaskRepositoryImpl(this.api);

  @override
  Future<List<ent.Task>> getAllTasks() async {
    final List<TaskVo> taskVos = await api.getAllItems(); // This still returns a List of TaskVo
    // Convert TaskVo to  Task if necessary
    throw UnimplementedError();

  }

  @override
  Future<ent. Task> findTaskById(String id) async {
    final taskVo = await api.findItemById(id);
    throw UnimplementedError();
  }

  @override
  Future<ent. Task> createTask(ent. Task task) async {
    throw UnimplementedError();
   // final taskVo = task.toVo(); // Assuming a toVo method to convert  Task to TaskVo
   // final createdTaskVo = await api.createItem(taskVo); // This still returns a TaskVo
    // return ent. Task.fromVo(createdTaskVo); // Convert to  Task
  }

  // @override
  // Future<bool> updateTask(ent. Task task) async {
  //   throw UnimplementedError();
  //   // final taskVo = task.toVo(); // Convert to TaskVo
  //   // final result = await api.updateItem(taskVo); // This returns a boolean
  //   // return result != null;
  // }

  @override
  Future<bool> deleteTaskById(String id) async {
    final result = await api.deleteItemById(id); // This returns a boolean
    return result;
  }

  @override
  Future<List<ent. Task>> filterTasks(Map<String, dynamic> criteria) async {
    final taskVos = await api.filterItems(criteria); // This returns a List of TaskVo
    // Convert TaskVo to  Task
    // return taskVos.map((taskVo) => ent. Task.fromVo(taskVo)).toList();
    throw UnimplementedError();
  }

  @override
  Future<bool> updateTask(ent.Task task) {
    // TODO: implement updateTask
    throw UnimplementedError();
  }
}
