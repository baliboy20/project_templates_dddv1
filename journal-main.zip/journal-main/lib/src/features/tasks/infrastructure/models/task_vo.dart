import 'dart:convert';


class TaskVo  {
  final String id;
  final String title;
  final String? description;
  final DateTime? dueDate;
  final int priority; // 1 for high, 2 for medium, 3 for low
  bool isCompleted;
  final String userId; // ID of the user assigned to the task
  final String? projectId; // ID of the associated project (optional)
  final String category; // Category of the task, e.g., "Work", "Personal"

  TaskVo({
    required this.id,
    required this.title,
    this.description,
    this.dueDate,
    this.priority = 3, // Default priority is low
    this.isCompleted = false,
    required this.userId,
    this.projectId,
    this.category = 'General', // Default category is "General"
  });

  // Factory constructor for creating a TaskVo from JSON
  factory TaskVo.fromJson(Map<String, dynamic> json) {

    return TaskVo(
      id: json['_id'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      dueDate: json['dueDate'] != null ? DateTime.parse(json['dueDate'] as String) : null,
      priority: json['priority'] as int,
      isCompleted: json['isCompleted'] as bool,
      userId: json['userId'] as String,
      projectId: json['projectId'] as String?,
      category: json['category'] as String? ?? 'General',
    );
  }

  // Method for converting a TaskVo to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'dueDate': dueDate?.toIso8601String(),
      'priority': priority,
      'isCompleted': isCompleted,
      'userId': userId,
      'projectId': projectId,
      'category': category,
    };
  }

  // Optional: Method for toggling the completion status
  void toggleCompletion() {
    isCompleted = !isCompleted;
  }

  @override
  TaskVo fromJson(Map<String, dynamic> item) {
    // TODO: implement fromJson
    throw UnimplementedError();
  }
}

// class TaskVoMapper{
//   static TaskVo fromJson(Map<String, dynamic> json) {
//     return TaskVo.fromJson(json);
//   }
//
//   static List<TaskVo> fromJsonList(List<Map<String, dynamic>> jsonList) {
//     return  jsonList.map((item) => TaskVo.fromJson(item)).toList();
//   }
//
//   static toJsonList(List<TaskVo> vos){
//     return vos.map((vo) => vo.toJson()).toList();
//   }
//   static TaskVo toVo(TaskVo entity) {
//     return entity.toJson() as TaskVo;
//   }
//   static List<TaskVo> toVos(List<TaskVo> entities) {
//     return entities.map((entity) => toVo(entity)).toList();
//   }
//   static toJsonEncoded(){
//
//   }
//   static dynamic fromJsonEncoded(String jsonStr){
//     final decoded  = jsonDecode(jsonStr);
//     if(decoded is List)
//       return TaskVoMapper.fromJsonList(decoded as List<Map<String, dynamic>>);
//     else
//       return TaskVoMapper.fromJson(decoded as Map<String, dynamic>);
//   }
//
//
// }
