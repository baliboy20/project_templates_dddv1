part of 'SnippetScreen.dart';



class SnippetFormScreen extends StatefulWidget {
  final SnippetEntity? snippet;
  final List<String> categoryChoices;

  SnippetFormScreen({this.snippet, required this.categoryChoices});

  @override
  _SnippetFormScreenState createState() => _SnippetFormScreenState();
}

class _SnippetFormScreenState extends State<SnippetFormScreen> {
  late TextEditingController titleController;
  late TextEditingController contentController;
  late List<String> selectedCategories;

  @override
  void initState() {
    super.initState();
    titleController = TextEditingController(text: widget.snippet?.title ?? '');
    contentController = TextEditingController(text: widget.snippet?.body ?? '');
    selectedCategories = widget.snippet?.categories ?? [];
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Snippet',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22)),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal, Colors.tealAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            spacing: 20,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: titleController,
                decoration: InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
              ),

              TextField(
                controller: contentController,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: 'Content',
                  border: OutlineInputBorder(),
                ),
              ),

              Text('Categories', style: TextStyle(fontWeight: FontWeight.bold)),
              Wrap(
                spacing: 8.0,
                children: selectedCategories.map((category) {
                  return Chip(
                    label: Text(category),
                    onDeleted: () {
                      setState(() {
                        selectedCategories.remove(category);
                      });
                    },
                  );
                }).toList(),
              ),

              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  labelText: 'Add Category',
                  border: OutlineInputBorder(),
                ),
                value: null,
                items: widget.categoryChoices
                    .map((category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (value) {
                  if (value != null && !selectedCategories.contains(value)) {
                    setState(() {

                      selectedCategories.add(value);

                    });
                  }
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      BlocProvider.of<SnippetBloc>(context).add(AddOne(
                        SnippetEntity(
                          id: widget.snippet!.id,
                          title: titleController.text,
                          body: contentController.text,
                          categories: selectedCategories,
                          createdOn: DateTime.now(),
                          postedBy: widget.snippet!.postedBy,
                        ),
                      ));
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.save),
                    label: const Text('Save'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.cancel),
                    label: const Text('Cancel'),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
