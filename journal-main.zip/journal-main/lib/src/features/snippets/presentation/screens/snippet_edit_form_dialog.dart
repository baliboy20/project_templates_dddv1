part of 'SnippetScreen.dart';

class SnippetEditForm extends StatefulWidget {
  final List<String> categories;
  final SnippetEntity snippet;

  const SnippetEditForm({
    Key? key,
    required this.snippet,
    this.categories = const [],
  }) : super(key: key);

  @override
  _SnippetEditFormState createState() => _SnippetEditFormState();
}

class _SnippetEditFormState extends State<SnippetEditForm> {
  late TextEditingController _titleController;
  late TextEditingController _categoriesController;
  late TextEditingController _bodyController;
  late MultipleSelectController<String> _multipleSelectController;
  late double _height = 10;
  late int _maxLines = 20;

  void _updateHeight() {

    final text = _bodyController.text;

    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: 16.0, // Match the TextFormField's fontSize
          fontFamily:
              'Roboto', // Match the TextFormField's fontFamily (if applicable)
        ),
      ),
     // maxLines: max(2, _maxLines),
      //textDirection: TextDirection.LTR,
    );
    textPainter.textDirection = ui.TextDirection.ltr;
    textPainter.layout(
        maxWidth: context.size!.width - 24); // Subtract padding * 2

    final newHeight = textPainter.height + 16;
    wpLog("update height $newHeight");
    if (newHeight != _height ) {
    // if (newHeight != _height && newHeight <= _maxLines * 24.0) {
      setState(() {
        final ht  = this.context.size?.height ?? 0 - 300;
        wpLog("new height: $ht, $newHeight");
        _height = min(ht,newHeight);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _multipleSelectController =
        MultipleSelectController<String>(widget.snippet.categories);
    _titleController = TextEditingController(text: widget.snippet.title);
    _bodyController = TextEditingController(text: widget.snippet.body);
    _bodyController.addListener(_updateHeight);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateHeight();
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    _bodyController.dispose();
    _multipleSelectController.dispose();
    super.dispose();
  }

  void _saveChanges() {
    final updatedSnippet = widget.snippet.copyWith(
      title: _titleController.text,
      categories: _multipleSelectController.value,
      body: _bodyController.text,
    );
    Navigator.pop(context, (_PopupOperation.update, updatedSnippet));
  }

  // Future<void> _deleteSnippet() async {
  //   await _confirmDeleteDialog(widget.snippet.id ?? "");
  //   // Navigator.pop(context, (_PopupOperation.delete, widget.snippet.id));
  // }

  Future<void> _confirmDeleteDialog() async {
    bool retval = await showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Confirm Deletion for ${widget.snippet.title}'
            'Continue delete this item? This action cannot be undone.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          actions: [
            OverflowBar(
              alignment: MainAxisAlignment.start,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  // Cancel action
                  child: const Icon(
                    Icons.clear,
                    color: Colors.red,
                    size: 26,
                  ),
                ),
                TextButton(
                  focusNode: FocusNode(),
                  autofocus: true,
                  onPressed: () => Navigator.pop(context, true),
                  child: const Icon(
                    Icons.check,
                    color: Colors.green,
                    size: 26,
                  ),
                ),
              ],
            )
          ],
        );
      },
    );
    Navigator.pop(context, (_PopupOperation.delete, widget.snippet.id));
    // return retval ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final Color start = Colors.yellow.withBlue(120);
    final end = Colors.yellow.withBlue(90);
    return Dialog(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [end, start],
              begin: Alignment.center,
              end: Alignment.bottomCenter),
        ),
        padding: const EdgeInsets.all(16.0),
        constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.8,
            maxWidth: MediaQuery.of(context).size.width * 0.8),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 16,
          mainAxisSize: MainAxisSize.max,
          children: [
            TextFormField(
              controller: _titleController,
              decoration: const InputDecoration(
                labelText: 'Title',
                filled: true,
              ),
            ),
            SizedBox(
              height: _height,
              child: TextFormField(
                keyboardType: TextInputType.multiline,
                controller: _bodyController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Body',
                  label: Text('Snippet'),
                  // labelText: 'Bodl',
                  fillColor: Colors.white54,
                  filled: true,
                ),
                // expands: true,
                maxLines: _maxLines,
                minLines: 2,
              ),
            ),
            MultipleSectionDropdownChip(
              controller: _multipleSelectController,
              options: widget.categories,
            ),
            Row(children: [
              Text("${DateFormat.yMMMd().format(widget.snippet.createdOn)}"),
              Text("   Posted By: ${widget.snippet.postedBy}"),
            ]),
            Expanded(child: SizedBox.expand()),
            Row(
              children: [
                TextButton(
                  focusNode: FocusNode(),
                  autofocus: true,
                  onPressed: () async => await _confirmDeleteDialog(),
                  child:
                      const Text('Delete', style: TextStyle(color: Colors.red)),
                ),
                TextButton(
                  onPressed: () =>
                      Navigator.pop(context, (_PopupOperation.cancel, null)),
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: _saveChanges,
                  child: const Text('Save'),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

///
enum _PopupOperation { update, delete, cancel }

///dropdown menu with multiple selection and chip options//
///
///
///
///
///

class MultipleSectionDropdownChip extends StatefulWidget {
  final List<String> options;

  final MultipleSelectController<String>? controller;

  MultipleSectionDropdownChip(
      {super.key, this.controller, required this.options});

  @override
  State<MultipleSectionDropdownChip> createState() =>
      _MultipleSectionDropdownChipState();
}

class _MultipleSectionDropdownChipState
    extends State<MultipleSectionDropdownChip> {
  late MultipleSelectController<String> _controller;
  late TextEditingController
      _textController; // for the categores dropmenu edit box.

  @override
  initState() {
    super.initState();
    _textController = TextEditingController();
    _controller = (widget.controller != null
        ? widget.controller
        : MultipleSelectController<String>())!;

    _controller?.addListener(() {
      print("controller changed");
      setState(() {
        // _selectedSections = _controller.value;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Wrap(
      runAlignment: WrapAlignment.start,
      spacing: 8.0,
      runSpacing: 4.0,
      alignment: WrapAlignment.start,
      crossAxisAlignment: WrapCrossAlignment.end,
      children: [
        DropdownMenu(
          controller: _textController,
          alignmentOffset: Offset(0, 40),
          onSelected: (e) {
            if (e != null)
              _controller.add(e!);
            else if (_textController.text.isNotEmpty)
              _controller.add(_textController.text);
            _textController.clear();
          },
          dropdownMenuEntries: widget.options
              .whereType<String>()
              .map((e) => DropdownMenuEntry<String>(value: e, label: e))
              .toList(),
        ),
        ..._controller.value
            .map<Widget>((e) => Chip(
                  deleteIcon: Icon(Icons.close),
                  onDeleted: () {
                    wpLog("deleteding $e");
                    _controller.remove(e);
                  },
                  label: Text(e),
                ))
            .toList(),
      ],
    );
  }
}

class MultipleSelectController<T> extends ValueNotifier<List<T>> {
  MultipleSelectController([List<T>? value]) : super(value ?? []);

  void add(T item) {
    if (value.contains(item)) return;
    value = [...value, item];
    notifyListeners(); // Add item to the list
  }

  void remove(T item) {
    value.removeWhere((element) => element == item);
    notifyListeners(); // Remove item
  }

  void toggle(T item) {
    if (value.contains(item)) {
      remove(item);
    } else {
      add(item);
    }
  }

  bool isSelected(T item) => value.contains(item);

  void clear() {
    value = [];
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///// Testing Snippet Edit Form //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// main_devtest() {
//   runApp(DevTestApp());
// }
//
// class DevTestApp extends StatelessWidget {
//   const DevTestApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       home: DevTestScreen(),
//     );
//   }
// }
//
// class DevTestScreen extends StatefulWidget {
//   const DevTestScreen({super.key});
//
//   @override
//   State<DevTestScreen> createState() => _DevTestScreenState();
// }
//
// class _DevTestScreenState extends State<DevTestScreen> {
//   final SnippetEntity mySnippet = SnippetEntity(
//     id: 'sdfdsf',
//     title: 'My Snippet',
//     categories: ['Category 1', 'Category 2'],
//     body: 'This is my snippet body.',
//     createdOn: DateTime.now(),
//     postedBy: 'John Doe',
//   );
//
//   Future<(SnippetEntity?, bool?)> _showSnippetEditDialog({
//     required BuildContext context,
//     required SnippetEntity snippet,
//   }) async {
//     final a = await showDialog(
//       context: context,
//       builder: (context) => SnippetEditForm(
//         snippet: snippet,
//         categories: [],
//       ),
//     );
//     return a;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Center(
//         child: Row(
//       children: [
//         IconButton(
//           icon: Icon(Icons.edit),
//           onPressed: () async {
//             final result = await _showSnippetEditDialog(
//                 context: context, snippet: mySnippet);
//           },
//         )
//       ],
//     ));
//   }
// }
