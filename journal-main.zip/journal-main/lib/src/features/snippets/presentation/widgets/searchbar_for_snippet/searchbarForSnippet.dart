//============================================================
// template created on: 2023-06-14 16:48:22.701639
// version: 1.1
//============================================================



import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/dev_utils/console_log.dart';

import '../../blocs/snippet_bloc.dart';
import '../../blocs/snippet_events.dart';



class SearchbarSnippet extends StatefulWidget  {

   SearchbarSnippet({Key? key}) : super(key: key);

  @override
  State<SearchbarSnippet> createState() => _SearchbarSnippetState();
}

class _SearchbarSnippetState extends State<SearchbarSnippet>  with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  late TextEditingController searchController;
  String lastval ='';
  @override
  bool get wantKeepAlive => true;
  @override
  initState() {
  searchController = TextEditingController();
    super.initState();

  }
  @override
  Widget build(BuildContext context) {
    return SearchBar(
      controller: searchController,
      hintText: 'Search',
      leading: Icon(CupertinoIcons.search, size: 22,),
      onChanged: (value) {
        if (searchController.text.length <= 1 ) return;
        if(searchController.text == lastval) return;
        lastval = searchController.text;
        Debouncer.instanceOf(millis: 500)..run( (){
          BlocProvider.of<SnippetBloc>(context)
              .add(FilterOn(criteria: {"find": searchController.text}));
          wpLog(value);
        });
      }
    );

  }
}

//todo: add this.
class Debouncer {
  final int milliseconds;
  static Timer? _timer;
  static Debouncer? _debouncer;

  static Debouncer instanceOf({int millis = 200}) {
    return _debouncer ?? Debouncer(milliseconds: millis);
  }

  Debouncer({required this.milliseconds});

  run(VoidCallback action) {
    if (_timer == null)
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    else {
      _timer?.cancel();
      _timer = Timer(Duration(milliseconds: milliseconds), action);
    }
  }
}
