// journal_bloc.dart
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/generic_crud/repository/crud_repository.dart';
import 'package:journal_macos/src/core/error/app_error.dart';
import 'package:journal_macos/src/features/snippets/infrastructure/models/snippet_vo.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_events.dart'
    as ev;
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_events.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/snippet_states.dart';
import 'package:journal_macos/src/features/snippets/presentation/blocs/usecases/categories_set.usecase.dart';

import '../../domain/entities/snippet_entity.dart';

class SnippetBloc extends Bloc<SnippetEvent, SnippetState> {
  final List<SnippetEntity> items = [];
  final CrudRepositoryImpl<SnippetEntity, SnippetVo> repository;

  SnippetBloc({required this.repository}) : super(Loading()) {
    on<LoadSnippets>(_onLoadSnippets);
    on<DeleteSnippet>(_onDeleteSnippet);
    on<SelectSnippet>(_onSelectSnippet);
    on<ev.AddOne>(_onAdd);
    on<ev.UpdateOne>(_onUpdate);
    on<ev.FilterOn>(_onFilterOn);
  }

  Future<void> _getAllitems(emit) async {
    final result = await repository.getAll();
    if (result.hasValue()) {
      emit(SnippetsResult(SnippetsOrderedByDateUsecase()(result.value!),
          CategoriesSetUsecase()(result.value!)));
    }
    if (result.hasError()) {
      emit(SnippetError('Fail : ${result.error?.message ?? 'unknown error'}'));
      emit(SnippetNotification('Changes not saved'));
    }
  }

  Future<void> _onFilterOn(ev.FilterOn event, Emitter<SnippetState> emit) async {
    final entry = event.criteria.entries.first;
    final result = await repository.filterOn({entry.key: entry.value});
    if (result.hasValue()) {
      emit(SnippetsResult(SnippetsOrderedByDateUsecase()(result.value!),
          CategoriesSetUsecase()(result.value!)));
    }
  }

  void _onLoadSnippets(LoadSnippets event, Emitter<SnippetState> emit) async =>
      _getAllitems(emit);

  void _onDeleteSnippet(DeleteSnippet event, Emitter<SnippetState> emit) async {
    final result = await repository.deleteOne(event.id);
    if (result.hasValue()) {
      emit(SnippetNotification('Snippet deleted'));
      await _getAllitems(emit);
    }
    if (result.hasError()) {
      emit(SnippetError('Fail : ${result.error?.message ?? 'unknown error'}'));
      emit(SnippetNotification('Changes not saved'));
      await _getAllitems(emit);
    }
  }

  void _onSelectSnippet(SelectSnippet event, Emitter<SnippetState> emit) {
    // find index of selected journal and remplace it with the new one
    final selectedSnippet = items.firstWhere(
      (journal) => journal.id == event.id,
      orElse: () => SnippetEntity(
          id: '',
          title: '',
          body: '',
          categories: [],
          createdOn: DateTime.now(),
          postedBy: ''),
    );
    emit(SnippetSelectedForChanging(selectedSnippet));
  }

  void _onAdd(AddOne event, Emitter<SnippetState> emit) async {
    emit(SnippetSaving());

    final reply = await repository.createOne(event.snippet);

    if (reply.hasValue()) {
      await _getAllitems(emit);
      emit(SnippetNotification('Changes saved'));
    }

    if (reply.hasError()) {
      emit(SnippetError('Fail : ${reply.error?.message ?? 'unknown error'}'));
      emit(SnippetNotification('Changes not saved'));
      await _getAllitems(emit);
    }
  }

  void _onUpdate(ev.UpdateOne event, Emitter<SnippetState> emit) async {
    emit(SnippetSaving());

    final reply = await repository.updateOne(event.snippet);

    if (reply.hasValue()) {
      emit(SnippetNotification('Changes saved'));
      await _getAllitems(emit);
    }

    if (reply.hasError()) {
      emit(SnippetError('Fail : ${reply.error?.message ?? 'unknown error'}'));
      emit(SnippetNotification('Changes not saved'));
    }
  }
}
