// journal_event.dart
import 'package:equatable/equatable.dart';
import '../../domain/entities/snippet_entity.dart';


abstract class SnippetEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class InitSnippets extends SnippetEvent {}



class LoadSnippets extends SnippetEvent {}

class DeleteSnippet extends SnippetEvent {
  final String id;
  DeleteSnippet(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectSnippet extends SnippetEvent {
  final SnippetEntity id;
  SelectSnippet(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends SnippetEvent {
  final SnippetEntity snippet;
  SaveChanges(this.snippet);

  @override
  List<Object?> get props => [snippet];
}

class UpdateOne extends SnippetEvent {
  final SnippetEntity snippet;
  UpdateOne(this.snippet);

  @override
  List<Object?> get props => [snippet];
}

class AddOne extends SnippetEvent {
  final SnippetEntity snippet;
  AddOne(this.snippet);

  @override
  List<Object?> get props => [snippet];
}

class FilterOn extends SnippetEvent {
  final Map<String, dynamic> criteria;
  FilterOn({required this.criteria});

  @override
  List<Object?> get props => [criteria];
}

