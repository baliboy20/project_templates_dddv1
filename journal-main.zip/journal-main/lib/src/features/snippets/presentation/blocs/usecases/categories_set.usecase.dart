import 'package:journal_macos/src/features/snippets/domain/entities/snippet_entity.dart';

class CategoriesSetUsecase {
  List<String> call(List<SnippetEntity> snippets) {
    // After
    try {
      List<String> categories =
          snippets.expand((element) => element.categories).toSet().toList();
      categories.sort((a, b) => a.compareTo(b));
      return categories;
    } catch (e) {
      return [e.toString()];
    }
  }
}

class SnippetsOrderedByDateUsecase {
  List<SnippetEntity> call(List<SnippetEntity> snippets) {
    // After
    try {
      if (snippets.length > 1)
        return  snippets..sort((a, b) => b.createdOn.compareTo(a.createdOn));
      else
        return snippets;
    } catch (e) {
     rethrow;
    }
  }
}

// main() {
//   List<SnippetEntity> snippets = [
//   SnippetEntity(
//       id: "1",
//       title: "Snippet 1",
//       body: "",
//       categories: ["Category 1", "Category 2"],
//       createdOn: DateTime.now(),
//       postedBy: "User 1"
//   )
//   ,
//   SnippetEntity(
//   id: "2",
//   title: "Snippet 2",
//   body: "",
//   categories: ["Category 3", "Category 4","Category 1", "Category 2"],
//   createdOn: DateTime.now(),
//   postedBy: "User 2"
//   ),
//   SnippetEntity(
//   id: "3",
//   title: "Snippet 3",
//   body: "",
//   categories: ["Category 5", "Category 6"],
//   createdOn: DateTime.now(),
//   postedBy: "User 3"
//   ),
//   SnippetEntity(id: "4", title: "Snippet", body: "",
//    categories: ["Category 5", "Category 6"], createdOn: DateTime.now(), postedBy: "User")
//
//
//   ];
//
//   final usecase = ListCategoiesUsecase()(snippets);
//   print(usecase);
//
// }
//
