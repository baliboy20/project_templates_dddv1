import 'dart:async';

import 'package:journal_macos/src/features/snippets/infrastructure/models/snippet_vo.dart';

abstract class FeatureRepository <T> {
  Future<List<T>> getItems();
  Future<List<T>> findItemsWhere(Map<String, dynamic> criteria);
  Future<T> updateItem(T item);
  Future<T> addItem(T item);
  Future<dynamic> deleteItem(T item);
  Future<dynamic> getList();

  get isChanged;
  Future<List<T>?> filterItems(Map<String, dynamic> map);
}
