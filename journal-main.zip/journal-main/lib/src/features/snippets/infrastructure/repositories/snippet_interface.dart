// snippet_repository.dart
import '../../domain/entities/snippet_entity.dart';
import '../models/snippet_vo.dart';

abstract class SnippetRepository {
  Future<List<SnippetEntity>> getAllSnippets();
  Future<List<SnippetVo>> findSnippetsByTitle(String title);
  Future<Map<String, dynamic>> createSnippet(SnippetEntity snippet);
  Future<bool> updateSnippet(SnippetEntity snippet);
  Future<Map<String, dynamic>> deleteSnippetById(String id);
  Future<List<SnippetVo>> filterSnippets(Map<String, dynamic> criteria);
}
