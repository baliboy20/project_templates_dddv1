import 'dart:convert';

import 'package:journal_macos/dev_utils/console_log.dart';

import '../../models/snippet_vo.dart';

class JsonSnippetVoMapper {
  static dynamic decodeJsonList(String jsonStr) {
    final json = jsonDecode(jsonStr);

    if (json is List) {
      final List<SnippetVo> snippets = [];
      for (var item in json) {
        try {
          final snippet = SnippetVo.fromJson(item);
          snippets.add(snippet);
        } catch (e) {
          wpLog('invalid json $item');
        }
      } //endfor
      return snippets;
    } else if (json is Map<String, dynamic>) {
      try {
        final snippet = SnippetVo.fromJson(json);
        return snippet;
      } catch (e) {
        wpLog('invalid json $json');
      }
    }
  }

  static String encodeSnippetVo(dynamic vos) {
    if (vos is List<SnippetVo>) {
      return jsonEncode(vos.map((e) => e.toJson()).toList());
    } else if (vos is SnippetVo) {
      return jsonEncode(vos.toJson());
    } else
      throw Exception('Failed to encode ValueObjectMappable $vos');
  }
}
