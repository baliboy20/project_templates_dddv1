import 'package:parse_utils/core/app_configs/db_parse_local_settings.dart';
import 'package:parse_utils/infrastructure/api/parse_generic_service_api.dart';

import '../../models/snippet_vo.dart';



class SnippetApi extends ParseApiService {
  SnippetApi() : super("snippets");

  Future<List<SnippetVo>> fetchSnippets() async {
    final items = await getItems();
    if (items.isEmpty) return [];
    return items.map((item) => SnippetVo.fromJson(item)).toList();
  }

  Future<SnippetVo?> getSnippetById(String id) async {
    final item = await getById(id);
    return item != null ? SnippetVo.fromJson(item) : null;
  }

  Future<SnippetVo?> addSnippet(SnippetVo snippet) async {
    final result = await addOne(snippet.toJson());
    return result != null ? SnippetVo.fromJson(result) : null;
  }

  Future<SnippetVo?> updateSnippet(String id, SnippetVo snippet) async {
    final result = await updateOne(id, snippet.toJson());
    return result != null ? SnippetVo.fromJson(result) : null;
  }

  Future<bool> deleteSnippet(String id) async {
    return await deleteOne(id);
  }
}
