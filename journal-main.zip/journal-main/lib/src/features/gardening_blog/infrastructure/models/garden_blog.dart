import 'dart:convert';

import 'package:bson/bson.dart';
import 'package:ddd_framework_assets/core/validation/json_validator.dart';
import 'package:equatable/equatable.dart';

import '../../../../../generic_crud/repository/crud_repository.dart';

abstract interface class Encodable<T> {
  Map<String, dynamic> toJson();

  T fromJson(Map<String, dynamic> json);
}

class GardenBlogVo extends Equatable {
  final String title;
  final List<String> categories;
  final String body;
  final String? id;
  final DateTime createdOn;
  final String postedBy;

  GardenBlogVo({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  });

  DateTime getDateFromObjectId(String objectId) {
    try {
      // Convert the first 8 characters (representing the timestamp) to a 4-byte integer
      final timestampHex = objectId.substring(0, 8);
      final timestamp = int.parse(timestampHex, radix: 16);
      // Convert Unix timestamp to a DateTime object
      return DateTime.fromMillisecondsSinceEpoch(timestamp * 1000, isUtc: true);
    } catch (e) {
      throw FormatException('Invalid ObjectId format: $e');
    }
  }

  factory GardenBlogVo.fromJson(Map<String, dynamic> json) {
    final frgid = json['objectId'] ;
    final missing = 'missingvalue';
   final validator = JsonValidation.singleton()
   ..nextFrag(fragment: json, clearFailures: false, fragId: frgid);

   final title = validator.isString(
       key: 'title',
       severity: ValidationFailureSeverity.log,
       altValue: missing
   );

   final categories = validator.isList(
       key: 'categories',
       severity: ValidationFailureSeverity.log,
       altValue: []
   );

   final body = validator.isString(
       key: 'body',
       severity: ValidationFailureSeverity.log,
       altValue: missing
   );





    String idstr;
    if(json['_id'] is ObjectId) {
      idstr = json['_id'].toHexString();
    } else {
      idstr = json['_id'] ?? '';
    }

    final vo = GardenBlogVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      createdOn: DateTime.parse(idstr),
      id: idstr,
      postedBy: json['postedBy'] ?? 'Guest poster',
    );

    return vo;
  }

  @override
  List<Object> get props => [title, categories, body, id!, createdOn, postedBy];

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'categories': categories,
      'body': body,
      'id': id ?? '',
      'createdOn': createdOn.toIso8601String(),
      'postedBy': postedBy,
    };
  }

  static GardenBlogVo newInstance() {
    return GardenBlogVo(
      title: '',
      categories: [],
      body: '',
      id: null,
      createdOn: DateTime.now(),
      postedBy: '',
    );
  }

  String concatenateFields() {
    return '${title}${categories.join()}${body}${postedBy}';
  }

  @override
  GardenBlogVo fromJson(Map<String, dynamic> json) {
    return GardenBlogVo(
      title: json['title'] ?? '',
      categories: List<String>.from(json['categories']) ?? [],
      body: json['body'] ?? '',
      id: json['id'] ?? null,
      createdOn: json['createdOn'],
      postedBy: json['postedBy'],
    );
  }
}

class JournalVoMapper{
  static GardenBlogVo fromJson(Map<String, dynamic> json) {
    return GardenBlogVo.fromJson(json);
  }
  static fromJsonList(List<Map<String, dynamic>> jsonList) {
    return jsonList.map((json) => GardenBlogVo.fromJson(json)).toList();

  }
  static Map<String, dynamic> toJson(GardenBlogVo value) {
    return value.toJson();
  }
  static List<Map<String, dynamic>> toMapList(List<GardenBlogVo> value) {
    return value.map((value) => value.toJson()).toList();
  }
  static String toJsonString(value) {
    if(value is GardenBlogVo)
      return jsonEncode(value.toJson());
    else if(value is List<GardenBlogVo>)
    return jsonEncode(toMapList(value));
    else
      throw Exception('unsupported type should be list or JounnalVo ${value}');

  }
  static dynamic fromJsonEncoded(String jsonStr) {
   try {
      final json = jsonDecode(jsonStr);

      if (json is Map<String, dynamic>) {
        return GardenBlogVo.fromJson(json);
      }
      if (json is List<dynamic>) {
        return fromJsonList(json.cast<Map<String, dynamic>>());
      }
      throw Exception('unsupported type should be list or JounnalVo ${json.runtimeType}');
    }catch (e) {
     print('$e');
     rethrow;
   }
  }
}
