// journal_repository.dart
import '../../domain/entities/garden_blog_entity.dart';
import '../models/garden_blog.dart';

// abstract class JournalRepository {
//   Future<List<GardenBlogEntity>> getAllJournals();
//   Future<List<GardenBlogVo>> findJournalsByTitle(String title);
//   Future<List<GardenBlogEntity>> createJournal(GardenBlogEntity journal);
//   Future<List<GardenBlogEntity>>updateJournal(GardenBlogEntity journal);
//   Future<List<GardenBlogEntity>> deleteJournalById(String id);
//   Future<List<GardenBlogVo>> filterJournals(Map<String, dynamic> criteria);
// }
