part of 'garden_blog_screen.dart';

class GardenBlogEditForm extends StatefulWidget {
  final GardenBlogEntity entity;
  final EditOrNew editOrNew;

  const GardenBlogEditForm({
    super.key,
    required this.editOrNew,
    required this.entity,
  });

  @override
  State<GardenBlogEditForm> createState() => _GardenBlogEditFormState();
}

class _GardenBlogEditFormState extends State<GardenBlogEditForm> {
  final _formKey = GlobalKey<FormState>();
  late MultiProductImageSelector a;

  final _imageSelectorKey = GlobalKey<StateKeyType>();
  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;
  late Set<String> _selectedCategories;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.entity.title);
    _bodyController = TextEditingController(text: widget.entity.body);
    _selectedCategories = Set<String>.from(widget.entity.categories);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  Future<void> _onSave() async {
    final bloc = BlocProvider.of<GardenBlogBloc>(context);
    print('bloc is ${bloc}');

    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    final modifiedImagesVo =
        _imageSelectorKey.currentState?.getModifiedImages();

    wpLog('modifiedImagesVo in onsave is ${modifiedImagesVo}');
     GardenBlogEvent event;
    if (widget.editOrNew == EditOrNew.Edit) {
      final updatedBlog = widget.entity.copyWith(
          title: _titleController.text,
          body: _bodyController.text,
          categories: _selectedCategories.toList());

     event =SaveChanges(
        gardenBlog: updatedBlog,
        modifiedImagesVo: modifiedImagesVo ?? ModifiedImagesVo.empty(),
      );
    } else {
      event =(AddOne(
        modifiedImagesVo: modifiedImagesVo ?? ModifiedImagesVo.empty(),
        gardenBlog: GardenBlogEntity(
          id: null,
          title: _titleController.text,
          body: _bodyController.text,
          categories: _selectedCategories.toList(),
          createdOn: DateTime.now(),
          postedBy: 'Guest',
        ),
      ));


    }
    Navigator.pop(context,event );
  }

  @override
  Widget build(BuildContext context) {
    final bloc = BlocProvider.of<GardenBlogBloc>(context);
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(26.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: ListView(
              shrinkWrap: true,
              children: [
                MultiProductImageSelector(
                  key: _imageSelectorKey,
                  imageRefs: widget.entity.imageRefs ?? [],
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(labelText: 'Journal Title'),
                  validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  minLines: 3,
                  maxLines: 10,

                  controller: _bodyController,
                  decoration: const InputDecoration(labelText: 'Journal Body'),
                  validator: (v) => (v?.isEmpty ?? true) ? 'Required' : null,
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8.0,
                  children: widget.entity.categories.map((category) {
                    final isSelected = _selectedCategories.contains(category);
                    return ChoiceChip(
                      label: Text(category),
                      selected: isSelected,
                      onSelected: (selected) {
                        setState(() {
                          if (selected) {
                            _selectedCategories.add(category);
                          } else {
                            _selectedCategories.remove(category);
                          }
                        });
                      },
                    );
                  }).toList(),
                ),
                const SizedBox(height: 24),
                ElevatedButton(onPressed: _onSave, child: Text('Save')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// class GardenBlogEditForm extends StatefulWidget {
//   final GardenBlogEntity entity;
//   final EditOrNew editOrNew;
//
//   const GardenBlogEditForm(
//       {super.key, required this.editOrNew, required this.entity});
//
//   @override
//   State<GardenBlogEditForm> createState() => _GardenBlogEditFormState();
// }
//
// class _GardenBlogEditFormState extends State<GardenBlogEditForm> {
//   late final TextEditingController _titleController;
//   late final TextEditingController _bodyController;
//   late Set<String> _selectedCategories;
//
//   File? _image;
//   final ImagePicker _picker = ImagePicker();
//
//   Future<void> _pickImage() async {
//     final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
//
//     if (pickedFile != null) {
//       setState(() {
//         _image = File(pickedFile.path);
//       });
//     }
//   }
//
//   Future<void> _uploadImage() async {
//     if (_image == null) return;
//
//     var uri = Uri.parse('http://your-node-server.com/upload'); // Change URL
//     var request = http.MultipartRequest('POST', uri);
//     request.files.add(
//       await http.MultipartFile.fromPath('image', _image!.path,
//           filename: basename(_image!.path)),
//     );
//
//     var response = await request.send();
//
//     if (response.statusCode == 200) {
//       print('Image Uploaded Successfully');
//     } else {
//       print('Upload Failed');
//     }
//   }
//
//
//   @override
//   void initState() {
//     super.initState();
//     wpLog("${widget.entity.title}");
//     _titleController = TextEditingController(text: widget.entity.title);
//     _bodyController = TextEditingController(text: widget.entity.body);
//     _selectedCategories = Set<String>.from(widget.entity.categories ?? []);
//   }
//
//   showImage() {
//     if (_image != null) {
//       return Image.file(_image!);
//     } else if(widget.entity.filename != null){
//       final path = AppSettings.serverUrl + '/uploads/' +( widget.entity.filename ?? "");
//       return Image.network("${path}");
//     } else {
//       return SizedBox.shrink();
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: const EdgeInsets.all(26.0),
//       child: Column(
//         mainAxisSize: MainAxisSize.min,
//         children: [
//           ConstrainedBox(constraints: BoxConstraints(
//           maxHeight: 200,
//       ),
//           child: showImage(),
//           ),
//
//           widget.editOrNew == EditOrNew.New ? Icon(Icons.add_business, size: 50,color: Colors.purple,) : Icon(Icons.edit,size: 50,color: Colors.purple,),
//
//           ElevatedButton(onPressed: _pickImage, child: Text('Pick Image')),
//           TextField(
//             controller: _titleController,
//             decoration: const InputDecoration(labelText: 'Journal Title'),
//           ),
//           const SizedBox(height: 16.0),
//           TextField(
//             maxLines: 30,
//             controller: _bodyController,
//             decoration: const InputDecoration(labelText: 'Journal Body'),
//           ),
//           const SizedBox(height: 16.0),
//           Wrap(
//             spacing: 8.0,
//             children: _selectedCategories.map((category) {
//               final isSelected = _selectedCategories.contains(category);
//               return ChoiceChip(
//                 label: Text(category),
//                 selected: isSelected,
//                 onSelected: (selected) {
//                   setState(() {
//                     if (selected) {
//                       _selectedCategories.add(category);
//                     } else {
//                       _selectedCategories.remove(category);
//                     }
//                   });
//                 },
//               );
//             }).toList(),
//           ),
//           const SizedBox(height: 20),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceAround,
//             children: [
//               OutlinedButton.icon(
//                 onPressed: () {
//
//                (widget.editOrNew == EditOrNew.Edit)
//                    ? _saveEditsAction()
//                    : _SaveNewAction();
//                 },
//                 icon: const Icon(Icons.save),
//                 label: const Text('Save'),
//               ),
//               OutlinedButton.icon(
//                 onPressed: () async {
//                   final confirmed =
//                   await _showDeleteConfirmationDialog(context);
//                   if (confirmed) {
//                     BlocProvider.of<GardenBlogBloc>(context)
//                         .add(DeleteGardenBlog(widget.entity.id!));
//                   }
//                   Navigator.pop(context);
//                 },
//                 icon: const Icon(Icons.delete),
//                 label: const Text('Delete'),
//               ),
//               OutlinedButton.icon(
//                 onPressed: () => Navigator.pop(context),
//                 icon: const Icon(Icons.cancel),
//                 label: const Text('Cancel'),
//               ),
//             ],
//           )
//         ],
//       ),
//     );
//   }
//
//   Future<bool> _showDeleteConfirmationDialog(BuildContext context) async {
//     return await showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: const Text('Confirm Deletion'),
//           content: const Text(
//               'Are you sure you wish to delete this journal? This action cannot be undone.'),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(false),
//               child: const Text('Cancel'),
//             ),
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(true),
//               child:
//               const Text('Delete', style: TextStyle(color: Colors.red)),
//             ),
//           ],
//         );
//       },
//     ) ??
//         false;
//   }
//
//   Future<void> _saveEditsAction() async {
//
//     final newent = widget.entity.copyWith(
//       title: _titleController.text,
//       body: _bodyController.text,
//       categories: _selectedCategories.toList(),
//       createdOn: widget.entity.createdOn,
//       postedBy: widget.entity.postedBy,
//       id: widget.entity.id,
//     );
//
//
//     var event  =  SaveChanges(newent, _image);
//
//     BlocProvider.of<GardenBlogBloc>(this.context).add(event);
//
//     Navigator.pop(this.context);
//   }
//   Future<void> _SaveNewAction() async {
//     final newent = GardenBlogEntity(
//       id: null,
//       title: _titleController.text,
//       body: _bodyController.text,
//       categories: _selectedCategories.toList(),
//       createdOn: widget.entity.createdOn,
//       postedBy: widget.entity.postedBy,
//     );
//
//     var event  =  AddOne(newent, _image);
//
//     BlocProvider.of<GardenBlogBloc>(this.context).add(event);
//
//     Navigator.pop(this.context);
//
//   }
// }
