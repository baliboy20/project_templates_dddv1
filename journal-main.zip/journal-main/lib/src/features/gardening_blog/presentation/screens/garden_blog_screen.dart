import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/dev_utils/console_log.dart';
import 'package:parse_utils/domain/models/image_ref.vo.dart';
import 'package:parse_utils/domain/models/modified_images_vo.dart';
import 'package:parse_utils/presentation/multifilepicker/multi_image_picker.dart';

import '../../../../core/enums/editOrNew.dart';
import '../../domain/entities/garden_blog_entity.dart';
import '../blocs/garden_blog_bloc.dart';
import '../blocs/garden_blog_events.dart';
import '../blocs/garden_blog_states.dart' as st;
import '../blocs/garden_blog_states.dart';
part 'garden_blog_entryform.dart';



class GardenBlogScreen extends StatelessWidget {
  static const routeName = '/garden-blog';
  static const routeLabel = 'Garden Blog';


  const GardenBlogScreen({super.key});

  static MaterialPageRoute genRoute() {
    return MaterialPageRoute(
      settings: const RouteSettings(name: routeName),
      builder: (context) {
        final bloc = BlocProvider.of<GardenBlogBloc>(context);
        if (bloc.state is! GardenBlogLoaded) bloc.add(LoadGardenBlogs());
        return const GardenBlogLayout();
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const GardenBlogLayout(),
      theme: ThemeData(
        primarySwatch: Colors.lightBlue,
        appBarTheme: AppBarTheme(
          color: Colors.lightBlueAccent,
          centerTitle: true,
          titleTextStyle: TextStyle(
              color: Colors.grey[900],
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

class GardenBlogLayout extends StatefulWidget {
  const GardenBlogLayout({super.key});


  @override
  State<GardenBlogLayout> createState() => _GardenBlogLayoutState();
}


class _GardenBlogLayoutState extends State<GardenBlogLayout> {


  @override
  void initState() {
   BlocProvider.of<GardenBlogBloc>(context).add(LoadGardenBlogs());


    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Garden Blog'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: BlocConsumer<GardenBlogBloc, GardenBlogState>(
        listener: (context, state) {
          if (state is GardenBlogError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text(state.message), backgroundColor: Colors.red),
            );
          } else if (state is GardenBlogNotification) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                  content: Text(state.message), backgroundColor: Colors.green),
            );
          }
        },
        listenWhen: (previous, current) =>
            current is GardenBlogError || current is GardenBlogNotification,
        builder: (context, state) {
          if (state is st.Loading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is GardenBlogLoaded) {
            return GardenBlogLoadedView(blogs: state.journals);
          } else if (state is GardenBlogSaving) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is GardenBlogSelectedForChanging) {
            return Text("Selected for changing");
            // return GardenBlogEditForm(journal: state.journal, editOrNew: "edit");
          } else if (state is GardenBlogError) {
            return Center(child: Text('Error: ${state.message}'));
          } else {
            return const Center(child: Text('Welcome to the Journals App!'));
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async => ShowBottomSheet(context, EditOrNew.New, null),
        child: const Icon(Icons.add),
      ),
    );
  }
}

Future <void> ShowBottomSheet(
    BuildContext context, EditOrNew editOrNew, GardenBlogEntity? entity)
async {
  final retval= await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (BuildContext context) {
      assert((entity == null && editOrNew == EditOrNew.New) ||
          (entity != null && editOrNew == EditOrNew.Edit));
      final arg =
          editOrNew == EditOrNew.Edit ? entity : GardenBlogEntity.empty();
      return Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: GardenBlogEditForm(entity: arg!, editOrNew: editOrNew)
          // child: GardenBlogEditForm(journal: journal, editOrNew: "edit"),
          );
    },
  );
  if (retval != null) {
    BlocProvider.of<GardenBlogBloc>(context).add(retval);
  }
}

class GardenBlogLoadedView extends StatelessWidget {
  final List<GardenBlogEntity> blogs;

  const GardenBlogLoadedView({super.key, required this.blogs});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: blogs.length,
      itemBuilder: (context, index) {
        final entity = blogs[index];
        final refs = entity.imageRefs ?? [];
        final defImg = refs.firstWhere((ImageRefVo a) => a.isDefault, orElse: () =>refs.first) ;

        return Dismissible(

          key: Key(entity.id!),
          direction: DismissDirection.startToEnd,
          background: Container(
            alignment: Alignment.centerRight,
            color: Colors.red.withOpacity(0.8),
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: const Icon(Icons.delete, color: Colors.white),
          ),
          confirmDismiss: (direction) async =>
              await _showDeleteConfirmationDialog(context, entity.id!),
          onDismissed: (direction) {
            BlocProvider.of<GardenBlogBloc>(context)
                .add(DeleteGardenBlog(entity.id!));
          },
          child: Card(
            margin: const EdgeInsets.symmetric(vertical: 8.0),
            child: ListTile(
              contentPadding: const EdgeInsets.all(16.0),
              title: Column(
                children: [
                  SizedBox(
                    width: 200,
                    height: 200,
                    child: Image.network(
                      entity.getDefaultImageUrl(),
                      errorBuilder: (context, error, stackTrace) {
                        return const Center(
                          child: Icon(Icons.error, color: Colors.red),
                        );
                      },
                    ),
                  ),
                  Text(
                    entity.title,
                    style: const TextStyle(
                        height: 2,
                        decoration: TextDecoration.underline,
                        fontSize: 18,
                        fontWeight: FontWeight.w400),
                  ),
                ],
              ),
              subtitle: Column(
                children: [
                  Text.rich(
                    TextSpan(
                      text: "\n${entity.body}",
                      style: const TextStyle(fontSize: 13),
                    ),
                    maxLines: 8,
                    overflow: TextOverflow.ellipsis,
                  ),
                  SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    //color: Colors.red[100],
                    child: Wrap(
                      alignment: WrapAlignment.start,
                      spacing: 8.0,
                      children: entity.categories.map((category) {
                        final isSelected = entity.categories.contains(category);
                        return Chip(
                          labelPadding: EdgeInsets.all(2),
                          label: Text(category),
                          backgroundColor: Colors.purple[100],
                        );
                      }).toList(),
                    ),
                  ),
                  Text.rich(
                    TextSpan(
                      text: "\n${entity.postedBy}",
                      style: const TextStyle(fontSize: 13),
                    ),
                    maxLines: 8,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text.rich(
                    textAlign: TextAlign.end,
                    TextSpan(
                      text: '\n\nCreated on: ${entity.createdOn?.toIso8601String()}',
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ),
                ],
              ),
              onTap: () async{
              final result = await  ShowBottomSheet(context, EditOrNew.Edit, entity);

              },
            ),
          ),
        );
      },
    );
  }

  Future<bool> _showDeleteConfirmationDialog(
      BuildContext context, String journalId) async {
    return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Confirm Delete'),
              content: Text('Are you sure you want to delete this journal?'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(false),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  focusNode: FocusNode(skipTraversal: false)..requestFocus(),
                  onPressed: () => Navigator.of(context).pop(true),
                  child:
                      const Text('Delete', style: TextStyle(color: Colors.red)),
                ),
              ],
            );
          },
        ) ??
        false;
  }

}
