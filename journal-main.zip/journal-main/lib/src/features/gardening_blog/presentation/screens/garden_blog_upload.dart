import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:path/path.dart';

class ImageUploadScreen extends StatefulWidget {
  @override
  _ImageUploadScreenState createState() => _ImageUploadScreenState();
}

class _ImageUploadScreenState extends State<ImageUploadScreen> {
  File? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _uploadImage() async {
    if (_image == null) return;

    var uri = Uri.parse('http://your-node-server.com/upload'); // Change URL
    var request = http.MultipartRequest('POST', uri);
    request.files.add(
      await http.MultipartFile.fromPath('image', _image!.path,
          filename: basename(_image!.path)),
    );

    var response = await request.send();

    if (response.statusCode == 200) {
      print('Image Uploaded Successfully');
    } else {
      print('Upload Failed');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload Image')),
      body: Column(
        children: [
          _image != null ? Image.file(_image!) : Placeholder(fallbackHeight: 200),
          ElevatedButton(onPressed: _pickImage, child: Text('Pick Image')),
          ElevatedButton(onPressed: _uploadImage, child: Text('Upload Image')),
        ],
      ),
    );
  }
}
