// journal_state.dart
import 'package:equatable/equatable.dart';
import '../../domain/entities/garden_blog_entity.dart';
 

abstract class GardenBlogState extends Equatable {
  @override
  List<Object?> get props => [];
}

class Loading extends GardenBlogState {}

class GardenBlogLoaded extends GardenBlogState {
  final List<GardenBlogEntity> journals;
  GardenBlogLoaded(this.journals);

  @override
  List<Object?> get props => [journals];
}

class GardenBlogSelectedForChanging extends GardenBlogState {
  final GardenBlogEntity journal;
  GardenBlogSelectedForChanging(this.journal);

  @override
  List<Object?> get props => [journal];
}

/// shows progress button.
class GardenBlogSaving extends GardenBlogState {}

class GardenBlogNotification extends GardenBlogState {
  final String message;
  GardenBlogNotification(this.message);

  @override
  List<Object?> get props => [message];
}

class NewGardenBlog extends GardenBlogState {}

class GardenBlogError extends GardenBlogState {
  final String message;
  GardenBlogError(this.message);

  @override
  List<Object?> get props => [message];
}