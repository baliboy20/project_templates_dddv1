
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:journal_macos/dev_utils/console_log.dart';
import 'package:parse_utils/core/app_configs/db_parse_local_settings.dart';
import 'package:parse_utils/domain/models/image_ref.vo.dart';
import 'package:parse_utils/domain/usecases/add_many_images.dart';
import 'package:parse_utils/domain/usecases/delete_many_images.dart';
import 'package:parse_utils/domain/usecases/image_storage_operations.dart';

import '../../domain/entities/garden_blog_entity.dart';
import '../../domain/repositories/garden_blog.repository.dart';
import 'garden_blog_events.dart';
import 'garden_blog_states.dart';

class GardenBlogBloc extends Bloc<GardenBlogEvent, GardenBlogState> {
  final GardenBlogRepositoryImpl repository;

  GardenBlogBloc({required this.repository}) : super(Loading()) {
    on<LoadGardenBlogs>(_onLoadGardenBlogs);
    on<DeleteGardenBlog>(_onDeleteGardenBlog);
    on<AddOne>(_onAddOne);
    on<SaveChanges>(_onSaveChanges);
  }

  Future<void> _onLoadGardenBlogs(LoadGardenBlogs event, Emitter<GardenBlogState> emit) async {
    emit(Loading());
    await Future.delayed(Duration(milliseconds: 300));

    final blogs = await repository.getAll();
    blogs.sort((a, b) => b.createdOn?.compareTo(a.createdOn ?? DateTime(0)) ?? 0);

    emit(GardenBlogLoaded(blogs));
  }

  Future<void> _onDeleteGardenBlog(DeleteGardenBlog event, Emitter<GardenBlogState> emit) async {
    final success = await repository.deleteOne(event.id);
    if (success) {
      add(LoadGardenBlogs());
    } else {
      emit(GardenBlogError('Failed to delete garden blog'));
    }
  }

  void todoOnSave(GardenBlogEntity entity) async {

  }

  Future<void> _onSaveChanges(SaveChanges event, Emitter<GardenBlogState> emit) async {

    emit(GardenBlogSaving());
    /// save new files.
    /// delete other files

    try {
      final resAdded = await AddManyImages(settings: DBConfig).call(event.modifiedImagesVo);
      final resDeleted = await DeleteManyImages(settings: DBConfig).call(event.modifiedImagesVo.deletedImages);

      if(resDeleted != null){
        print('errors are ${resDeleted}');
      }

      if(resAdded.$1 != null){
        print('errors are ${resAdded.$1} ');
      }

        final List<ImageRefVo> allImages = [
          ...resAdded.$2 ?? [],
          ...event.modifiedImagesVo.retainedImages
        ];


        final updatedBlog = event.gardenBlog.copyWith(imageRefs: allImages);
        await repository.updateOne(updatedBlog);

      emit(GardenBlogNotification('Garden blog inserted'));
      emit(GardenBlogLoaded(await repository.getAll()));
    } catch (e) {
      emit(GardenBlogError("Failed to update product: $e"));
    }

  }

  Future<void> _onAddOne(AddOne event, Emitter<GardenBlogState> emit) async {
    emit(GardenBlogSaving());
 /// save new files.
    /// delete other files

    try {
      final res = await AddManyImages(settings: DBConfig).call(event.modifiedImagesVo);
      if(res.$1 != null){
        print('errors are ${res.$1}');
      }
      if(res.$2 != null){
        final updatedBlog = event.gardenBlog.copyWith(imageRefs: res.$2);
        await repository.createOne(updatedBlog);
      }

      emit(GardenBlogNotification('Garden blog inserted'));
      emit(GardenBlogLoaded(  await repository.getAll()));

    } catch (e) {
      emit(GardenBlogError("Failed to update product: $e"));
    }



  }
}


