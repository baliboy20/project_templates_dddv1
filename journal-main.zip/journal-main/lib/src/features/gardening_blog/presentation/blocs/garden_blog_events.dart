// gardenBlog_event.dart
import 'dart:io';

import 'package:equatable/equatable.dart';
import 'package:parse_utils/domain/models/image_ref.vo.dart';
import 'package:parse_utils/domain/models/modified_images_vo.dart';

import '../../domain/entities/garden_blog_entity.dart';


abstract class GardenBlogEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class InitGardenBlogs extends GardenBlogEvent {}



class LoadGardenBlogs extends GardenBlogEvent {}

class DeleteGardenBlog extends GardenBlogEvent {
  final String id;
  DeleteGardenBlog(this.id);

  @override
  List<Object?> get props => [id];
}

class SelectGardenBlogs extends GardenBlogEvent {
  final GardenBlogEntity id;
  SelectGardenBlogs(this.id);

  @override
  List<Object?> get props => [id];
}

class SaveChanges extends GardenBlogEvent {
  final GardenBlogEntity gardenBlog;
  final ModifiedImagesVo modifiedImagesVo;
  SaveChanges({required this.gardenBlog,  required this.modifiedImagesVo});

  @override
  List<Object?> get props => [gardenBlog, modifiedImagesVo];
}

class AddOne extends GardenBlogEvent {
  final ModifiedImagesVo modifiedImagesVo;
  final GardenBlogEntity gardenBlog;
  AddOne({required this.gardenBlog, required this.modifiedImagesVo});

  @override
  List<Object?> get props => [gardenBlog, modifiedImagesVo];
}

