import 'package:bson/bson.dart';
import 'package:ddd_framework_assets/core/validation/json_validator.dart';
import 'package:equatable/equatable.dart';
import 'package:journal_macos/src/core/app_config/app_config.dart';
import 'package:parse_utils/domain/models/image_ref.vo.dart';



class GardenBlogEntity extends Equatable {
  final String title;
  final List<String> categories;
  final String body;
  final String? id;
  final DateTime? createdOn;
  final String postedBy;
  final List<ImageRefVo>? imageRefs;

  GardenBlogEntity({
    required this.title,
    required this.categories,
    required this.body,
    this.id,
    required this.createdOn,
    required this.postedBy,
    this.imageRefs,
  });

  GardenBlogEntity copyWith({
    String? id,
    DateTime? createdOn,
    String? postedBy,
    String? title,
    List<String>? categories,
    String? body,
    List<ImageRefVo>? imageRefs,
  }) {
    return GardenBlogEntity(
      title: title ?? this.title,
      categories: categories ?? this.categories,
      body: body ?? this.body,
      id: id ?? this.id,
      createdOn: createdOn ?? this.createdOn,
      postedBy: postedBy ?? this.postedBy,
      imageRefs: imageRefs ?? this.imageRefs,
    );
  }

  factory GardenBlogEntity.fromJson(Map<String, dynamic> json) {

    final ident = json['objectId'].toString();

    final valr = JsonValidation.singleton()
    ..nextFrag(fragment: json, clearFailures: false, fragId: ident);

    final ent = GardenBlogEntity(
      title:  valr.isString(key: 'title', severity: ValidationFailureSeverity.log, altValue: ''),
      categories:[],
      body: valr.isString(key: 'body', severity: ValidationFailureSeverity.log, altValue: ''),
      createdOn: valr.isDateTime(key: 'createdOn', severity: ValidationFailureSeverity.log, altValue: DateTime.now()),
      postedBy: valr.isString(key: 'postedBy', severity: ValidationFailureSeverity.log, altValue: 'Guest poster'),
      id: ident,
      imageRefs: valr.isSubList<ImageRefVo>(key: 'imageRefs', mapper: ImageRefVo.fromJson, severity: ValidationFailureSeverity.log, altValue: []),


    );

    assert(valr.hasSevereFails() == false, 'Validation errors: ${valr.listSevereFails().map((e) => e.toString()).join(',')}');

    return ent;

  }

  Map<String, dynamic> toJson() {
    final List<Map<String, dynamic>>? imageRefs =
        this.imageRefs?.map((e) => e.toJson()).toList();
    final retval =  {
      'objectId': id,
      'title': title,
      'categories': categories,
      'body': body,
      'imageRefs': imageRefs,
      'createdOn': createdOn?.toIso8601String(),
      'postedBy': postedBy,

    };
    return retval;

   }

  String toString() {
    return 'GardenBlogEntity(\n'
        '  title: $title,\n'
        '  categories: $categories,\n'
        '  body: $body,\n'
        '  id: $id,\n'
        '  createdOn: $createdOn,\n'
        '  postedBy: $postedBy,\n'
        '  imageRefs: $imageRefs\n'
        ')';
  }

  factory GardenBlogEntity.empty() {
    return GardenBlogEntity(
      title: '',
      categories: [],
      body: '',
      createdOn: DateTime.now(),
      postedBy: '',
    );
  }


  getDefaultImageUrl(){
    if(this.imageRefs == null || this.imageRefs!.isEmpty)
      return "";
    else
    return (this.imageRefs!.firstWhere((ImageRefVo a) => a.isDefault, orElse: () =>imageRefs!.first)).url ;
  }

  @override
  List<Object?> get props => [id, title, categories, body, createdOn, postedBy];
}
