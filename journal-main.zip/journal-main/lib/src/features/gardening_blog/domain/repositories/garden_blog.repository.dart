import 'dart:io';

import 'package:ddd_framework_assets/core/validation/json_validator.dart';
import 'package:journal_macos/src/core/app_config/app_config.dart';
import 'package:parse_utils/infrastructure/api/parse_generic_service_api.dart';

import '../../domain/entities/garden_blog_entity.dart';

class GardenBlogRepositoryImpl {
  final ParseApiService _apiService;

  GardenBlogRepositoryImpl() : _apiService = ParseApiService('gardenBlogs');

  Future<List<GardenBlogEntity>> getAll() async {
    try {
      final results = await _apiService.getItems();
      JsonValidation.resetInstance();
     final entities = results.map((e) => GardenBlogEntity.fromJson(e)).toList();
     if(JsonValidation.singleton().hasSevereFails())
       {
         print(JsonValidation.singleton().listSevereFails());
       }
     return  entities;
    } catch (e) {
      print('Error fetching garden blogs: $e');
      JsonValidation.resetInstance();
      return [];
    }
  }

  Future<String> createOne(GardenBlogEntity blog) async {
    try {
      final data = blog.toJson()..remove("id");
      final result = await _apiService.addOne(data);
      return result!['objectId'];
    } catch (e) {
      print('Error creating garden blog: $e');
   rethrow;
    }
  }


  Future<String> updateOne(GardenBlogEntity blog) async {
    try {
      final data = blog.toJson()..remove("id");
      final result = await _apiService.updateOne(blog.id!,data);
      return result!['objectId'];
    } catch (e) {
      print('Error creating garden blog: $e');
      return "";
    }
  }

  Future<bool> deleteOne(String id) async {
    try {
      return await _apiService.deleteOne(id);
    } catch (e) {
      print('Error deleting garden blog: $e');
      return false;
    }
  }

  Future<GardenBlogEntity?> updateBlogWithImage(GardenBlogEntity blog, File? image) async {
    try {
      Map<String, dynamic> updatedData = blog.toJson();

      if (image != null) {
        final uploadResult = await _apiService.uploadImage(file:image, prefix:  "gdn_");
        if (uploadResult != null && uploadResult['url'] != null) {
          updatedData['imageUrl'] = uploadResult['url'];
        }
      }

      if (blog.id == null) {
        print('Missing blog ID');
        return null;
      }

      final result = await _apiService.updateOne(blog.id!, updatedData);
      return result != null ? GardenBlogEntity.fromJson(result) : null;
    } catch (e) {
      print('Error updating garden blog: $e');
      return null;
    }
  }

  Future<GardenBlogEntity?> createBlogWithImage(GardenBlogEntity blog, File image) async {
    try {
      final fname = image.path.split('/').last;
      final uploadResult = await _apiService.uploadImage(file:image, prefix:"gdn_");
      if (uploadResult == null || uploadResult['url'] == null) {
        print('Image upload failed');
        return null;
      }

      final Map<String, dynamic> blogData = blog.toJson();
      blogData['filepath'] = uploadResult['url'];
      blogData['filename'] = uploadResult['name'];

      final result = await _apiService.addOne(blogData);
      return result != null ? GardenBlogEntity.fromJson(result) : null;
    } catch (e) {
      print('Error creating blog with image: $e');
      return null;
    }
  }
}
