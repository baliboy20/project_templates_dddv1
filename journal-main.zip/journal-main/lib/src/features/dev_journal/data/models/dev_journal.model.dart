import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:mongo_dart/mongo_dart.dart';

import 'package:equatable/equatable.dart';
import 'package:bson/bson.dart';
// class _DevJournal extends Equatable {
//
// /// to be implemented
// final String urname1;
// final String urname2;
// final String urname3;
// final ObjectId id;
// final DateTime createdOn;
// final List<String> categories;
// //todo: is fixed?
// DevJournal({
// required this.urname1,
// required this.urname2,
// required this.urname3,
// required this.id,
// required this.createdOn,
// required this.categories});
//
// @override
// // TODO: implement props
// List<Object?> get props => [urname3, urname2, urname1];
// static _DevJournal fromJson(Map<String, dynamic> json) {
// return _DevJournal(
// id: ObjectId.fromHexString(json['_id']),
// urname1: json['urname1'],
// urname3: json['urname3'],
// urname2: json['urname2'],
// createdOn: DateTime.parse(json['createdOn']),
// categories: json['categories'],
// );
// }
// toJson() {
// return {
// '_id': id.toString(),
// 'urname1': urname1,
// 'urname3': urname3,
// 'urname2': urname2,
// 'createdOn': createdOn.toIso8601String(),
// };
// }
// static empty() {
// return _DevJournal(
// urname1: '',
// urname3: '',
// urname2: '',
// id: ObjectId(),
// createdOn: DateTime.now(),
// categories: [],
// );
// }
//
// _DevJournal  copyWith(
// {String? urname1,
// String? urname2,
// String? urname3,
// ObjectId? id,
// DateTime? createdOn,
// List<String>? categories}) {
// return DevJournal(
// urname1: urname1 ?? this.urname1,
// urname2: urname2 ?? this.urname2,
// urname3: urname3 ?? this.urname3,
// id: id ?? this.id,
// createdOn: createdOn ?? this.createdOn,
// categories: categories ?? this.categories,
// );
// }
// }

//======================== end

/**
    This is a class named DevJournal that extends Equatable and is written in dart with the following methods and properties:-
    - String title,
    - List<String> categories,
    - String body,
    - ObjectId id, (mongodb)
    - DateTime createOn,
    - String postedby

    It implements  @override getProps => [], where the array returned contains references to the classes public properties.

    The class has the following methods:
    -   Map<String, dynamic> toJson,
    - fromJson(Map<Sting,dynamic> json),
    where the id field takes the value of the _id field
    - copyWith
    - empty which create a new instance of the class and where all the fields are empty apart from the id field, which is initalised with a new ObjectId
    - create a method called concatenateFields() which returns a string of conconcatenated values of all fields of type string or List<String>.
 **/


@immutable
class DevJournal extends Equatable {
  final String title;
  final List<String> categories;
  final String body;
  final ObjectId id;
  final DateTime createdOn;
  final String postedBy;
  int localid = 0;
  static int local_counter = 0;

  DevJournal({
    required this.title,
    required this.categories,
    required this.body,
    required this.id,
    required this.createdOn,
    required this.postedBy,
  }): localid =local_counter++ ;

  @override
  List<Object> get props => [title, categories, body, id, createdOn, postedBy];

  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'categories': categories,
      'body': body,
      '_id': id.toHexString(),
      'createdOn': createdOn.toIso8601String(),
      'postedBy': postedBy,
    };
  }

  static DevJournal fromJson(Map<String, dynamic> json) {

   try {
print('fromJson: $local_counter');
     DevJournal  res = DevJournal(
       title: json['title'] ?? '',
       categories: [], //List<String>.from(json['categories']) ?? [],
       body: json['body'] ?? '',
       id: ObjectId.fromHexString(json['_id'])  ,
       createdOn: json.containsKey('createdOn') && json['createdOn'] != null ?  DateTime.parse(json['createdOn']) : DateTime.now(),
       postedBy: json['postedBy'] ?? 'william',
     );
     return res;
   } catch (e) {
     print('error in fromJson: $e');
     throw e;
   }
  }

  DevJournal copyWith({
    String? title,
    List<String>? categories,
    String? body,
    ObjectId? id,
    DateTime? createdOn,
    String? postedBy,
  }) {
    return DevJournal(
      title: title ?? this.title,
      categories: categories ?? this.categories,
      body: body ?? this.body,
      id: id ?? this.id,
      createdOn: createdOn ?? this.createdOn,
      postedBy: postedBy ?? this.postedBy,
    );
  }

  static DevJournal empty() {
    return DevJournal(
      title: '',
      categories: [],
      body: '',
      id: ObjectId(),
      createdOn: DateTime.now(),
      postedBy: '',
    );
  }

  String concatenateFields() {
    return '${title}${categories.join()}${body}${postedBy}';
  }
}
