import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/dev_journal.model.dart';
import '../../../domain/repositories/dev_journal_repository_base.dart';



class DevJournalRepository implements DevJournalRepositoryBase {
  final String baseUrl;



  DevJournalRepository({ required this.baseUrl});

  Future<List<DevJournal>> getItems() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/findAll'));
      if (response.statusCode == 200) {
        Iterable list = json.decode(response.body);
    List<DevJournal> list1 =  list.map((e) => DevJournal.fromJson(e)).toList() as  List<DevJournal>;
    return Future.value(list1);

      } else {
        throw Exception('Failed to load items');
      }
    } catch (e) {
      print(e.toString());
      return [];
    }
  }

  Future<List<DevJournal>> findItemsWhere(Map<String, dynamic> criteria) async {
    try {
      final response = await http.post(Uri.parse('$baseUrl/findBy'), body: jsonEncode(criteria));
      if (response.statusCode == 200) {
        Iterable list = json.decode(response.body);
        return list.map((e) => DevJournal.fromJson(e)).toList() as Future<List<DevJournal>>;

  } else {
        throw Exception('Failed to load items');
      }
    } catch (e) {
      print(e.toString());
      return [];
    }
  }

  Future<DevJournal> updateItem(DevJournal item) async {

    try {


      final response = await http.post(Uri.parse('$baseUrl/add-one'),
          headers: <String, String>{
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: jsonEncode(item));
      if (response.statusCode == 200) {

        return DevJournal.empty();
      } else {
        throw Exception('Failed to update item');
      }
    } catch (e) {
      print(e.toString());
      return Future.value(null);
    }
  }

  Future<DevJournal> addItem(DevJournal item) async {
    try {
      final response = await http.post(Uri.parse('$baseUrl/addOne'), body: item.toJson());
      if (response.statusCode == 200) {
        return DevJournal.fromJson(json.decode(response.body));
      } else {
        throw Exception('Failed to add item');
      }
    } catch (e) {
      print(e.toString());
      return Future.value(null);
    }
  }

  Future<dynamic> deleteItem(DevJournal item) async {
    print('hi ${item.toJson()}, \\n ${baseUrl}');
    try {
      final response = await http.delete(Uri.parse('$baseUrl/deleteById/${item.id.toHexString()}'));
      if (response.statusCode == 200) {
        return json.decode(response.body);
      } else {
        throw Exception('Failed to delete item');
      }
    } catch (e) {
      print("Error: ${e.toString()}");
      return null;
    }
  }

  get isChanged {
    // Implement your own logic for checking if the repository has changed
  }

   FilteredResultsStore<DevJournal>? store;
   List<DevJournal>  list = [];

  Future<List<DevJournal>> filterItems(Map<String, dynamic> crit ) async {
    // setup the store.
    if (store == null)
      store = FilteredResultsStore<DevJournal>(crit, list);

    // if the store is the same, return the same list.
     if (store!.equals(crit)) {
      return Future.value(store!.results);
    }
    _UnaryPredicate<DevJournal> fn = (arg) => crit.values.any((pm)=> arg.concatenateFields().contains(pm));
    List<DevJournal> rz =  await getItems();
    DevJournal t1 = rz.first;
    List<DevJournal>  rz1 = rz.where(fn).toList();
    store = FilteredResultsStore(crit, rz);

   final tcrit = crit.values;
   final tbn = tcrit.any((e) => t1.toJson().values.join(',').contains(e));
   return rz1;
  }


  @override
  Future getList() {
    // TODO: implement getList
    throw UnimplementedError();
  }
}

class FilteredResultsStore <T>{
  final Map<String, dynamic> crit;
  final List<T> list;
  FilteredResultsStore(this.crit, this.list);
  bool equals(Map<String, dynamic> crit) {
    return this.crit == crit;
  }
  get results => list ?? [];

}

typedef _UnaryPredicate <T>  = bool Function(T i);
