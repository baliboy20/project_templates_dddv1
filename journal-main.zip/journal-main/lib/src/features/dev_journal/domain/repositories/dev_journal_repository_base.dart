import 'dart:async';
import '../../data/models/dev_journal.model.dart';
abstract class DevJournalRepositoryBase {
  Future<List<DevJournal>> getItems();
  Future<List<DevJournal>> findItemsWhere(Map<String, dynamic> criteria);
  Future<DevJournal> updateItem(DevJournal item);
  Future<DevJournal> addItem(DevJournal item);
  Future<dynamic> deleteItem(DevJournal item);
  Future<dynamic> getList();

  get isChanged;

  Future<List<DevJournal>?> filterItems(Map<String, dynamic> map);
}
