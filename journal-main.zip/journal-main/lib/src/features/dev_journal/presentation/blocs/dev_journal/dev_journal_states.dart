part of 'dev_journal_bloc.dart';


class DevJournalStatesDictionary {
  static Function waiting = () => Waiting(showAnimation: false);
  static Function loadedDevJournals =
      (List<DevJournal> devJournals) => LoadedDevJournals(devJournals: devJournals);
  static Function devJournalError =
      (String errorMessage) => DevJournalError(errorMessage: errorMessage);
  static Function editingDevJournal = (DevJournal devJournal, List<String> categories) =>
      EditingDevJournal(devJournal: devJournal, categories: categories);
  static Function savingChanges =
      (String message) => SavingChanges(message: message);
  static Function snackBarMessage =
      (String message) => SnackBarMessage(message: message);
}

abstract class DevJournalStates extends Equatable {}

class Waiting extends DevJournalStates {
  final bool showAnimation;

  Waiting({required this.showAnimation});

  @override
  List<Object> get props => [showAnimation];
}

class LoadedDevJournals extends DevJournalStates {
  final List<DevJournal> devJournals;
  final int len;

  LoadedDevJournals({required this.devJournals}) : len = devJournals.length;

  @override
  List<Object> get props => [devJournals];
}

class DevJournalError extends DevJournalStates {
  final String errorMessage;

  DevJournalError({required this.errorMessage});

  @override
  List<Object> get props => [errorMessage];
}

class EditingDevJournal extends DevJournalStates {
  final DevJournal devJournal;
  final List<String> categories;

  EditingDevJournal({required this.devJournal, required this.categories});

  @override
  List<Object> get props => [devJournal];
}

class SavingChanges extends DevJournalStates {
  final String message;

  SavingChanges({required this.message});

  @override
  List<Object> get props => [message];
}

/// SnackBarMessage is used to display a message in a SnackBar
/// on the main Scaffold.
/// has the property message which is the message to display.
class SnackBarMessage extends DevJournalStates {
  final String message;

  SnackBarMessage({required this.message});

  @override
  List<Object> get props => [message];
}
