import 'package:bloc/bloc.dart';

// import '../../repositories/dev_journal/dev_journal_repository.dart';
// import 'package:mongo_dart/mongo_dart.dart';

//  uncomment
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import '../../../data/models/dev_journal.model.dart';
import '../../../domain/repositories/dev_journal_repository_base.dart';

part './dev_journal_actions.dart';

part './dev_journal_states.dart';

class DevJournalBloc extends Bloc<DevJournalActions, DevJournalStates> {
  final DevJournalRepositoryBase repository;


  DevJournalBloc({required this.repository})
      : super(Waiting(showAnimation: true)) {
    on<DbLoadDevJournal>(_dbLoadDevJournal);
    on<DbUpsertDevJournal>(_dbUpsertDevJournal);
    on<DbDeleteDevJournal>(_dbDeleteDevJournal);
    on<DoEditDevJournal>(_doEditDevJournal);
    on<DoCreateDevJournal>(_doCreateDevJournal);
    on<DbFilterDevJournals>(_doFilterDevJournals);

  }

  @override
  void onTransition(Transition<DevJournalActions, DevJournalStates> transition) {
   // print(transition);
    super.onTransition(transition);
  }
  Future<void> _doFilterDevJournals(
      DbFilterDevJournals event, Emitter<DevJournalStates> emit) async {
    // emit(Waiting(showAnimation: true));
    // print('at this poilknt we are stuk');
    try {

      final devJournal =
          await repository.filterItems(event.criteria) as List<DevJournal>;

      emit(LoadedDevJournals(devJournals: devJournal));
    } catch (e) {
      emit(DevJournalError(errorMessage: e.toString()));
    }
  }

// Private event handler methods
  Future<void> _dbLoadDevJournal(
      DbLoadDevJournal event, Emitter<DevJournalStates> emit) async {
    emit(Waiting(showAnimation: true));
    try {
      final devJournal = await repository.getItems() as List<DevJournal>;
      emit(LoadedDevJournals(devJournals: devJournal));
    } catch (e) {
      emit(DevJournalError(errorMessage: e.toString()));
    }
  }

  Future<void> _dbUpsertDevJournal(
      DbUpsertDevJournal event, Emitter<DevJournalStates> emit) async {

    emit(Waiting(showAnimation: true));
    try {
      await repository.updateItem(event.item);
      emit(SnackBarMessage(message: "Saved"));
    } catch (e) {
      emit(DevJournalError(errorMessage: e.toString()));
    } finally {
      final devJournal = await repository.getItems() as List<DevJournal>;
      emit(LoadedDevJournals(devJournals: devJournal));
    }
  }

  Future<void> _dbDeleteDevJournal(
      DbDeleteDevJournal event, Emitter<DevJournalStates> emit) async {
    emit(Waiting(showAnimation: true));
    try {
      await repository.deleteItem(event.devJournal);
      emit(SnackBarMessage(message: "DevJournal Deleted"));
    } catch (e) {
      emit(DevJournalError(errorMessage: e.toString()));
    } finally {
      final devJournal = await repository.getItems() as List<DevJournal>;
      emit(LoadedDevJournals(devJournals: devJournal));
    }
  }

  Future<void> _doEditDevJournal(
      DoEditDevJournal event, Emitter<DevJournalStates> emit) async {
    List<String> cats = ["hujmg", "dfder"]; //await repository.getList();
    emit(EditingDevJournal(devJournal: event.item, categories: cats));
    print('Editing item ${event.item.id}');
  }

  Future<void> _doCreateDevJournal(
      DoCreateDevJournal event, Emitter<DevJournalStates> emit) async {
    emit(EditingDevJournal(
        devJournal: DevJournal.empty(),
        categories: ['Personal', 'Work', 'Family', 'Other']));
  }
}
