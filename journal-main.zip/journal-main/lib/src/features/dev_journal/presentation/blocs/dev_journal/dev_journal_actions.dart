part of 'dev_journal_bloc.dart';



abstract class DevJournalActions extends Equatable {}

class DbLoadDevJournal extends DevJournalActions {
final Map<String, dynamic>? criteria;

DbLoadDevJournal({required this.criteria});

@override
List<Object> get props => [criteria ?? ''];
}

class DbFilterDevJournals extends DevJournalActions {
final Map<String, dynamic> criteria;

DbFilterDevJournals({required this.criteria});

@override
List<Object> get props => [criteria ?? ''];
}

class DbUpsertDevJournal extends DevJournalActions {
final DevJournal item;

DbUpsertDevJournal({required this.item});

@override
List<Object> get props => [item];
}

class DbDeleteDevJournal extends DevJournalActions {
final DevJournal devJournal;

DbDeleteDevJournal({required this.devJournal});

@override
List<Object> get props => [devJournal];
}
@immutable
class DoEditDevJournal extends DevJournalActions {
final DevJournal item;
DoEditDevJournal({required this.item});
@override
List<Object> get props => [item];
}

class DoCreateDevJournal extends DevJournalActions {
@override
List<Object> get props => [];
}






