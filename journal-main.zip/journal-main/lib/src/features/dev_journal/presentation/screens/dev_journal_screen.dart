
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:journal_macos/src/features/dev_journal/presentation/screens/dev_journal_blog/dev_journal_blog.screen.dart';

import '../../../../shared/widgets/export.widgets.dart';


class HomeScreen extends StatelessWidget {
  static const routeName = '/home';
  static MaterialPageRoute genRoute () {
    return MaterialPageRoute(
        settings: RouteSettings(name: routeName),
        builder: (_) => HomeScreen());
  }
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: AppDrawer(),
      appBar: AppBar(title: Text('test'),),
      body: Center(child: Text('Home Screen'),),

    );
  }
}


class DevJournalScreen extends StatefulWidget {
// this should be paramCase.
static const routeLabel = 'Dev Journal';
static const routeName = '/dev-journal';
static MaterialPageRoute genRoute () {
return MaterialPageRoute(
settings: RouteSettings(name: routeName),
builder: (_) => DevJournalScreen());
}
const DevJournalScreen({Key? key}) : super(key: key);

@override
State<DevJournalScreen> createState() => _DevJournalScreenState();
}

class _DevJournalScreenState extends State<DevJournalScreen> {
@override
Widget build(BuildContext context) {
return Scaffold(
drawer: AppDrawer(),
appBar: AppBar(
title: Text('DevJournal'),
),
body: Center(
child: DevJournalBlogScreen())
);}
}


