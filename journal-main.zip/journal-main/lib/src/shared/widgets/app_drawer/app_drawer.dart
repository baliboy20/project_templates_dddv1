import 'package:flutter/material.dart';
import 'package:journal_macos/src/features/projects/presentation/screens/projects_screen.dart';
import 'package:journal_macos/src/features/snippets/presentation/screens/SnippetScreen.dart'
    as snip;
import 'package:journal_macos/src/features/tasks/presentation/screens/task_screeen.dart';

import '../../../features/dev_journal/presentation/screens/dev_journal_blog/dev_journal_blog.screen.dart';
import '../../../features/gardening_blog/presentation/screens/garden_blog_screen.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({Key? key}) : super(key: key);

  final List<Map<String, String>> tiles = const [
    {'label': 'Home', "path": '/home'},
    {
      "label": DevJournalBlogScreen.routeLabel,
      "path": DevJournalBlogScreen.routeName
    },
    {
      "label": snip.SnippetsScreen.routeLabel,
      "path": snip.SnippetsScreen.routeName
    },
    {"label": TaskScreen.routeLabel, "path": TaskScreen.routeName},
    {"label": ProjectsScreen.routeLabel, "path": ProjectsScreen.routeName},
    {"label": GardenBlogScreen.routeLabel, "path": GardenBlogScreen.routeName},
  ];

  @override
  Widget build(BuildContext context) {
    return Drawer(
        child: Padding(
      padding: EdgeInsets.symmetric(horizontal: 0),
      child: Column(
        children: [
          DrawerHeader(
            child: Text(
              'Menu',
              style: Theme.of(context).textTheme.labelMedium,
            ),
          ),
          ListView.separated(
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            separatorBuilder: (context, idx) => Divider(),
            itemCount: tiles.length,
            itemBuilder: (context, idx) => ListTile(
              title: Text('${tiles[idx]['label']}'),
              onTap: () => Navigator.pushNamed(context, tiles[idx]['path']!),
            ),
          ),
        ],
      ),
    ));
  }
}
